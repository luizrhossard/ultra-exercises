import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Sidebar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8a41314"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=a8a41314";
import { useApp } from "/src/store.tsx";
import { sportById } from "/src/data/sports.ts";
import { Logo } from "/src/components/Logo.tsx";
import {
  IconBolt,
  IconClipboard,
  IconRadar,
  IconTrend,
  IconUser,
  SportIcon
} from "/src/components/Icons.tsx";
const NAV = [
  { id: "explorar", label: "Explorar", hint: "Feed por relevância", icon: (p) => /* @__PURE__ */ jsxDEV(IconRadar, { ...p }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
    lineNumber: 36,
    columnNumber: 80
  }, this) },
  { id: "rotinas", label: "Rotinas", hint: "Gerador + salvas", icon: (p) => /* @__PURE__ */ jsxDEV(IconClipboard, { ...p }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
    lineNumber: 37,
    columnNumber: 75
  }, this) },
  { id: "progresso", label: "Progresso", hint: "Resumo e histórico", icon: (p) => /* @__PURE__ */ jsxDEV(IconTrend, { ...p }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
    lineNumber: 38,
    columnNumber: 81
  }, this) },
  { id: "perfil", label: "Perfil", hint: "Esportes e dados", icon: (p) => /* @__PURE__ */ jsxDEV(IconUser, { ...p }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
    lineNumber: 39,
    columnNumber: 73
  }, this) }
];
export default function Sidebar() {
  _s();
  const { tab, setTab, setGenFocus, profile } = useApp();
  return /* @__PURE__ */ jsxDEV("aside", { className: "fixed inset-y-0 left-0 z-30 hidden w-[260px] flex-col border-r border-ink-800 bg-ink-900/90 backdrop-blur-md lg:flex", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "px-6 pb-5 pt-7", children: /* @__PURE__ */ jsxDEV(Logo, { full: true }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
      lineNumber: 49,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "space-y-1 px-3", children: NAV.map((item) => {
      const active = tab === item.id;
      return /* @__PURE__ */ jsxDEV(
        motion.button,
        {
          whileTap: { scale: 0.97 },
          onClick: () => setTab(item.id),
          className: `group relative flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-left transition-colors ${active ? "bg-ink-800" : "hover:bg-ink-850"}`,
          "aria-current": active ? "page" : void 0,
          children: [
            active && /* @__PURE__ */ jsxDEV(
              motion.span,
              {
                layoutId: "sidebar-notch",
                className: "absolute left-0 top-1/2 h-7 w-[3px] -translate-y-1/2 rounded-r-full bg-volt-400"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
                lineNumber: 67,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: `transition-colors ${active ? "text-volt-400" : "text-fog-mute group-hover:text-fog-dim"}`, children: item.icon({ size: 19 }) }, void 0, false, {
              fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
              lineNumber: 72,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("span", { className: `block text-[13px] font-bold ${active ? "text-fog" : "text-fog-dim group-hover:text-fog"}`, children: item.label }, void 0, false, {
                fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
                lineNumber: 76,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "block text-[10px] uppercase tracking-[0.12em] text-fog-mute", children: item.hint }, void 0, false, {
                fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
                lineNumber: 79,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
              lineNumber: 75,
              columnNumber: 15
            }, this)
          ]
        },
        item.id,
        true,
        {
          fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
          lineNumber: 57,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "px-5 pt-5", children: /* @__PURE__ */ jsxDEV(
      motion.button,
      {
        whileTap: { scale: 0.96 },
        onClick: () => {
          setGenFocus(null);
          setTab("rotinas");
          window.setTimeout(
            () => document.getElementById("generator-card")?.scrollIntoView({ behavior: "smooth", block: "center" }),
            80
          );
        },
        className: "flex w-full items-center justify-center gap-2 rounded-xl bg-volt-400 py-3 font-display text-sm uppercase tracking-[0.06em] text-ink-950 shadow-[0_8px_26px_rgba(212,245,60,0.28)] transition-shadow hover:shadow-[0_10px_34px_rgba(212,245,60,0.4)]",
        children: [
          /* @__PURE__ */ jsxDEV(IconBolt, { size: 16, strokeWidth: 2.4 }, void 0, false, {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
            lineNumber: 101,
            columnNumber: 11
          }, this),
          " Gerar treino do dia"
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
        lineNumber: 88,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
      lineNumber: 87,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 min-h-0 flex-1 overflow-y-auto px-6", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[9px] font-bold uppercase tracking-[0.22em] text-fog-mute", children: "No foco" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
        lineNumber: 107,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-3 space-y-1.5", children: profile.sports.map((id) => {
        const s = sportById(id);
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "flex items-center gap-2.5 rounded-lg border border-ink-800 bg-ink-850/70 px-2.5 py-2 transition-colors hover:border-ink-600",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "grid h-7 w-7 place-items-center rounded-md", style: { background: `${s.color}1a`, color: s.color }, children: /* @__PURE__ */ jsxDEV(SportIcon, { id, size: 15 }, void 0, false, {
                fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
                lineNumber: 117,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
                lineNumber: 116,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "flex-1 truncate text-[12px] font-bold text-fog-dim", children: s.name }, void 0, false, {
                fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
                lineNumber: 119,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "h-1.5 w-1.5 rounded-full blink-dot", style: { background: s.color } }, void 0, false, {
                fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
                lineNumber: 120,
                columnNumber: 17
              }, this)
            ]
          },
          id,
          true,
          {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
            lineNumber: 112,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
        lineNumber: 108,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
      lineNumber: 106,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => setTab("perfil"),
        className: "m-3 flex items-center gap-3 rounded-xl border border-ink-800 bg-ink-850/80 px-3 py-3 text-left transition-colors hover:border-ink-600",
        children: [
          /* @__PURE__ */ jsxDEV("span", { className: "grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-volt-400/15 font-display text-base text-volt-400 ring-1 ring-volt-400/30", children: (profile.name || "A")[0].toUpperCase() }, void 0, false, {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
            lineNumber: 132,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block truncate text-[13px] font-bold text-fog", children: profile.name || "Atleta" }, void 0, false, {
              fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
              lineNumber: 136,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "block text-[10px] uppercase tracking-[0.14em] text-fog-mute", children: [
              profile.sports.length,
              " esporte",
              profile.sports.length === 1 ? "" : "s",
              " ativo",
              profile.sports.length === 1 ? "" : "s"
            ] }, void 0, true, {
              fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
              lineNumber: 137,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
            lineNumber: 135,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
        lineNumber: 128,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
}
_s(Sidebar, "wTMa8GfngM3nVf967VU6Lwrs1mY=", false, function() {
  return [useApp];
});
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Sidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JpRjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFmakYsU0FBU0EsY0FBYztBQUN2QixTQUFTQyxjQUFjO0FBRXZCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxZQUFZO0FBQ3JCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLE1BQU1DLE1BQW1HO0FBQUEsRUFDdkcsRUFBRUMsSUFBSSxZQUFZQyxPQUFPLFlBQVlDLE1BQU0sdUJBQXVCQyxNQUFNQSxDQUFDQyxNQUFNLHVCQUFDLGFBQVUsR0FBSUEsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlCLEVBQUk7QUFBQSxFQUNwRyxFQUFFSixJQUFJLFdBQVdDLE9BQU8sV0FBV0MsTUFBTSxvQkFBb0JDLE1BQU1BLENBQUNDLE1BQU0sdUJBQUMsaUJBQWMsR0FBSUEsS0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQixFQUFJO0FBQUEsRUFDbkcsRUFBRUosSUFBSSxhQUFhQyxPQUFPLGFBQWFDLE1BQU0sc0JBQXNCQyxNQUFNQSxDQUFDQyxNQUFNLHVCQUFDLGFBQVUsR0FBSUEsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlCLEVBQUk7QUFBQSxFQUNyRyxFQUFFSixJQUFJLFVBQVVDLE9BQU8sVUFBVUMsTUFBTSxvQkFBb0JDLE1BQU1BLENBQUNDLE1BQU0sdUJBQUMsWUFBUyxHQUFJQSxLQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0IsRUFBSTtBQUFDO0FBRy9GLHdCQUF3QkMsVUFBVTtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sRUFBRUMsS0FBS0MsUUFBUUMsYUFBYUMsUUFBUSxJQUFJcEIsT0FBTztBQUVyRCxTQUNFLHVCQUFDLFdBQU0sV0FBVSx3SEFFZjtBQUFBLDJCQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxRQUFLLE1BQUksUUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVUsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxrQkFDWlMsY0FBSVksSUFBSSxDQUFDQyxTQUFTO0FBQ2pCLFlBQU1DLFNBQVNOLFFBQVFLLEtBQUtaO0FBQzVCLGFBQ0U7QUFBQSxRQUFDLE9BQU87QUFBQSxRQUFQO0FBQUEsVUFFQyxVQUFVLEVBQUVjLE9BQU8sS0FBSztBQUFBLFVBQ3hCLFNBQVMsTUFBTU4sT0FBT0ksS0FBS1osRUFBRTtBQUFBLFVBQzdCLFdBQVcsc0dBQ1RhLFNBQVMsZUFBZSxrQkFBa0I7QUFBQSxVQUU1QyxnQkFBY0EsU0FBUyxTQUFTRTtBQUFBQSxVQUUvQkY7QUFBQUEsc0JBQ0M7QUFBQSxjQUFDLE9BQU87QUFBQSxjQUFQO0FBQUEsZ0JBQ0MsVUFBUztBQUFBLGdCQUNULFdBQVU7QUFBQTtBQUFBLGNBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRTZGO0FBQUEsWUFHL0YsdUJBQUMsVUFBSyxXQUFXLHFCQUFxQkEsU0FBUyxrQkFBa0Isd0NBQXdDLElBQ3RHRCxlQUFLVCxLQUFLLEVBQUVhLE1BQU0sR0FBRyxDQUFDLEtBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxrQkFDZDtBQUFBLHFDQUFDLFVBQUssV0FBVywrQkFBK0JILFNBQVMsYUFBYSxtQ0FBbUMsSUFDdEdELGVBQUtYLFNBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsVUFBSyxXQUFVLCtEQUErRFcsZUFBS1YsUUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUY7QUFBQSxpQkFKM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBO0FBQUE7QUFBQSxRQXRCS1UsS0FBS1o7QUFBQUEsUUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bd0JBO0FBQUEsSUFFSixDQUFDLEtBOUJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErQkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsTUFBQyxPQUFPO0FBQUEsTUFBUDtBQUFBLFFBQ0MsVUFBVSxFQUFFYyxPQUFPLEtBQUs7QUFBQSxRQUN4QixTQUFTLE1BQU07QUFDYkwsc0JBQVksSUFBSTtBQUNoQkQsaUJBQU8sU0FBUztBQUNoQlMsaUJBQU9DO0FBQUFBLFlBQ0wsTUFDRUMsU0FBU0MsZUFBZSxnQkFBZ0IsR0FBR0MsZUFBZSxFQUFFQyxVQUFVLFVBQVVDLE9BQU8sU0FBUyxDQUFDO0FBQUEsWUFDbkc7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLFFBQ0EsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxZQUFTLE1BQU0sSUFBSSxhQUFhLE9BQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDO0FBQUEsVUFBRztBQUFBO0FBQUE7QUFBQSxNQWIxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLDZCQUFDLE9BQUUsV0FBVSxrRUFBaUUsdUJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUY7QUFBQSxNQUNyRix1QkFBQyxTQUFJLFdBQVUsb0JBQ1piLGtCQUFRYyxPQUFPYixJQUFJLENBQUNYLE9BQU87QUFDMUIsY0FBTXlCLElBQUlsQyxVQUFVUyxFQUFFO0FBQ3RCLGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsVUFBSyxXQUFVLDhDQUE2QyxPQUFPLEVBQUUwQixZQUFZLEdBQUdELEVBQUVFLEtBQUssTUFBTUEsT0FBT0YsRUFBRUUsTUFBTSxHQUMvRyxpQ0FBQyxhQUFVLElBQVEsTUFBTSxNQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsc0RBQXNERixZQUFFRyxRQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBQzdFLHVCQUFDLFVBQUssV0FBVSxzQ0FBcUMsT0FBTyxFQUFFRixZQUFZRCxFQUFFRSxNQUFNLEtBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9GO0FBQUE7QUFBQTtBQUFBLFVBUC9FM0I7QUFBQUEsVUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0E7QUFBQSxNQUVKLENBQUMsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsTUFBTVEsT0FBTyxRQUFRO0FBQUEsUUFDOUIsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsbUlBQ1pFLG1CQUFRa0IsUUFBUSxLQUFLLENBQUMsRUFBRUMsWUFBWSxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsV0FDZDtBQUFBLG1DQUFDLFVBQUssV0FBVSxpREFBaURuQixrQkFBUWtCLFFBQVEsWUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxZQUMxRix1QkFBQyxVQUFLLFdBQVUsK0RBQ2JsQjtBQUFBQSxzQkFBUWMsT0FBT007QUFBQUEsY0FBTztBQUFBLGNBQVNwQixRQUFRYyxPQUFPTSxXQUFXLElBQUksS0FBSztBQUFBLGNBQUk7QUFBQSxjQUFPcEIsUUFBUWMsT0FBT00sV0FBVyxJQUFJLEtBQUs7QUFBQSxpQkFEbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBO0FBQUE7QUFBQSxNQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWFBO0FBQUEsT0EvRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdHQTtBQUVKO0FBQUN4QixHQXRHdUJELFNBQU87QUFBQSxVQUNpQmYsTUFBTTtBQUFBO0FBQUEsS0FEOUJlO0FBQU8sSUFBQTBCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIm1vdGlvbiIsInVzZUFwcCIsInNwb3J0QnlJZCIsIkxvZ28iLCJJY29uQm9sdCIsIkljb25DbGlwYm9hcmQiLCJJY29uUmFkYXIiLCJJY29uVHJlbmQiLCJJY29uVXNlciIsIlNwb3J0SWNvbiIsIk5BViIsImlkIiwibGFiZWwiLCJoaW50IiwiaWNvbiIsInAiLCJTaWRlYmFyIiwiX3MiLCJ0YWIiLCJzZXRUYWIiLCJzZXRHZW5Gb2N1cyIsInByb2ZpbGUiLCJtYXAiLCJpdGVtIiwiYWN0aXZlIiwic2NhbGUiLCJ1bmRlZmluZWQiLCJzaXplIiwid2luZG93Iiwic2V0VGltZW91dCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJzY3JvbGxJbnRvVmlldyIsImJlaGF2aW9yIiwiYmxvY2siLCJzcG9ydHMiLCJzIiwiYmFja2dyb3VuZCIsImNvbG9yIiwibmFtZSIsInRvVXBwZXJDYXNlIiwibGVuZ3RoIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2lkZWJhci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tIFwiZnJhbWVyLW1vdGlvblwiO1xyXG5pbXBvcnQgeyB1c2VBcHAgfSBmcm9tIFwiLi4vc3RvcmVcIjtcclxuaW1wb3J0IHR5cGUgeyBUYWIgfSBmcm9tIFwiLi4vdHlwZXNcIjtcclxuaW1wb3J0IHsgc3BvcnRCeUlkIH0gZnJvbSBcIi4uL2RhdGEvc3BvcnRzXCI7XHJcbmltcG9ydCB7IExvZ28gfSBmcm9tIFwiLi9Mb2dvXCI7XHJcbmltcG9ydCB7XHJcbiAgSWNvbkJvbHQsXHJcbiAgSWNvbkNsaXBib2FyZCxcclxuICBJY29uUmFkYXIsXHJcbiAgSWNvblRyZW5kLFxyXG4gIEljb25Vc2VyLFxyXG4gIFNwb3J0SWNvbixcclxufSBmcm9tIFwiLi9JY29uc1wiO1xyXG5cclxuY29uc3QgTkFWOiB7IGlkOiBUYWI7IGxhYmVsOiBzdHJpbmc7IGhpbnQ6IHN0cmluZzsgaWNvbjogKHA6IHsgc2l6ZT86IG51bWJlciB9KSA9PiBSZWFjdC5SZWFjdE5vZGUgfVtdID0gW1xyXG4gIHsgaWQ6IFwiZXhwbG9yYXJcIiwgbGFiZWw6IFwiRXhwbG9yYXJcIiwgaGludDogXCJGZWVkIHBvciByZWxldsOibmNpYVwiLCBpY29uOiAocCkgPT4gPEljb25SYWRhciB7Li4ucH0gLz4gfSxcclxuICB7IGlkOiBcInJvdGluYXNcIiwgbGFiZWw6IFwiUm90aW5hc1wiLCBoaW50OiBcIkdlcmFkb3IgKyBzYWx2YXNcIiwgaWNvbjogKHApID0+IDxJY29uQ2xpcGJvYXJkIHsuLi5wfSAvPiB9LFxyXG4gIHsgaWQ6IFwicHJvZ3Jlc3NvXCIsIGxhYmVsOiBcIlByb2dyZXNzb1wiLCBoaW50OiBcIlJlc3VtbyBlIGhpc3TDs3JpY29cIiwgaWNvbjogKHApID0+IDxJY29uVHJlbmQgey4uLnB9IC8+IH0sXHJcbiAgeyBpZDogXCJwZXJmaWxcIiwgbGFiZWw6IFwiUGVyZmlsXCIsIGhpbnQ6IFwiRXNwb3J0ZXMgZSBkYWRvc1wiLCBpY29uOiAocCkgPT4gPEljb25Vc2VyIHsuLi5wfSAvPiB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2lkZWJhcigpIHtcclxuICBjb25zdCB7IHRhYiwgc2V0VGFiLCBzZXRHZW5Gb2N1cywgcHJvZmlsZSB9ID0gdXNlQXBwKCk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8YXNpZGUgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQteS0wIGxlZnQtMCB6LTMwIGhpZGRlbiB3LVsyNjBweF0gZmxleC1jb2wgYm9yZGVyLXIgYm9yZGVyLWluay04MDAgYmctaW5rLTkwMC85MCBiYWNrZHJvcC1ibHVyLW1kIGxnOmZsZXhcIj5cclxuICAgICAgey8qIGJyYW5kICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcGItNSBwdC03XCI+XHJcbiAgICAgICAgPExvZ28gZnVsbCAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBuYXYgKi99XHJcbiAgICAgIDxuYXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIHB4LTNcIj5cclxuICAgICAgICB7TkFWLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgYWN0aXZlID0gdGFiID09PSBpdGVtLmlkO1xyXG4gICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPG1vdGlvbi5idXR0b25cclxuICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XHJcbiAgICAgICAgICAgICAgd2hpbGVUYXA9e3sgc2NhbGU6IDAuOTcgfX1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWIoaXRlbS5pZCl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgcmVsYXRpdmUgZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQteGwgcHgtMy41IHB5LTIuNSB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgIGFjdGl2ZSA/IFwiYmctaW5rLTgwMFwiIDogXCJob3ZlcjpiZy1pbmstODUwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICBhcmlhLWN1cnJlbnQ9e2FjdGl2ZSA/IFwicGFnZVwiIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2FjdGl2ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8bW90aW9uLnNwYW5cclxuICAgICAgICAgICAgICAgICAgbGF5b3V0SWQ9XCJzaWRlYmFyLW5vdGNoXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0wIHRvcC0xLzIgaC03IHctWzNweF0gLXRyYW5zbGF0ZS15LTEvMiByb3VuZGVkLXItZnVsbCBiZy12b2x0LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi1jb2xvcnMgJHthY3RpdmUgPyBcInRleHQtdm9sdC00MDBcIiA6IFwidGV4dC1mb2ctbXV0ZSBncm91cC1ob3Zlcjp0ZXh0LWZvZy1kaW1cIn1gfT5cclxuICAgICAgICAgICAgICAgIHtpdGVtLmljb24oeyBzaXplOiAxOSB9KX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGJsb2NrIHRleHQtWzEzcHhdIGZvbnQtYm9sZCAke2FjdGl2ZSA/IFwidGV4dC1mb2dcIiA6IFwidGV4dC1mb2ctZGltIGdyb3VwLWhvdmVyOnRleHQtZm9nXCJ9YH0+XHJcbiAgICAgICAgICAgICAgICAgIHtpdGVtLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjEyZW1dIHRleHQtZm9nLW11dGVcIj57aXRlbS5oaW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvbW90aW9uLmJ1dHRvbj5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvbmF2PlxyXG5cclxuICAgICAgey8qIENUQSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC01IHB0LTVcIj5cclxuICAgICAgICA8bW90aW9uLmJ1dHRvblxyXG4gICAgICAgICAgd2hpbGVUYXA9e3sgc2NhbGU6IDAuOTYgfX1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0R2VuRm9jdXMobnVsbCk7XHJcbiAgICAgICAgICAgIHNldFRhYihcInJvdGluYXNcIik7XHJcbiAgICAgICAgICAgIHdpbmRvdy5zZXRUaW1lb3V0KFxyXG4gICAgICAgICAgICAgICgpID0+XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImdlbmVyYXRvci1jYXJkXCIpPy5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiBcInNtb290aFwiLCBibG9jazogXCJjZW50ZXJcIiB9KSxcclxuICAgICAgICAgICAgICA4MFxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLXZvbHQtNDAwIHB5LTMgZm9udC1kaXNwbGF5IHRleHQtc20gdXBwZXJjYXNlIHRyYWNraW5nLVswLjA2ZW1dIHRleHQtaW5rLTk1MCBzaGFkb3ctWzBfOHB4XzI2cHhfcmdiYSgyMTIsMjQ1LDYwLDAuMjgpXSB0cmFuc2l0aW9uLXNoYWRvdyBob3ZlcjpzaGFkb3ctWzBfMTBweF8zNHB4X3JnYmEoMjEyLDI0NSw2MCwwLjQpXVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEljb25Cb2x0IHNpemU9ezE2fSBzdHJva2VXaWR0aD17Mi40fSAvPiBHZXJhciB0cmVpbm8gZG8gZGlhXHJcbiAgICAgICAgPC9tb3Rpb24uYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBmb2N1c2VkIHNwb3J0cyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1pbi1oLTAgZmxleC0xIG92ZXJmbG93LXktYXV0byBweC02XCI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjIyZW1dIHRleHQtZm9nLW11dGVcIj5ObyBmb2NvPC9wPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBzcGFjZS15LTEuNVwiPlxyXG4gICAgICAgICAge3Byb2ZpbGUuc3BvcnRzLm1hcCgoaWQpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgcyA9IHNwb3J0QnlJZChpZCk7XHJcbiAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAga2V5PXtpZH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWluay04MDAgYmctaW5rLTg1MC83MCBweC0yLjUgcHktMiB0cmFuc2l0aW9uLWNvbG9ycyBob3Zlcjpib3JkZXItaW5rLTYwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3JpZCBoLTcgdy03IHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLW1kXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogYCR7cy5jb2xvcn0xYWAsIGNvbG9yOiBzLmNvbG9yIH19PlxyXG4gICAgICAgICAgICAgICAgICA8U3BvcnRJY29uIGlkPXtpZH0gc2l6ZT17MTV9IC8+XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4LTEgdHJ1bmNhdGUgdGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtZm9nLWRpbVwiPntzLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC0xLjUgdy0xLjUgcm91bmRlZC1mdWxsIGJsaW5rLWRvdFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IHMuY29sb3IgfX0gLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiB1c2VyICovfVxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGFiKFwicGVyZmlsXCIpfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cIm0tMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItaW5rLTgwMCBiZy1pbmstODUwLzgwIHB4LTMgcHktMyB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6Ym9yZGVyLWluay02MDBcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3JpZCBoLTkgdy05IHNocmluay0wIHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLWxnIGJnLXZvbHQtNDAwLzE1IGZvbnQtZGlzcGxheSB0ZXh0LWJhc2UgdGV4dC12b2x0LTQwMCByaW5nLTEgcmluZy12b2x0LTQwMC8zMFwiPlxyXG4gICAgICAgICAgeyhwcm9maWxlLm5hbWUgfHwgXCJBXCIpWzBdLnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRydW5jYXRlIHRleHQtWzEzcHhdIGZvbnQtYm9sZCB0ZXh0LWZvZ1wiPntwcm9maWxlLm5hbWUgfHwgXCJBdGxldGFcIn08L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTRlbV0gdGV4dC1mb2ctbXV0ZVwiPlxyXG4gICAgICAgICAgICB7cHJvZmlsZS5zcG9ydHMubGVuZ3RofSBlc3BvcnRle3Byb2ZpbGUuc3BvcnRzLmxlbmd0aCA9PT0gMSA/IFwiXCIgOiBcInNcIn0gYXRpdm97cHJvZmlsZS5zcG9ydHMubGVuZ3RoID09PSAxID8gXCJcIiA6IFwic1wifVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2FzaWRlPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9sdWl6ci9PbmVEcml2ZS9Eb2N1bWVudG9zL3Byb2dyYW1hcy1naXQvdWx0cmEtZXhlcmNpc2VzL3VsdHJhLWV4ZXJjaXNlcy9zcmMvY29tcG9uZW50cy9TaWRlYmFyLnRzeCJ9