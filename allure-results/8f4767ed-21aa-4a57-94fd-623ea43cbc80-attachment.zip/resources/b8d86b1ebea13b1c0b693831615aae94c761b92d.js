export const SPORTS = [
  {
    id: "futebol",
    name: "Futebol",
    tag: "Arrancada, mudança de direção e resistência de jogo",
    color: "#34d97b",
    demands: ["Sprints repetidos", "Unilateral de pernas", "Prevenção de isquiotibiais"]
  },
  {
    id: "boxe",
    name: "Boxe",
    tag: "Potência de golpe, tronco rígido e gás anaeróbio",
    color: "#ff5148",
    demands: ["Rotação explosiva", "Ombros que aguentam rounds", "Core de transferência"]
  },
  {
    id: "jiu-jitsu",
    name: "Jiu-Jitsu",
    tag: "Pegada, controle de quadril e força isométrica",
    color: "#5b8cff",
    demands: ["Puxada e pegada", "Quadril dominante", "Força em ângulos estranhos"]
  },
  {
    id: "basquete",
    name: "Basquete",
    tag: "Salto vertical, aceleração e aterrissagem",
    color: "#ff8a2a",
    demands: ["Impulsão reativa", "Absorção de impacto", "Troca de direção"]
  },
  {
    id: "volei",
    name: "Vôlei",
    tag: "Impulsão, ombro resistente e defesa lateral",
    color: "#ffd23d",
    demands: ["Salto repetido", "Manguito blindado", "Reação lateral"]
  },
  {
    id: "corrida",
    name: "Corrida",
    tag: "Economia de passada e blindagem de posteriores",
    color: "#ff6fb2",
    demands: ["Posterior de ferro", "Rigidez de panturrilha", "Estabilidade de quadril"]
  },
  {
    id: "natacao",
    name: "Natação",
    tag: "Dorsais potentes, core de rotação e ombro saudável",
    color: "#38cfe0",
    demands: ["Puxada subaquática", "Rotação de tronco", "Estabilidade escapular"]
  },
  {
    id: "tenis",
    name: "Tênis",
    tag: "Rotação de tronco, pernas elásticas e frenagem",
    color: "#b8f04a",
    demands: ["Frenagem excêntrica", "Cadeia rotacional", "Passada lateral"]
  }
];
export const sportById = (id) => SPORTS.find((s) => s.id === id) ?? SPORTS[0];

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNwb3J0cy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFNwb3J0IH0gZnJvbSBcIi4uL3R5cGVzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgU1BPUlRTOiBTcG9ydFtdID0gW1xyXG4gIHtcclxuICAgIGlkOiBcImZ1dGVib2xcIixcclxuICAgIG5hbWU6IFwiRnV0ZWJvbFwiLFxyXG4gICAgdGFnOiBcIkFycmFuY2FkYSwgbXVkYW7Dp2EgZGUgZGlyZcOnw6NvIGUgcmVzaXN0w6puY2lhIGRlIGpvZ29cIixcclxuICAgIGNvbG9yOiBcIiMzNGQ5N2JcIixcclxuICAgIGRlbWFuZHM6IFtcIlNwcmludHMgcmVwZXRpZG9zXCIsIFwiVW5pbGF0ZXJhbCBkZSBwZXJuYXNcIiwgXCJQcmV2ZW7Dp8OjbyBkZSBpc3F1aW90aWJpYWlzXCJdLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiYm94ZVwiLFxyXG4gICAgbmFtZTogXCJCb3hlXCIsXHJcbiAgICB0YWc6IFwiUG90w6puY2lhIGRlIGdvbHBlLCB0cm9uY28gcsOtZ2lkbyBlIGfDoXMgYW5hZXLDs2Jpb1wiLFxyXG4gICAgY29sb3I6IFwiI2ZmNTE0OFwiLFxyXG4gICAgZGVtYW5kczogW1wiUm90YcOnw6NvIGV4cGxvc2l2YVwiLCBcIk9tYnJvcyBxdWUgYWd1ZW50YW0gcm91bmRzXCIsIFwiQ29yZSBkZSB0cmFuc2ZlcsOqbmNpYVwiXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcImppdS1qaXRzdVwiLFxyXG4gICAgbmFtZTogXCJKaXUtSml0c3VcIixcclxuICAgIHRhZzogXCJQZWdhZGEsIGNvbnRyb2xlIGRlIHF1YWRyaWwgZSBmb3LDp2EgaXNvbcOpdHJpY2FcIixcclxuICAgIGNvbG9yOiBcIiM1YjhjZmZcIixcclxuICAgIGRlbWFuZHM6IFtcIlB1eGFkYSBlIHBlZ2FkYVwiLCBcIlF1YWRyaWwgZG9taW5hbnRlXCIsIFwiRm9yw6dhIGVtIMOibmd1bG9zIGVzdHJhbmhvc1wiXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcImJhc3F1ZXRlXCIsXHJcbiAgICBuYW1lOiBcIkJhc3F1ZXRlXCIsXHJcbiAgICB0YWc6IFwiU2FsdG8gdmVydGljYWwsIGFjZWxlcmHDp8OjbyBlIGF0ZXJyaXNzYWdlbVwiLFxyXG4gICAgY29sb3I6IFwiI2ZmOGEyYVwiLFxyXG4gICAgZGVtYW5kczogW1wiSW1wdWxzw6NvIHJlYXRpdmFcIiwgXCJBYnNvcsOnw6NvIGRlIGltcGFjdG9cIiwgXCJUcm9jYSBkZSBkaXJlw6fDo29cIl0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCJ2b2xlaVwiLFxyXG4gICAgbmFtZTogXCJWw7RsZWlcIixcclxuICAgIHRhZzogXCJJbXB1bHPDo28sIG9tYnJvIHJlc2lzdGVudGUgZSBkZWZlc2EgbGF0ZXJhbFwiLFxyXG4gICAgY29sb3I6IFwiI2ZmZDIzZFwiLFxyXG4gICAgZGVtYW5kczogW1wiU2FsdG8gcmVwZXRpZG9cIiwgXCJNYW5ndWl0byBibGluZGFkb1wiLCBcIlJlYcOnw6NvIGxhdGVyYWxcIl0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCJjb3JyaWRhXCIsXHJcbiAgICBuYW1lOiBcIkNvcnJpZGFcIixcclxuICAgIHRhZzogXCJFY29ub21pYSBkZSBwYXNzYWRhIGUgYmxpbmRhZ2VtIGRlIHBvc3RlcmlvcmVzXCIsXHJcbiAgICBjb2xvcjogXCIjZmY2ZmIyXCIsXHJcbiAgICBkZW1hbmRzOiBbXCJQb3N0ZXJpb3IgZGUgZmVycm9cIiwgXCJSaWdpZGV6IGRlIHBhbnR1cnJpbGhhXCIsIFwiRXN0YWJpbGlkYWRlIGRlIHF1YWRyaWxcIl0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCJuYXRhY2FvXCIsXHJcbiAgICBuYW1lOiBcIk5hdGHDp8Ojb1wiLFxyXG4gICAgdGFnOiBcIkRvcnNhaXMgcG90ZW50ZXMsIGNvcmUgZGUgcm90YcOnw6NvIGUgb21icm8gc2F1ZMOhdmVsXCIsXHJcbiAgICBjb2xvcjogXCIjMzhjZmUwXCIsXHJcbiAgICBkZW1hbmRzOiBbXCJQdXhhZGEgc3ViYXF1w6F0aWNhXCIsIFwiUm90YcOnw6NvIGRlIHRyb25jb1wiLCBcIkVzdGFiaWxpZGFkZSBlc2NhcHVsYXJcIl0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCJ0ZW5pc1wiLFxyXG4gICAgbmFtZTogXCJUw6puaXNcIixcclxuICAgIHRhZzogXCJSb3Rhw6fDo28gZGUgdHJvbmNvLCBwZXJuYXMgZWzDoXN0aWNhcyBlIGZyZW5hZ2VtXCIsXHJcbiAgICBjb2xvcjogXCIjYjhmMDRhXCIsXHJcbiAgICBkZW1hbmRzOiBbXCJGcmVuYWdlbSBleGPDqm50cmljYVwiLCBcIkNhZGVpYSByb3RhY2lvbmFsXCIsIFwiUGFzc2FkYSBsYXRlcmFsXCJdLFxyXG4gIH0sXHJcbl07XHJcblxyXG5leHBvcnQgY29uc3Qgc3BvcnRCeUlkID0gKGlkOiBzdHJpbmcpOiBTcG9ydCA9PlxyXG4gIFNQT1JUUy5maW5kKChzKSA9PiBzLmlkID09PSBpZCkgPz8gU1BPUlRTWzBdO1xyXG4iXSwibWFwcGluZ3MiOiJBQUVPLGFBQU0sU0FBa0I7QUFBQSxFQUM3QjtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osTUFBTTtBQUFBLElBQ04sS0FBSztBQUFBLElBQ0wsT0FBTztBQUFBLElBQ1AsU0FBUyxDQUFDLHFCQUFxQix3QkFBd0IsNEJBQTRCO0FBQUEsRUFDckY7QUFBQSxFQUNBO0FBQUEsSUFDRSxJQUFJO0FBQUEsSUFDSixNQUFNO0FBQUEsSUFDTixLQUFLO0FBQUEsSUFDTCxPQUFPO0FBQUEsSUFDUCxTQUFTLENBQUMscUJBQXFCLDhCQUE4Qix1QkFBdUI7QUFBQSxFQUN0RjtBQUFBLEVBQ0E7QUFBQSxJQUNFLElBQUk7QUFBQSxJQUNKLE1BQU07QUFBQSxJQUNOLEtBQUs7QUFBQSxJQUNMLE9BQU87QUFBQSxJQUNQLFNBQVMsQ0FBQyxtQkFBbUIscUJBQXFCLDRCQUE0QjtBQUFBLEVBQ2hGO0FBQUEsRUFDQTtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osTUFBTTtBQUFBLElBQ04sS0FBSztBQUFBLElBQ0wsT0FBTztBQUFBLElBQ1AsU0FBUyxDQUFDLG9CQUFvQix1QkFBdUIsa0JBQWtCO0FBQUEsRUFDekU7QUFBQSxFQUNBO0FBQUEsSUFDRSxJQUFJO0FBQUEsSUFDSixNQUFNO0FBQUEsSUFDTixLQUFLO0FBQUEsSUFDTCxPQUFPO0FBQUEsSUFDUCxTQUFTLENBQUMsa0JBQWtCLHFCQUFxQixnQkFBZ0I7QUFBQSxFQUNuRTtBQUFBLEVBQ0E7QUFBQSxJQUNFLElBQUk7QUFBQSxJQUNKLE1BQU07QUFBQSxJQUNOLEtBQUs7QUFBQSxJQUNMLE9BQU87QUFBQSxJQUNQLFNBQVMsQ0FBQyxzQkFBc0IsMEJBQTBCLHlCQUF5QjtBQUFBLEVBQ3JGO0FBQUEsRUFDQTtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osTUFBTTtBQUFBLElBQ04sS0FBSztBQUFBLElBQ0wsT0FBTztBQUFBLElBQ1AsU0FBUyxDQUFDLHNCQUFzQixxQkFBcUIsd0JBQXdCO0FBQUEsRUFDL0U7QUFBQSxFQUNBO0FBQUEsSUFDRSxJQUFJO0FBQUEsSUFDSixNQUFNO0FBQUEsSUFDTixLQUFLO0FBQUEsSUFDTCxPQUFPO0FBQUEsSUFDUCxTQUFTLENBQUMsdUJBQXVCLHFCQUFxQixpQkFBaUI7QUFBQSxFQUN6RTtBQUNGO0FBRU8sYUFBTSxZQUFZLENBQUMsT0FDeEIsT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLE9BQU8sQ0FBQzsiLCJuYW1lcyI6W119