import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Logo.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8a41314"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Logo.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import logoUrl from "/src/assets/logo-ultra.png?import";
export function Logo({ size = 40, full = false }) {
  if (full) {
    return /* @__PURE__ */ jsxDEV(
      "img",
      {
        src: logoUrl,
        alt: "Ultra Exercises",
        className: "h-auto w-full rounded-xl border border-ink-700 object-contain"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Logo.tsx",
        lineNumber: 32,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV(
    "img",
    {
      src: logoUrl,
      alt: "Ultra Exercises",
      width: Math.round(size * 1.5),
      height: size,
      style: { width: Math.round(size * 1.5), height: size },
      className: "shrink-0 rounded-lg border border-ink-700 object-cover"
    },
    void 0,
    false,
    {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Logo.tsx",
      lineNumber: 40,
      columnNumber: 5
    },
    this
  );
}
_c = Logo;
export default Logo;
var _c;
$RefreshReg$(_c, "Logo");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Logo.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Logo.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFaTixPQUFPQSxhQUFhO0FBU2IsZ0JBQVNDLEtBQUssRUFBRUMsT0FBTyxJQUFJQyxPQUFPLE1BQXlDLEdBQUc7QUFDbkYsTUFBSUEsTUFBTTtBQUNSLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLEtBQUtIO0FBQUFBLFFBQ0wsS0FBSTtBQUFBLFFBQ0osV0FBVTtBQUFBO0FBQUEsTUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHMkU7QUFBQSxFQUcvRTtBQUNBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEtBQUtBO0FBQUFBLE1BQ0wsS0FBSTtBQUFBLE1BQ0osT0FBT0ksS0FBS0MsTUFBTUgsT0FBTyxHQUFHO0FBQUEsTUFDNUIsUUFBUUE7QUFBQUEsTUFDUixPQUFPLEVBQUVJLE9BQU9GLEtBQUtDLE1BQU1ILE9BQU8sR0FBRyxHQUFHSyxRQUFRTCxLQUFLO0FBQUEsTUFDckQsV0FBVTtBQUFBO0FBQUEsSUFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNb0U7QUFHeEU7QUFBQ00sS0FwQmVQO0FBc0JoQixlQUFlQTtBQUFLLElBQUFPO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImxvZ29VcmwiLCJMb2dvIiwic2l6ZSIsImZ1bGwiLCJNYXRoIiwicm91bmQiLCJ3aWR0aCIsImhlaWdodCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxvZ28udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBsb2dvVXJsIGZyb20gXCIuLi9hc3NldHMvbG9nby11bHRyYS5wbmdcIjtcclxuXHJcbi8qKlxyXG4gKiBMb2dvbWFyY2EgVWx0cmEgRXhlcmNpc2VzLiBBIGFydGUgb3JpZ2luYWwgdGVtIGZ1bmRvIHByZXRvIGVtYnV0aWRvIOKAlFxyXG4gKiBvIGNvbnRhaW5lciBhcnJlZG9uZGFkbyBjb20gYm9yZGEgc3V0aWwgaW50ZWdyYSBvIHJlY29ydGUgYW8gdGVtYSBlc2N1cm8uXHJcbiAqXHJcbiAqIC0gYHNpemVgOiBhbHR1cmEgZml4YSwgbGFyZ3VyYSBwcm9wb3JjaW9uYWwgKDM6Mikg4oCUIHBhcmEgbGluaGFzIGNvbSB0ZXh0byBhbyBsYWRvLlxyXG4gKiAtIGBmdWxsYDogb2N1cGEgdG9kYSBhIGxhcmd1cmEgZG8gY29udGFpbmVyIHBhaSDigJQgYmFubmVyIGRlIG1hcmNhIChzaWRlYmFyKS5cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBMb2dvKHsgc2l6ZSA9IDQwLCBmdWxsID0gZmFsc2UgfTogeyBzaXplPzogbnVtYmVyOyBmdWxsPzogYm9vbGVhbiB9KSB7XHJcbiAgaWYgKGZ1bGwpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxpbWdcclxuICAgICAgICBzcmM9e2xvZ29Vcmx9XHJcbiAgICAgICAgYWx0PVwiVWx0cmEgRXhlcmNpc2VzXCJcclxuICAgICAgICBjbGFzc05hbWU9XCJoLWF1dG8gdy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1pbmstNzAwIG9iamVjdC1jb250YWluXCJcclxuICAgICAgLz5cclxuICAgICk7XHJcbiAgfVxyXG4gIHJldHVybiAoXHJcbiAgICA8aW1nXHJcbiAgICAgIHNyYz17bG9nb1VybH1cclxuICAgICAgYWx0PVwiVWx0cmEgRXhlcmNpc2VzXCJcclxuICAgICAgd2lkdGg9e01hdGgucm91bmQoc2l6ZSAqIDEuNSl9XHJcbiAgICAgIGhlaWdodD17c2l6ZX1cclxuICAgICAgc3R5bGU9e3sgd2lkdGg6IE1hdGgucm91bmQoc2l6ZSAqIDEuNSksIGhlaWdodDogc2l6ZSB9fVxyXG4gICAgICBjbGFzc05hbWU9XCJzaHJpbmstMCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItaW5rLTcwMCBvYmplY3QtY292ZXJcIlxyXG4gICAgLz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMb2dvO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL2x1aXpyL09uZURyaXZlL0RvY3VtZW50b3MvcHJvZ3JhbWFzLWdpdC91bHRyYS1leGVyY2lzZXMvdWx0cmEtZXhlcmNpc2VzL3NyYy9jb21wb25lbnRzL0xvZ28udHN4In0=