import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/store.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8a41314"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/store.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=a8a41314"; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]





;
import { api, ApiError } from "/src/api.ts";
import { CACHE_TTL, clearCache, dedupeFetch, getCachedOrStale, invalidate, setCache, userCacheKey } from "/src/cache.ts";
function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
const Ctx = createContext(null);
export function AppProvider({ children }) {
  _s();
  const [profile, setProfile] = useState(() => {
    const local = load("forja:profile:v1", { name: "", sports: [], onboarded: false });
    const token2 = localStorage.getItem("forja:token:v1");
    if (token2) {
      const cached = getCachedOrStale(userCacheKey(token2), "me");
      if (cached) {
        return { name: cached.value.name ?? "", sports: cached.value.sports.map((s) => s.code), onboarded: cached.value.sports.length > 0 };
      }
    }
    return local;
  });
  const [tab, setTab] = useState("explorar");
  const [playerId, setPlayerId] = useState(null);
  const [genFocus, setGenFocus] = useState(null);
  const [toasts, setToasts] = useState([]);
  const [token, setToken] = useState(() => localStorage.getItem("forja:token:v1"));
  const [pendingChallenge, setPendingChallenge] = useState(null);
  const [authLoading, setAuthLoading] = useState(() => {
    const stored = localStorage.getItem("forja:token:v1");
    return stored ? !getCachedOrStale(userCacheKey(stored), "me") : false;
  });
  useEffect(() => {
    localStorage.setItem("forja:profile:v1", JSON.stringify(profile));
  }, [profile]);
  useEffect(() => {
    if (!token) return;
    const userKey = userCacheKey(token);
    dedupeFetch(userKey, "me", () => api.me(token)).then((remote) => {
      setCache(userKey, "me", remote, CACHE_TTL.profile);
      setProfile({ name: remote.name ?? "", sports: remote.sports.map((s) => s.code), onboarded: remote.sports.length > 0 });
    }).catch((err) => {
      const expired = err instanceof ApiError && err.status === 401;
      if (expired) clearCache();
      if (expired || !getCachedOrStale(userKey, "me")) {
        localStorage.removeItem("forja:token:v1");
        setToken(null);
      }
    }).finally(() => setAuthLoading(false));
  }, [token]);
  const toast = useCallback((msg, color) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, msg, tone: color ? "sport" : "volt", color }]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2400);
  }, []);
  const authenticate = useCallback(async (mode, email, password, name) => {
    const response = mode === "login" ? await api.login(email, password) : await api.register(email, password, name);
    if (response.mfaRequired && response.challengeToken) {
      setPendingChallenge(response.challengeToken);
      return;
    }
    if (!response.token) throw new Error("Não foi possível entrar.");
    clearCache();
    setAuthLoading(true);
    localStorage.setItem("forja:token:v1", response.token);
    setToken(response.token);
  }, []);
  const verifyChallenge = useCallback(async (code) => {
    if (!pendingChallenge) throw new Error("Sessão de verificação ausente. Entre novamente.");
    const response = await api.verifyTwoFactor(pendingChallenge, code);
    if (!response.token) throw new Error("Não foi possível concluir a entrada.");
    setPendingChallenge(null);
    clearCache();
    setAuthLoading(true);
    localStorage.setItem("forja:token:v1", response.token);
    setToken(response.token);
  }, [pendingChallenge]);
  const cancelChallenge = useCallback(() => setPendingChallenge(null), []);
  const logout = useCallback(() => {
    clearCache();
    localStorage.removeItem("forja:token:v1");
    setToken(null);
    setPendingChallenge(null);
    setAuthLoading(false);
    setProfile({ name: "", sports: [], onboarded: false });
    setTab("explorar");
  }, []);
  const completeOnboarding = useCallback(async (name, sports) => {
    if (!token) throw new Error("Sua sessão expirou. Entre novamente.");
    const remote = await api.saveProfile(token, name, sports);
    const userKey = userCacheKey(token);
    invalidate(userKey, /me/);
    setCache(userKey, "me", remote, CACHE_TTL.profile);
    setProfile({ name: remote.name ?? "", sports: remote.sports.map((s) => s.code), onboarded: true });
    setTab("explorar");
  }, [token]);
  const setName = useCallback((n) => setProfile((p) => ({ ...p, name: n })), []);
  const toggleSport = useCallback((id) => {
    setProfile((p) => {
      const has = p.sports.includes(id);
      if (has && p.sports.length === 1) return p;
      return { ...p, sports: has ? p.sports.filter((s) => s !== id) : [...p.sports, id] };
    });
  }, []);
  const resetAll = useCallback(() => {
    localStorage.removeItem("forja:profile:v1");
    setProfile({ name: "", sports: [], onboarded: false });
    setTab("explorar");
    setPlayerId(null);
  }, []);
  return /* @__PURE__ */ jsxDEV(
    Ctx.Provider,
    {
      value: {
        profile,
        token,
        authLoading,
        pendingChallenge,
        tab,
        playerId,
        toasts,
        genFocus,
        setGenFocus,
        setTab,
        openPlayer: setPlayerId,
        closePlayer: () => setPlayerId(null),
        toast,
        authenticate,
        verifyChallenge,
        cancelChallenge,
        logout,
        completeOnboarding,
        setName,
        toggleSport,
        resetAll
      },
      children
    },
    void 0,
    false,
    {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/store.tsx",
      lineNumber: 185,
      columnNumber: 5
    },
    this
  );
}
_s(AppProvider, "JarhnTjEDzYphnETbENsmrJZISs=");
_c = AppProvider;
export function useApp() {
  _s2();
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp fora do AppProvider");
  return ctx;
}
_s2(useApp, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
$RefreshReg$(_c, "AppProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/store.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/store.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUtJOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJLSjtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxTQUFTQyxLQUFLQyxnQkFBcUM7QUFDbkQsU0FBU0MsV0FBV0MsWUFBWUMsYUFBYUMsa0JBQWtCQyxZQUFZQyxVQUFVQyxvQkFBb0I7QUFTekcsU0FBU0MsS0FBUUMsS0FBYUMsVUFBZ0I7QUFDNUMsTUFBSTtBQUNGLFVBQU1DLE1BQU1DLGFBQWFDLFFBQVFKLEdBQUc7QUFDcEMsV0FBT0UsTUFBT0csS0FBS0MsTUFBTUosR0FBRyxJQUFVRDtBQUFBQSxFQUN4QyxRQUFRO0FBQ04sV0FBT0E7QUFBQUEsRUFDVDtBQUNGO0FBMEJBLE1BQU1NLE1BQU10QixjQUErQixJQUFJO0FBRXhDLGdCQUFTdUIsWUFBWSxFQUFFQyxTQUF3QyxHQUFHO0FBQUFDLEtBQUE7QUFDdkUsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUl2QixTQUFzQixNQUFNO0FBQ3hELFVBQU13QixRQUFRZCxLQUFLLG9CQUFvQixFQUFFZSxNQUFNLElBQUlDLFFBQVEsSUFBZ0JDLFdBQVcsTUFBTSxDQUFDO0FBQzdGLFVBQU1DLFNBQVFkLGFBQWFDLFFBQVEsZ0JBQWdCO0FBQ25ELFFBQUlhLFFBQU87QUFDVCxZQUFNQyxTQUFTdkIsaUJBQWlDRyxhQUFhbUIsTUFBSyxHQUFHLElBQUk7QUFDekUsVUFBSUMsUUFBUTtBQUNWLGVBQU8sRUFBRUosTUFBTUksT0FBT0MsTUFBTUwsUUFBUSxJQUFJQyxRQUFRRyxPQUFPQyxNQUFNSixPQUFPSyxJQUFJLENBQUNDLE1BQU1BLEVBQUVDLElBQUksR0FBR04sV0FBV0UsT0FBT0MsTUFBTUosT0FBT1EsU0FBUyxFQUFFO0FBQUEsTUFDcEk7QUFBQSxJQUNGO0FBQ0EsV0FBT1Y7QUFBQUEsRUFDVCxDQUFDO0FBQ0QsUUFBTSxDQUFDVyxLQUFLQyxNQUFNLElBQUlwQyxTQUFjLFVBQVU7QUFDOUMsUUFBTSxDQUFDcUMsVUFBVUMsV0FBVyxJQUFJdEMsU0FBd0IsSUFBSTtBQUM1RCxRQUFNLENBQUN1QyxVQUFVQyxXQUFXLElBQUl4QyxTQUF3QixJQUFJO0FBQzVELFFBQU0sQ0FBQ3lDLFFBQVFDLFNBQVMsSUFBSTFDLFNBQWtCLEVBQUU7QUFDaEQsUUFBTSxDQUFDNEIsT0FBT2UsUUFBUSxJQUFJM0MsU0FBd0IsTUFBTWMsYUFBYUMsUUFBUSxnQkFBZ0IsQ0FBQztBQUM5RixRQUFNLENBQUM2QixrQkFBa0JDLG1CQUFtQixJQUFJN0MsU0FBd0IsSUFBSTtBQUM1RSxRQUFNLENBQUM4QyxhQUFhQyxjQUFjLElBQUkvQyxTQUFTLE1BQU07QUFDbkQsVUFBTWdELFNBQVNsQyxhQUFhQyxRQUFRLGdCQUFnQjtBQUNwRCxXQUFPaUMsU0FBUyxDQUFDMUMsaUJBQWlDRyxhQUFhdUMsTUFBTSxHQUFHLElBQUksSUFBSTtBQUFBLEVBQ2xGLENBQUM7QUFFRGpELFlBQVUsTUFBTTtBQUNkZSxpQkFBYW1DLFFBQVEsb0JBQW9CakMsS0FBS2tDLFVBQVU1QixPQUFPLENBQUM7QUFBQSxFQUNsRSxHQUFHLENBQUNBLE9BQU8sQ0FBQztBQUNadkIsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDNkIsTUFBTztBQUNaLFVBQU11QixVQUFVMUMsYUFBYW1CLEtBQUs7QUFDbEN2QixnQkFBWThDLFNBQVMsTUFBTSxNQUFNbEQsSUFBSW1ELEdBQUd4QixLQUFLLENBQUMsRUFBRXlCLEtBQUssQ0FBQ0MsV0FBVztBQUMvRDlDLGVBQVMyQyxTQUFTLE1BQU1HLFFBQVFuRCxVQUFVbUIsT0FBTztBQUNqREMsaUJBQVcsRUFBRUUsTUFBTTZCLE9BQU83QixRQUFRLElBQUlDLFFBQVE0QixPQUFPNUIsT0FBT0ssSUFBSSxDQUFDQyxNQUFNQSxFQUFFQyxJQUFJLEdBQUdOLFdBQVcyQixPQUFPNUIsT0FBT1EsU0FBUyxFQUFFLENBQUM7QUFBQSxJQUN2SCxDQUFDLEVBQUVxQixNQUFNLENBQUNDLFFBQVE7QUFHaEIsWUFBTUMsVUFBVUQsZUFBZXRELFlBQVlzRCxJQUFJRSxXQUFXO0FBQzFELFVBQUlELFFBQVNyRCxZQUFXO0FBQ3hCLFVBQUlxRCxXQUFXLENBQUNuRCxpQkFBaUM2QyxTQUFTLElBQUksR0FBRztBQUMvRHJDLHFCQUFhNkMsV0FBVyxnQkFBZ0I7QUFBR2hCLGlCQUFTLElBQUk7QUFBQSxNQUMxRDtBQUFBLElBQ0YsQ0FBQyxFQUFFaUIsUUFBUSxNQUFNYixlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3hDLEdBQUcsQ0FBQ25CLEtBQUssQ0FBQztBQUVWLFFBQU1pQyxRQUFRaEUsWUFBWSxDQUFDaUUsS0FBYUMsVUFBbUI7QUFDekQsVUFBTUMsS0FBS0MsS0FBS0MsSUFBSSxJQUFJQyxLQUFLQyxPQUFPO0FBQ3BDMUIsY0FBVSxDQUFDMkIsTUFBTSxDQUFDLEdBQUdBLEVBQUVDLE1BQU0sRUFBRSxHQUFHLEVBQUVOLElBQUlGLEtBQUtTLE1BQU1SLFFBQVEsVUFBVSxRQUFRQSxNQUFNLENBQUMsQ0FBQztBQUNyRlMsV0FBT0MsV0FBVyxNQUFNL0IsVUFBVSxDQUFDMkIsTUFBTUEsRUFBRUssT0FBTyxDQUFDQyxNQUFNQSxFQUFFWCxPQUFPQSxFQUFFLENBQUMsR0FBRyxJQUFJO0FBQUEsRUFDOUUsR0FBRyxFQUFFO0FBRUwsUUFBTVksZUFBZS9FLFlBQVksT0FBT2dGLE1BQTRCQyxPQUFlQyxVQUFrQnRELFNBQWlCO0FBQ3BILFVBQU11RCxXQUFXSCxTQUFTLFVBQVUsTUFBTTVFLElBQUlnRixNQUFNSCxPQUFPQyxRQUFRLElBQUksTUFBTTlFLElBQUlpRixTQUFTSixPQUFPQyxVQUFVdEQsSUFBSTtBQUUvRyxRQUFJdUQsU0FBU0csZUFBZUgsU0FBU0ksZ0JBQWdCO0FBQ25EdkMsMEJBQW9CbUMsU0FBU0ksY0FBYztBQUMzQztBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUNKLFNBQVNwRCxNQUFPLE9BQU0sSUFBSXlELE1BQU0sMEJBQTBCO0FBQy9EakYsZUFBVztBQUNYMkMsbUJBQWUsSUFBSTtBQUNuQmpDLGlCQUFhbUMsUUFBUSxrQkFBa0IrQixTQUFTcEQsS0FBSztBQUNyRGUsYUFBU3FDLFNBQVNwRCxLQUFLO0FBQUEsRUFDekIsR0FBRyxFQUFFO0FBRUwsUUFBTTBELGtCQUFrQnpGLFlBQVksT0FBT29DLFNBQWlCO0FBQzFELFFBQUksQ0FBQ1csaUJBQWtCLE9BQU0sSUFBSXlDLE1BQU0saURBQWlEO0FBQ3hGLFVBQU1MLFdBQVcsTUFBTS9FLElBQUlzRixnQkFBZ0IzQyxrQkFBa0JYLElBQUk7QUFDakUsUUFBSSxDQUFDK0MsU0FBU3BELE1BQU8sT0FBTSxJQUFJeUQsTUFBTSxzQ0FBc0M7QUFDM0V4Qyx3QkFBb0IsSUFBSTtBQUN4QnpDLGVBQVc7QUFDWDJDLG1CQUFlLElBQUk7QUFDbkJqQyxpQkFBYW1DLFFBQVEsa0JBQWtCK0IsU0FBU3BELEtBQUs7QUFDckRlLGFBQVNxQyxTQUFTcEQsS0FBSztBQUFBLEVBQ3pCLEdBQUcsQ0FBQ2dCLGdCQUFnQixDQUFDO0FBRXJCLFFBQU00QyxrQkFBa0IzRixZQUFZLE1BQU1nRCxvQkFBb0IsSUFBSSxHQUFHLEVBQUU7QUFFdkUsUUFBTTRDLFNBQVM1RixZQUFZLE1BQU07QUFDL0JPLGVBQVc7QUFDWFUsaUJBQWE2QyxXQUFXLGdCQUFnQjtBQUFHaEIsYUFBUyxJQUFJO0FBQ3hERSx3QkFBb0IsSUFBSTtBQUN4QkUsbUJBQWUsS0FBSztBQUNwQnhCLGVBQVcsRUFBRUUsTUFBTSxJQUFJQyxRQUFRLElBQUlDLFdBQVcsTUFBTSxDQUFDO0FBQUdTLFdBQU8sVUFBVTtBQUFBLEVBQzNFLEdBQUcsRUFBRTtBQUVMLFFBQU1zRCxxQkFBcUI3RixZQUFZLE9BQU80QixNQUFjQyxXQUFxQjtBQUMvRSxRQUFJLENBQUNFLE1BQU8sT0FBTSxJQUFJeUQsTUFBTSxzQ0FBc0M7QUFDbEUsVUFBTS9CLFNBQVMsTUFBTXJELElBQUkwRixZQUFZL0QsT0FBT0gsTUFBTUMsTUFBTTtBQUN4RCxVQUFNeUIsVUFBVTFDLGFBQWFtQixLQUFLO0FBQ2xDckIsZUFBVzRDLFNBQVMsSUFBSTtBQUN4QjNDLGFBQVMyQyxTQUFTLE1BQU1HLFFBQVFuRCxVQUFVbUIsT0FBTztBQUNqREMsZUFBVyxFQUFFRSxNQUFNNkIsT0FBTzdCLFFBQVEsSUFBSUMsUUFBUTRCLE9BQU81QixPQUFPSyxJQUFJLENBQUNDLE1BQU1BLEVBQUVDLElBQUksR0FBR04sV0FBVyxLQUFLLENBQUM7QUFDakdTLFdBQU8sVUFBVTtBQUFBLEVBQ25CLEdBQUcsQ0FBQ1IsS0FBSyxDQUFDO0FBRVYsUUFBTWdFLFVBQVUvRixZQUFZLENBQUNnRyxNQUFjdEUsV0FBVyxDQUFDdUUsT0FBTyxFQUFFLEdBQUdBLEdBQUdyRSxNQUFNb0UsRUFBRSxFQUFFLEdBQUcsRUFBRTtBQUVyRixRQUFNRSxjQUFjbEcsWUFBWSxDQUFDbUUsT0FBZTtBQUM5Q3pDLGVBQVcsQ0FBQ3VFLE1BQU07QUFDaEIsWUFBTUUsTUFBTUYsRUFBRXBFLE9BQU91RSxTQUFTakMsRUFBRTtBQUNoQyxVQUFJZ0MsT0FBT0YsRUFBRXBFLE9BQU9RLFdBQVcsRUFBRyxRQUFPNEQ7QUFDekMsYUFBTyxFQUFFLEdBQUdBLEdBQUdwRSxRQUFRc0UsTUFBTUYsRUFBRXBFLE9BQU9nRCxPQUFPLENBQUMxQyxNQUFNQSxNQUFNZ0MsRUFBRSxJQUFJLENBQUMsR0FBRzhCLEVBQUVwRSxRQUFRc0MsRUFBRSxFQUFFO0FBQUEsSUFDcEYsQ0FBQztBQUFBLEVBQ0gsR0FBRyxFQUFFO0FBRUwsUUFBTWtDLFdBQVdyRyxZQUFZLE1BQU07QUFDakNpQixpQkFBYTZDLFdBQVcsa0JBQWtCO0FBQzFDcEMsZUFBVyxFQUFFRSxNQUFNLElBQUlDLFFBQVEsSUFBSUMsV0FBVyxNQUFNLENBQUM7QUFDckRTLFdBQU8sVUFBVTtBQUNqQkUsZ0JBQVksSUFBSTtBQUFBLEVBQ2xCLEdBQUcsRUFBRTtBQUVMLFNBQ0U7QUFBQSxJQUFDLElBQUk7QUFBQSxJQUFKO0FBQUEsTUFDQyxPQUFPO0FBQUEsUUFDTGhCO0FBQUFBLFFBQ0FNO0FBQUFBLFFBQ0FrQjtBQUFBQSxRQUNBRjtBQUFBQSxRQUNBVDtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBSTtBQUFBQSxRQUNBRjtBQUFBQSxRQUNBQztBQUFBQSxRQUNBSjtBQUFBQSxRQUNBK0QsWUFBWTdEO0FBQUFBLFFBQ1o4RCxhQUFhQSxNQUFNOUQsWUFBWSxJQUFJO0FBQUEsUUFDbkN1QjtBQUFBQSxRQUNBZTtBQUFBQSxRQUNBVTtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBRTtBQUFBQSxRQUNBRztBQUFBQSxRQUNBRztBQUFBQSxNQUNGO0FBQUEsTUFFQzlFO0FBQUFBO0FBQUFBLElBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTBCQTtBQUVKO0FBQUNDLEdBNUllRixhQUFXO0FBQUEsS0FBWEE7QUE4SVQsZ0JBQVNrRixTQUFtQjtBQUFBQyxNQUFBO0FBQ2pDLFFBQU1DLE1BQU16RyxXQUFXb0IsR0FBRztBQUMxQixNQUFJLENBQUNxRixJQUFLLE9BQU0sSUFBSWxCLE1BQU0sNEJBQTRCO0FBQ3RELFNBQU9rQjtBQUNUO0FBQUNELElBSmVELFFBQU07QUFBQSxJQUFBRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJhcGkiLCJBcGlFcnJvciIsIkNBQ0hFX1RUTCIsImNsZWFyQ2FjaGUiLCJkZWR1cGVGZXRjaCIsImdldENhY2hlZE9yU3RhbGUiLCJpbnZhbGlkYXRlIiwic2V0Q2FjaGUiLCJ1c2VyQ2FjaGVLZXkiLCJsb2FkIiwia2V5IiwiZmFsbGJhY2siLCJyYXciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwiQ3R4IiwiQXBwUHJvdmlkZXIiLCJjaGlsZHJlbiIsIl9zIiwicHJvZmlsZSIsInNldFByb2ZpbGUiLCJsb2NhbCIsIm5hbWUiLCJzcG9ydHMiLCJvbmJvYXJkZWQiLCJ0b2tlbiIsImNhY2hlZCIsInZhbHVlIiwibWFwIiwicyIsImNvZGUiLCJsZW5ndGgiLCJ0YWIiLCJzZXRUYWIiLCJwbGF5ZXJJZCIsInNldFBsYXllcklkIiwiZ2VuRm9jdXMiLCJzZXRHZW5Gb2N1cyIsInRvYXN0cyIsInNldFRvYXN0cyIsInNldFRva2VuIiwicGVuZGluZ0NoYWxsZW5nZSIsInNldFBlbmRpbmdDaGFsbGVuZ2UiLCJhdXRoTG9hZGluZyIsInNldEF1dGhMb2FkaW5nIiwic3RvcmVkIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsInVzZXJLZXkiLCJtZSIsInRoZW4iLCJyZW1vdGUiLCJjYXRjaCIsImVyciIsImV4cGlyZWQiLCJzdGF0dXMiLCJyZW1vdmVJdGVtIiwiZmluYWxseSIsInRvYXN0IiwibXNnIiwiY29sb3IiLCJpZCIsIkRhdGUiLCJub3ciLCJNYXRoIiwicmFuZG9tIiwidCIsInNsaWNlIiwidG9uZSIsIndpbmRvdyIsInNldFRpbWVvdXQiLCJmaWx0ZXIiLCJ4IiwiYXV0aGVudGljYXRlIiwibW9kZSIsImVtYWlsIiwicGFzc3dvcmQiLCJyZXNwb25zZSIsImxvZ2luIiwicmVnaXN0ZXIiLCJtZmFSZXF1aXJlZCIsImNoYWxsZW5nZVRva2VuIiwiRXJyb3IiLCJ2ZXJpZnlDaGFsbGVuZ2UiLCJ2ZXJpZnlUd29GYWN0b3IiLCJjYW5jZWxDaGFsbGVuZ2UiLCJsb2dvdXQiLCJjb21wbGV0ZU9uYm9hcmRpbmciLCJzYXZlUHJvZmlsZSIsInNldE5hbWUiLCJuIiwicCIsInRvZ2dsZVNwb3J0IiwiaGFzIiwiaW5jbHVkZXMiLCJyZXNldEFsbCIsIm9wZW5QbGF5ZXIiLCJjbG9zZVBsYXllciIsInVzZUFwcCIsIl9zMiIsImN0eCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInN0b3JlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHtcclxuICBjcmVhdGVDb250ZXh0LFxyXG4gIHVzZUNhbGxiYWNrLFxyXG4gIHVzZUNvbnRleHQsXHJcbiAgdXNlRWZmZWN0LFxyXG4gIHVzZVN0YXRlLFxyXG59IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgdHlwZSB7IFRhYiwgVXNlclByb2ZpbGUgfSBmcm9tIFwiLi90eXBlc1wiO1xyXG5pbXBvcnQgeyBhcGksIEFwaUVycm9yLCB0eXBlIEF0aGxldGVQcm9maWxlIH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IENBQ0hFX1RUTCwgY2xlYXJDYWNoZSwgZGVkdXBlRmV0Y2gsIGdldENhY2hlZE9yU3RhbGUsIGludmFsaWRhdGUsIHNldENhY2hlLCB1c2VyQ2FjaGVLZXkgfSBmcm9tIFwiLi9jYWNoZVwiO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBUb2FzdCB7XHJcbiAgaWQ6IG51bWJlcjtcclxuICBtc2c6IHN0cmluZztcclxuICB0b25lOiBcInZvbHRcIiB8IFwic3BvcnRcIjtcclxuICBjb2xvcj86IHN0cmluZztcclxufVxyXG5cclxuZnVuY3Rpb24gbG9hZDxUPihrZXk6IHN0cmluZywgZmFsbGJhY2s6IFQpOiBUIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmF3ID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgIHJldHVybiByYXcgPyAoSlNPTi5wYXJzZShyYXcpIGFzIFQpIDogZmFsbGJhY2s7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4gZmFsbGJhY2s7XHJcbiAgfVxyXG59XHJcblxyXG5pbnRlcmZhY2UgQXBwU3RvcmUge1xyXG4gIHRva2VuOiBzdHJpbmcgfCBudWxsO1xyXG4gIGF1dGhMb2FkaW5nOiBib29sZWFuO1xyXG4gIHBlbmRpbmdDaGFsbGVuZ2U6IHN0cmluZyB8IG51bGw7XHJcbiAgcHJvZmlsZTogVXNlclByb2ZpbGU7XHJcbiAgdGFiOiBUYWI7XHJcbiAgcGxheWVySWQ6IHN0cmluZyB8IG51bGw7XHJcbiAgdG9hc3RzOiBUb2FzdFtdO1xyXG4gIGdlbkZvY3VzOiBzdHJpbmcgfCBudWxsO1xyXG4gIHNldEdlbkZvY3VzOiAoczogc3RyaW5nIHwgbnVsbCkgPT4gdm9pZDtcclxuICBzZXRUYWI6ICh0OiBUYWIpID0+IHZvaWQ7XHJcbiAgb3BlblBsYXllcjogKGlkOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgY2xvc2VQbGF5ZXI6ICgpID0+IHZvaWQ7XHJcbiAgdG9hc3Q6IChtc2c6IHN0cmluZywgY29sb3I/OiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgYXV0aGVudGljYXRlOiAobW9kZTogXCJsb2dpblwiIHwgXCJyZWdpc3RlclwiLCBlbWFpbDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nLCBuYW1lOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD47XHJcbiAgdmVyaWZ5Q2hhbGxlbmdlOiAoY29kZTogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+O1xyXG4gIGNhbmNlbENoYWxsZW5nZTogKCkgPT4gdm9pZDtcclxuICBsb2dvdXQ6ICgpID0+IHZvaWQ7XHJcbiAgY29tcGxldGVPbmJvYXJkaW5nOiAobmFtZTogc3RyaW5nLCBzcG9ydHM6IHN0cmluZ1tdKSA9PiBQcm9taXNlPHZvaWQ+O1xyXG4gIHNldE5hbWU6IChuOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgdG9nZ2xlU3BvcnQ6IChpZDogc3RyaW5nKSA9PiB2b2lkO1xyXG4gIHJlc2V0QWxsOiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5jb25zdCBDdHggPSBjcmVhdGVDb250ZXh0PEFwcFN0b3JlIHwgbnVsbD4obnVsbCk7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQXBwUHJvdmlkZXIoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xyXG4gIGNvbnN0IFtwcm9maWxlLCBzZXRQcm9maWxlXSA9IHVzZVN0YXRlPFVzZXJQcm9maWxlPigoKSA9PiB7XHJcbiAgICBjb25zdCBsb2NhbCA9IGxvYWQoXCJmb3JqYTpwcm9maWxlOnYxXCIsIHsgbmFtZTogXCJcIiwgc3BvcnRzOiBbXSBhcyBzdHJpbmdbXSwgb25ib2FyZGVkOiBmYWxzZSB9KTtcclxuICAgIGNvbnN0IHRva2VuID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJmb3JqYTp0b2tlbjp2MVwiKTtcclxuICAgIGlmICh0b2tlbikge1xyXG4gICAgICBjb25zdCBjYWNoZWQgPSBnZXRDYWNoZWRPclN0YWxlPEF0aGxldGVQcm9maWxlPih1c2VyQ2FjaGVLZXkodG9rZW4pLCBcIm1lXCIpO1xyXG4gICAgICBpZiAoY2FjaGVkKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgbmFtZTogY2FjaGVkLnZhbHVlLm5hbWUgPz8gXCJcIiwgc3BvcnRzOiBjYWNoZWQudmFsdWUuc3BvcnRzLm1hcCgocykgPT4gcy5jb2RlKSwgb25ib2FyZGVkOiBjYWNoZWQudmFsdWUuc3BvcnRzLmxlbmd0aCA+IDAgfTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGxvY2FsO1xyXG4gIH0pO1xyXG4gIGNvbnN0IFt0YWIsIHNldFRhYl0gPSB1c2VTdGF0ZTxUYWI+KFwiZXhwbG9yYXJcIik7XHJcbiAgY29uc3QgW3BsYXllcklkLCBzZXRQbGF5ZXJJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbZ2VuRm9jdXMsIHNldEdlbkZvY3VzXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFt0b2FzdHMsIHNldFRvYXN0c10gPSB1c2VTdGF0ZTxUb2FzdFtdPihbXSk7XHJcbiAgY29uc3QgW3Rva2VuLCBzZXRUb2tlbl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPigoKSA9PiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImZvcmphOnRva2VuOnYxXCIpKTtcclxuICBjb25zdCBbcGVuZGluZ0NoYWxsZW5nZSwgc2V0UGVuZGluZ0NoYWxsZW5nZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbYXV0aExvYWRpbmcsIHNldEF1dGhMb2FkaW5nXSA9IHVzZVN0YXRlKCgpID0+IHtcclxuICAgIGNvbnN0IHN0b3JlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZm9yamE6dG9rZW46djFcIik7XHJcbiAgICByZXR1cm4gc3RvcmVkID8gIWdldENhY2hlZE9yU3RhbGU8QXRobGV0ZVByb2ZpbGU+KHVzZXJDYWNoZUtleShzdG9yZWQpLCBcIm1lXCIpIDogZmFsc2U7XHJcbiAgfSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImZvcmphOnByb2ZpbGU6djFcIiwgSlNPTi5zdHJpbmdpZnkocHJvZmlsZSkpO1xyXG4gIH0sIFtwcm9maWxlXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghdG9rZW4pIHJldHVybjtcclxuICAgIGNvbnN0IHVzZXJLZXkgPSB1c2VyQ2FjaGVLZXkodG9rZW4pO1xyXG4gICAgZGVkdXBlRmV0Y2godXNlcktleSwgXCJtZVwiLCAoKSA9PiBhcGkubWUodG9rZW4pKS50aGVuKChyZW1vdGUpID0+IHtcclxuICAgICAgc2V0Q2FjaGUodXNlcktleSwgXCJtZVwiLCByZW1vdGUsIENBQ0hFX1RUTC5wcm9maWxlKTtcclxuICAgICAgc2V0UHJvZmlsZSh7IG5hbWU6IHJlbW90ZS5uYW1lID8/IFwiXCIsIHNwb3J0czogcmVtb3RlLnNwb3J0cy5tYXAoKHMpID0+IHMuY29kZSksIG9uYm9hcmRlZDogcmVtb3RlLnNwb3J0cy5sZW5ndGggPiAwIH0pO1xyXG4gICAgfSkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICAvLyBTZXNzw6NvIGV4cGlyYWRhICg0MDEpOiBlbmNlcnJhIGEgc2Vzc8OjbyBtZXNtbyBjb20gcGVyZmlsIGVtIGNhY2hlLlxyXG4gICAgICAvLyBGYWxoYSBkZSByZWRlL3RpbWVvdXQ6IG1hbnTDqW0gbyBjYWNoZSBlIGEgc2Vzc8OjbyAobW9kbyBvZmZsaW5lIGFtaWfDoXZlbCkuXHJcbiAgICAgIGNvbnN0IGV4cGlyZWQgPSBlcnIgaW5zdGFuY2VvZiBBcGlFcnJvciAmJiBlcnIuc3RhdHVzID09PSA0MDE7XHJcbiAgICAgIGlmIChleHBpcmVkKSBjbGVhckNhY2hlKCk7XHJcbiAgICAgIGlmIChleHBpcmVkIHx8ICFnZXRDYWNoZWRPclN0YWxlPEF0aGxldGVQcm9maWxlPih1c2VyS2V5LCBcIm1lXCIpKSB7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJmb3JqYTp0b2tlbjp2MVwiKTsgc2V0VG9rZW4obnVsbCk7XHJcbiAgICAgIH1cclxuICAgIH0pLmZpbmFsbHkoKCkgPT4gc2V0QXV0aExvYWRpbmcoZmFsc2UpKTtcclxuICB9LCBbdG9rZW5dKTtcclxuXHJcbiAgY29uc3QgdG9hc3QgPSB1c2VDYWxsYmFjaygobXNnOiBzdHJpbmcsIGNvbG9yPzogc3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBpZCA9IERhdGUubm93KCkgKyBNYXRoLnJhbmRvbSgpO1xyXG4gICAgc2V0VG9hc3RzKCh0KSA9PiBbLi4udC5zbGljZSgtMiksIHsgaWQsIG1zZywgdG9uZTogY29sb3IgPyBcInNwb3J0XCIgOiBcInZvbHRcIiwgY29sb3IgfV0pO1xyXG4gICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0VG9hc3RzKCh0KSA9PiB0LmZpbHRlcigoeCkgPT4geC5pZCAhPT0gaWQpKSwgMjQwMCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBhdXRoZW50aWNhdGUgPSB1c2VDYWxsYmFjayhhc3luYyAobW9kZTogXCJsb2dpblwiIHwgXCJyZWdpc3RlclwiLCBlbWFpbDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nLCBuYW1lOiBzdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gbW9kZSA9PT0gXCJsb2dpblwiID8gYXdhaXQgYXBpLmxvZ2luKGVtYWlsLCBwYXNzd29yZCkgOiBhd2FpdCBhcGkucmVnaXN0ZXIoZW1haWwsIHBhc3N3b3JkLCBuYW1lKTtcclxuICAgIC8vIDJGQSBbVUUtMjRdOiBjcmVkZW5jaWFpcyBwcmltw6FyaWFzIHbDoWxpZGFzIOKGkiBlc3RhZG8gZGUgYXV0ZW50aWNhw6fDo28gcGFyY2lhbC5cclxuICAgIGlmIChyZXNwb25zZS5tZmFSZXF1aXJlZCAmJiByZXNwb25zZS5jaGFsbGVuZ2VUb2tlbikge1xyXG4gICAgICBzZXRQZW5kaW5nQ2hhbGxlbmdlKHJlc3BvbnNlLmNoYWxsZW5nZVRva2VuKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKCFyZXNwb25zZS50b2tlbikgdGhyb3cgbmV3IEVycm9yKFwiTsOjbyBmb2kgcG9zc8OtdmVsIGVudHJhci5cIik7XHJcbiAgICBjbGVhckNhY2hlKCk7XHJcbiAgICBzZXRBdXRoTG9hZGluZyh0cnVlKTtcclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiZm9yamE6dG9rZW46djFcIiwgcmVzcG9uc2UudG9rZW4pO1xyXG4gICAgc2V0VG9rZW4ocmVzcG9uc2UudG9rZW4pO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgdmVyaWZ5Q2hhbGxlbmdlID0gdXNlQ2FsbGJhY2soYXN5bmMgKGNvZGU6IHN0cmluZykgPT4ge1xyXG4gICAgaWYgKCFwZW5kaW5nQ2hhbGxlbmdlKSB0aHJvdyBuZXcgRXJyb3IoXCJTZXNzw6NvIGRlIHZlcmlmaWNhw6fDo28gYXVzZW50ZS4gRW50cmUgbm92YW1lbnRlLlwiKTtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnZlcmlmeVR3b0ZhY3RvcihwZW5kaW5nQ2hhbGxlbmdlLCBjb2RlKTtcclxuICAgIGlmICghcmVzcG9uc2UudG9rZW4pIHRocm93IG5ldyBFcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBjb25jbHVpciBhIGVudHJhZGEuXCIpO1xyXG4gICAgc2V0UGVuZGluZ0NoYWxsZW5nZShudWxsKTtcclxuICAgIGNsZWFyQ2FjaGUoKTtcclxuICAgIHNldEF1dGhMb2FkaW5nKHRydWUpO1xyXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJmb3JqYTp0b2tlbjp2MVwiLCByZXNwb25zZS50b2tlbik7XHJcbiAgICBzZXRUb2tlbihyZXNwb25zZS50b2tlbik7XHJcbiAgfSwgW3BlbmRpbmdDaGFsbGVuZ2VdKTtcclxuXHJcbiAgY29uc3QgY2FuY2VsQ2hhbGxlbmdlID0gdXNlQ2FsbGJhY2soKCkgPT4gc2V0UGVuZGluZ0NoYWxsZW5nZShudWxsKSwgW10pO1xyXG5cclxuICBjb25zdCBsb2dvdXQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBjbGVhckNhY2hlKCk7XHJcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcImZvcmphOnRva2VuOnYxXCIpOyBzZXRUb2tlbihudWxsKTtcclxuICAgIHNldFBlbmRpbmdDaGFsbGVuZ2UobnVsbCk7XHJcbiAgICBzZXRBdXRoTG9hZGluZyhmYWxzZSk7XHJcbiAgICBzZXRQcm9maWxlKHsgbmFtZTogXCJcIiwgc3BvcnRzOiBbXSwgb25ib2FyZGVkOiBmYWxzZSB9KTsgc2V0VGFiKFwiZXhwbG9yYXJcIik7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBjb21wbGV0ZU9uYm9hcmRpbmcgPSB1c2VDYWxsYmFjayhhc3luYyAobmFtZTogc3RyaW5nLCBzcG9ydHM6IHN0cmluZ1tdKSA9PiB7XHJcbiAgICBpZiAoIXRva2VuKSB0aHJvdyBuZXcgRXJyb3IoXCJTdWEgc2Vzc8OjbyBleHBpcm91LiBFbnRyZSBub3ZhbWVudGUuXCIpO1xyXG4gICAgY29uc3QgcmVtb3RlID0gYXdhaXQgYXBpLnNhdmVQcm9maWxlKHRva2VuLCBuYW1lLCBzcG9ydHMpO1xyXG4gICAgY29uc3QgdXNlcktleSA9IHVzZXJDYWNoZUtleSh0b2tlbik7XHJcbiAgICBpbnZhbGlkYXRlKHVzZXJLZXksIC9tZS8pO1xyXG4gICAgc2V0Q2FjaGUodXNlcktleSwgXCJtZVwiLCByZW1vdGUsIENBQ0hFX1RUTC5wcm9maWxlKTtcclxuICAgIHNldFByb2ZpbGUoeyBuYW1lOiByZW1vdGUubmFtZSA/PyBcIlwiLCBzcG9ydHM6IHJlbW90ZS5zcG9ydHMubWFwKChzKSA9PiBzLmNvZGUpLCBvbmJvYXJkZWQ6IHRydWUgfSk7XHJcbiAgICBzZXRUYWIoXCJleHBsb3JhclwiKTtcclxuICB9LCBbdG9rZW5dKTtcclxuXHJcbiAgY29uc3Qgc2V0TmFtZSA9IHVzZUNhbGxiYWNrKChuOiBzdHJpbmcpID0+IHNldFByb2ZpbGUoKHApID0+ICh7IC4uLnAsIG5hbWU6IG4gfSkpLCBbXSk7XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVNwb3J0ID0gdXNlQ2FsbGJhY2soKGlkOiBzdHJpbmcpID0+IHtcclxuICAgIHNldFByb2ZpbGUoKHApID0+IHtcclxuICAgICAgY29uc3QgaGFzID0gcC5zcG9ydHMuaW5jbHVkZXMoaWQpO1xyXG4gICAgICBpZiAoaGFzICYmIHAuc3BvcnRzLmxlbmd0aCA9PT0gMSkgcmV0dXJuIHA7XHJcbiAgICAgIHJldHVybiB7IC4uLnAsIHNwb3J0czogaGFzID8gcC5zcG9ydHMuZmlsdGVyKChzKSA9PiBzICE9PSBpZCkgOiBbLi4ucC5zcG9ydHMsIGlkXSB9O1xyXG4gICAgfSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCByZXNldEFsbCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwiZm9yamE6cHJvZmlsZTp2MVwiKTtcclxuICAgIHNldFByb2ZpbGUoeyBuYW1lOiBcIlwiLCBzcG9ydHM6IFtdLCBvbmJvYXJkZWQ6IGZhbHNlIH0pO1xyXG4gICAgc2V0VGFiKFwiZXhwbG9yYXJcIik7XHJcbiAgICBzZXRQbGF5ZXJJZChudWxsKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q3R4LlByb3ZpZGVyXHJcbiAgICAgIHZhbHVlPXt7XHJcbiAgICAgICAgcHJvZmlsZSxcclxuICAgICAgICB0b2tlbixcclxuICAgICAgICBhdXRoTG9hZGluZyxcclxuICAgICAgICBwZW5kaW5nQ2hhbGxlbmdlLFxyXG4gICAgICAgIHRhYixcclxuICAgICAgICBwbGF5ZXJJZCxcclxuICAgICAgICB0b2FzdHMsXHJcbiAgICAgICAgZ2VuRm9jdXMsXHJcbiAgICAgICAgc2V0R2VuRm9jdXMsXHJcbiAgICAgICAgc2V0VGFiLFxyXG4gICAgICAgIG9wZW5QbGF5ZXI6IHNldFBsYXllcklkLFxyXG4gICAgICAgIGNsb3NlUGxheWVyOiAoKSA9PiBzZXRQbGF5ZXJJZChudWxsKSxcclxuICAgICAgICB0b2FzdCxcclxuICAgICAgICBhdXRoZW50aWNhdGUsXHJcbiAgICAgICAgdmVyaWZ5Q2hhbGxlbmdlLFxyXG4gICAgICAgIGNhbmNlbENoYWxsZW5nZSxcclxuICAgICAgICBsb2dvdXQsXHJcbiAgICAgICAgY29tcGxldGVPbmJvYXJkaW5nLFxyXG4gICAgICAgIHNldE5hbWUsXHJcbiAgICAgICAgdG9nZ2xlU3BvcnQsXHJcbiAgICAgICAgcmVzZXRBbGwsXHJcbiAgICAgIH19XHJcbiAgICA+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvQ3R4LlByb3ZpZGVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1c2VBcHAoKTogQXBwU3RvcmUge1xyXG4gIGNvbnN0IGN0eCA9IHVzZUNvbnRleHQoQ3R4KTtcclxuICBpZiAoIWN0eCkgdGhyb3cgbmV3IEVycm9yKFwidXNlQXBwIGZvcmEgZG8gQXBwUHJvdmlkZXJcIik7XHJcbiAgcmV0dXJuIGN0eDtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL2x1aXpyL09uZURyaXZlL0RvY3VtZW50b3MvcHJvZ3JhbWFzLWdpdC91bHRyYS1leGVyY2lzZXMvdWx0cmEtZXhlcmNpc2VzL3NyYy9zdG9yZS50c3gifQ==