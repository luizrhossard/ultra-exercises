import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/screens/Auth.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8a41314"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=a8a41314"; const useState = __vite__cjsImport3_react["useState"];
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=a8a41314";
import { Logo } from "/src/components/Logo.tsx";
import { ApiError } from "/src/api.ts";
import { useApp } from "/src/store.tsx";
export default function Auth() {
  _s();
  const { authenticate, verifyChallenge, cancelChallenge, pendingChallenge } = useApp();
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [errorRef, setErrorRef] = useState(null);
  const [busy, setBusy] = useState(false);
  const [code, setCode] = useState("");
  const [recoveryMode, setRecoveryMode] = useState(false);
  if (pendingChallenge) {
    return /* @__PURE__ */ jsxDEV(
      TwoFactorChallenge,
      {
        code,
        setCode,
        recoveryMode,
        setRecoveryMode,
        error,
        setError,
        busy,
        onSubmit: async () => {
          setBusy(true);
          setError("");
          setErrorRef(null);
          try {
            await verifyChallenge(code.trim());
          } catch (err) {
            if (err instanceof ApiError) {
              setError(err.message);
              setErrorRef(err.traceId ?? null);
            } else {
              setError("Não foi possível concluir a entrada.");
              setErrorRef(null);
            }
          } finally {
            setBusy(false);
          }
        },
        onCancel: () => {
          cancelChallenge();
          setError("");
          setErrorRef(null);
          setCode("");
          setRecoveryMode(false);
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 41,
        columnNumber: 12
      },
      this
    );
  }
  const submit = async (event) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    setErrorRef(null);
    try {
      await authenticate(mode, email.trim(), password, name.trim());
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
        setErrorRef(err.traceId ?? null);
      } else {
        setError("Não foi possível entrar.");
        setErrorRef(null);
      }
    } finally {
      setBusy(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex min-h-dvh w-full max-w-[430px] items-center px-5", children: /* @__PURE__ */ jsxDEV(motion.form, { initial: { opacity: 0, y: 18 }, animate: { opacity: 1, y: 0 }, onSubmit: submit, className: "w-full rounded-2xl border border-ink-700 bg-ink-850 p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsxDEV(Logo, { size: 52 }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 77,
      columnNumber: 48
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 77,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "mt-8 font-display text-2xl uppercase text-fog", children: mode === "login" ? "Entrar" : "Criar conta" }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[12px] text-fog-dim", children: "Seu histórico e acompanhamento ficam associados à sua conta." }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 79,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-5 space-y-3", children: [
      mode === "register" && /* @__PURE__ */ jsxDEV("input", { value: name, onChange: (e) => setName(e.target.value), maxLength: 80, placeholder: "Nome", className: "w-full rounded-xl border border-ink-700 bg-ink-800 px-3.5 py-3 text-fog outline-none focus:border-volt-400" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 81,
        columnNumber: 33
      }, this),
      /* @__PURE__ */ jsxDEV("input", { value: email, onChange: (e) => setEmail(e.target.value), type: "email", required: true, placeholder: "E-mail", className: "w-full rounded-xl border border-ink-700 bg-ink-800 px-3.5 py-3 text-fog outline-none focus:border-volt-400" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { value: password, onChange: (e) => setPassword(e.target.value), type: "password", required: true, minLength: 8, placeholder: "Senha (mín. 8 caracteres)", className: "w-full rounded-xl border border-ink-700 bg-ink-800 px-3.5 py-3 text-fog outline-none focus:border-volt-400" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 80,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { role: "alert", className: "mt-3 rounded-lg bg-[#ff5148]/15 p-2.5 text-[12px] text-[#ff817b]", children: error }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 85,
      columnNumber: 17
    }, this),
    error && errorRef && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[11px] text-fog-mute", children: [
      "Ref: ",
      errorRef
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 86,
      columnNumber: 29
    }, this),
    /* @__PURE__ */ jsxDEV("button", { disabled: busy, className: "mt-5 w-full rounded-xl bg-volt-400 py-3 font-display uppercase text-ink-950 disabled:opacity-60", children: busy ? "Conectando…" : mode === "login" ? "Entrar" : "Criar conta" }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 87,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
      setMode(mode === "login" ? "register" : "login");
      setError("");
      setErrorRef(null);
    }, className: "mt-4 w-full text-[12px] font-bold text-volt-300", children: mode === "login" ? "Ainda não tenho conta" : "Já tenho uma conta" }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 88,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
    lineNumber: 76,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
    lineNumber: 75,
    columnNumber: 10
  }, this);
}
_s(Auth, "GdNU8Hp1rUFmgg4C0HFgt5ot8uQ=", false, function() {
  return [useApp];
});
_c = Auth;
function TwoFactorChallenge({ code, setCode, recoveryMode, setRecoveryMode, error, setError, busy, onSubmit, onCancel }) {
  const submit = async (event) => {
    event.preventDefault();
    await onSubmit();
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex min-h-dvh w-full max-w-[430px] items-center px-5", children: /* @__PURE__ */ jsxDEV(motion.form, { initial: { opacity: 0, y: 18 }, animate: { opacity: 1, y: 0 }, onSubmit: submit, className: "w-full rounded-2xl border border-ink-700 bg-ink-850 p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(Logo, { size: 40 }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 114,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("p", { className: "font-display text-2xl uppercase text-fog", children: "Verificação em dois fatores" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 115,
        columnNumber: 14
      }, this) }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 115,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "mt-8 font-display text-2xl uppercase text-fog", children: recoveryMode ? "Código de recuperação" : "Confirme o código" }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 117,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[12px] text-fog-dim", children: recoveryMode ? "Informe um dos seus códigos de recuperação de uso único." : "Abra seu aplicativo autenticador e informe o código de 6 dígitos da conta Forja." }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 118,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-5", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "twofa-code", className: "sr-only", children: recoveryMode ? "Código de recuperação" : "Código de verificação" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 124,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          id: "twofa-code",
          value: code,
          onChange: (e) => setCode(recoveryMode ? e.target.value.toUpperCase() : e.target.value.replace(/\D/g, "")),
          inputMode: recoveryMode ? "text" : "numeric",
          autoComplete: "one-time-code",
          autoFocus: true,
          required: true,
          maxLength: recoveryMode ? 9 : 6,
          placeholder: recoveryMode ? "XXXX-XXXX" : "000000",
          "aria-describedby": error ? "twofa-error" : void 0,
          className: "w-full rounded-xl border border-ink-700 bg-ink-800 px-3.5 py-3 text-center font-display text-xl tracking-[.35em] text-fog outline-none focus:border-volt-400"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
          lineNumber: 125,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 123,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("p", { id: "twofa-error", role: "alert", className: "mt-3 rounded-lg bg-[#ff5148]/15 p-2.5 text-[12px] text-[#ff817b]", children: error }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 141,
        columnNumber: 11
      }, this),
      recoveryMode ? null : /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[11px] text-fog-dim", children: [
        "Sem acesso ao app? ",
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
          setRecoveryMode(true);
          setError("");
        }, className: "font-bold text-volt-300 underline underline-offset-2", children: "Usar código de recuperação" }, void 0, false, {
          fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
          lineNumber: 142,
          columnNumber: 98
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 142,
        columnNumber: 34
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 140,
      columnNumber: 7
    }, this),
    !error && !recoveryMode && /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-[11px] text-fog-dim", children: [
      "Sem acesso ao app? ",
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
        setRecoveryMode(true);
        setError("");
      }, className: "font-bold text-volt-300 underline underline-offset-2", children: "Usar código de recuperação" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
        lineNumber: 145,
        columnNumber: 99
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 145,
      columnNumber: 35
    }, this),
    /* @__PURE__ */ jsxDEV("button", { disabled: busy || code.length < 6, className: "mt-5 w-full rounded-xl bg-volt-400 py-3 font-display uppercase text-ink-950 disabled:opacity-60", children: busy ? "Verificando…" : "Confirmar" }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 146,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onCancel, className: "mt-4 w-full text-[12px] font-bold text-fog-dim", children: "Voltar para o login" }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
      lineNumber: 147,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
    lineNumber: 112,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx",
    lineNumber: 111,
    columnNumber: 10
  }, this);
}
_c2 = TwoFactorChallenge;
var _c, _c2;
$RefreshReg$(_c, "Auth");
$RefreshReg$(_c2, "TwoFactorChallenge");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/screens/Auth.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJXLFNBbUdILFVBbkdHOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCWCxTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBRXZCLHdCQUF3QkMsT0FBTztBQUFBQyxLQUFBO0FBQzdCLFFBQU0sRUFBRUMsY0FBY0MsaUJBQWlCQyxpQkFBaUJDLGlCQUFpQixJQUFJTixPQUFPO0FBQ3BGLFFBQU0sQ0FBQ08sTUFBTUMsT0FBTyxJQUFJWixTQUErQixPQUFPO0FBQzlELFFBQU0sQ0FBQ2EsT0FBT0MsUUFBUSxJQUFJZCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZSxVQUFVQyxXQUFXLElBQUloQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDaUIsTUFBTUMsT0FBTyxJQUFJbEIsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQ21CLE9BQU9DLFFBQVEsSUFBSXBCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQixVQUFVQyxXQUFXLElBQUl0QixTQUF3QixJQUFJO0FBQzVELFFBQU0sQ0FBQ3VCLE1BQU1DLE9BQU8sSUFBSXhCLFNBQVMsS0FBSztBQUd0QyxRQUFNLENBQUN5QixNQUFNQyxPQUFPLElBQUkxQixTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDMkIsY0FBY0MsZUFBZSxJQUFJNUIsU0FBUyxLQUFLO0FBRXRELE1BQUlVLGtCQUFrQjtBQUNwQixXQUFPO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDTjtBQUFBLFFBQVk7QUFBQSxRQUNaO0FBQUEsUUFBNEI7QUFBQSxRQUM1QjtBQUFBLFFBQWM7QUFBQSxRQUNkO0FBQUEsUUFDQSxVQUFVLFlBQVk7QUFDcEJjLGtCQUFRLElBQUk7QUFBR0osbUJBQVMsRUFBRTtBQUFHRSxzQkFBWSxJQUFJO0FBQzdDLGNBQUk7QUFBRSxrQkFBTWQsZ0JBQWdCaUIsS0FBS0ksS0FBSyxDQUFDO0FBQUEsVUFBRyxTQUNuQ0MsS0FBSztBQUNWLGdCQUFJQSxlQUFlM0IsVUFBVTtBQUFFaUIsdUJBQVNVLElBQUlDLE9BQU87QUFBR1QsMEJBQVlRLElBQUlFLFdBQVcsSUFBSTtBQUFBLFlBQUcsT0FDbkY7QUFBRVosdUJBQVMsc0NBQXNDO0FBQUdFLDBCQUFZLElBQUk7QUFBQSxZQUFHO0FBQUEsVUFDOUUsVUFBQztBQUNTRSxvQkFBUSxLQUFLO0FBQUEsVUFBRztBQUFBLFFBQzVCO0FBQUEsUUFDQSxVQUFVLE1BQU07QUFBRWYsMEJBQWdCO0FBQUdXLG1CQUFTLEVBQUU7QUFBR0Usc0JBQVksSUFBSTtBQUFHSSxrQkFBUSxFQUFFO0FBQUdFLDBCQUFnQixLQUFLO0FBQUEsUUFBRztBQUFBO0FBQUEsTUFkdEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBY3dHO0FBQUEsRUFFakg7QUFFQSxRQUFNSyxTQUFTLE9BQU9DLFVBQTJCO0FBQy9DQSxVQUFNQyxlQUFlO0FBQ3JCWCxZQUFRLElBQUk7QUFBR0osYUFBUyxFQUFFO0FBQUdFLGdCQUFZLElBQUk7QUFDN0MsUUFBSTtBQUFFLFlBQU1mLGFBQWFJLE1BQU1FLE1BQU1nQixLQUFLLEdBQUdkLFVBQVVFLEtBQUtZLEtBQUssQ0FBQztBQUFBLElBQUcsU0FDOURDLEtBQUs7QUFDVixVQUFJQSxlQUFlM0IsVUFBVTtBQUMzQmlCLGlCQUFTVSxJQUFJQyxPQUFPO0FBQ3BCVCxvQkFBWVEsSUFBSUUsV0FBVyxJQUFJO0FBQUEsTUFDakMsT0FBTztBQUNMWixpQkFBUywwQkFBMEI7QUFDbkNFLG9CQUFZLElBQUk7QUFBQSxNQUNsQjtBQUFBLElBQ0YsVUFBQztBQUNTRSxjQUFRLEtBQUs7QUFBQSxJQUFHO0FBQUEsRUFDNUI7QUFFQSxTQUFPLHVCQUFDLFNBQUksV0FBVSxpRUFDcEIsaUNBQUMsT0FBTyxNQUFQLEVBQVksU0FBUyxFQUFFWSxTQUFTLEdBQUdDLEdBQUcsR0FBRyxHQUFHLFNBQVMsRUFBRUQsU0FBUyxHQUFHQyxHQUFHLEVBQUUsR0FBRyxVQUFVSixRQUFRLFdBQVUsMkRBQ3RHO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDJCQUEwQixpQ0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWUsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRDtBQUFBLElBQzNELHVCQUFDLFFBQUcsV0FBVSxpREFBaUR0QixtQkFBUyxVQUFVLFdBQVcsaUJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkc7QUFBQSxJQUMzRyx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLDRFQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlHO0FBQUEsSUFDekcsdUJBQUMsU0FBSSxXQUFVLGtCQUNaQTtBQUFBQSxlQUFTLGNBQWMsdUJBQUMsV0FBTSxPQUFPTSxNQUFNLFVBQVUsQ0FBQ3FCLE1BQU1wQixRQUFRb0IsRUFBRUMsT0FBT0MsS0FBSyxHQUFHLFdBQVcsSUFBSSxhQUFZLFFBQU8sV0FBVSxnSEFBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzTjtBQUFBLE1BQzlPLHVCQUFDLFdBQU0sT0FBTzNCLE9BQU8sVUFBVSxDQUFDeUIsTUFBTXhCLFNBQVN3QixFQUFFQyxPQUFPQyxLQUFLLEdBQUcsTUFBSyxTQUFRLFVBQVEsTUFBQyxhQUFZLFVBQVMsV0FBVSxnSEFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpTztBQUFBLE1BQ2pPLHVCQUFDLFdBQU0sT0FBT3pCLFVBQVUsVUFBVSxDQUFDdUIsTUFBTXRCLFlBQVlzQixFQUFFQyxPQUFPQyxLQUFLLEdBQUcsTUFBSyxZQUFXLFVBQVEsTUFBQyxXQUFXLEdBQUcsYUFBWSw2QkFBNEIsV0FBVSxnSEFBL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyUTtBQUFBLFNBSDdRO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBQ0NyQixTQUFTLHVCQUFDLE9BQUUsTUFBSyxTQUFRLFdBQVUsb0VBQW9FQSxtQkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRztBQUFBLElBQzdHQSxTQUFTRSxZQUFZLHVCQUFDLE9BQUUsV0FBVSxrQ0FBaUM7QUFBQTtBQUFBLE1BQU1BO0FBQUFBLFNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkQ7QUFBQSxJQUNuRix1QkFBQyxZQUFPLFVBQVVFLE1BQU0sV0FBVSxtR0FBbUdBLGlCQUFPLGdCQUFnQlosU0FBUyxVQUFVLFdBQVcsaUJBQTFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd007QUFBQSxJQUN4TSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU07QUFBRUMsY0FBUUQsU0FBUyxVQUFVLGFBQWEsT0FBTztBQUFHUyxlQUFTLEVBQUU7QUFBR0Usa0JBQVksSUFBSTtBQUFBLElBQUcsR0FBRyxXQUFVLG1EQUFtRFgsbUJBQVMsVUFBVSwwQkFBMEIsd0JBQXZPO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNFA7QUFBQSxPQVo5UDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYUEsS0FkSztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZVA7QUFDRjtBQUFDTCxHQWpFdUJELE1BQUk7QUFBQSxVQUNtREQsTUFBTTtBQUFBO0FBQUEsS0FEN0RDO0FBK0V4QixTQUFTb0MsbUJBQW1CLEVBQUVoQixNQUFNQyxTQUFTQyxjQUFjQyxpQkFBaUJULE9BQU9DLFVBQVVHLE1BQU1tQixVQUFVQyxTQUF5QixHQUFHO0FBQ3ZJLFFBQU1WLFNBQVMsT0FBT0MsVUFBMkI7QUFDL0NBLFVBQU1DLGVBQWU7QUFDckIsVUFBTU8sU0FBUztBQUFBLEVBQ2pCO0FBRUEsU0FBTyx1QkFBQyxTQUFJLFdBQVUsaUVBQ3BCLGlDQUFDLE9BQU8sTUFBUCxFQUFZLFNBQVMsRUFBRU4sU0FBUyxHQUFHQyxHQUFHLEdBQUcsR0FBRyxTQUFTLEVBQUVELFNBQVMsR0FBR0MsR0FBRyxFQUFFLEdBQUcsVUFBVUosUUFBUSxXQUFVLDJEQUN0RztBQUFBLDJCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsU0FBSSxpQ0FBQyxPQUFFLFdBQVUsNENBQTJDLDJDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1GLEtBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEY7QUFBQSxTQUY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFFBQUcsV0FBVSxpREFBaUROLHlCQUFlLDBCQUEwQix1QkFBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0SDtBQUFBLElBQzVILHVCQUFDLE9BQUUsV0FBVSxpQ0FDVkEseUJBQ0csNkRBQ0Esc0ZBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLFdBQU0sU0FBUSxjQUFhLFdBQVUsV0FBV0EseUJBQWUsMEJBQTBCLDJCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtIO0FBQUEsTUFDbEg7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLElBQUc7QUFBQSxVQUNILE9BQU9GO0FBQUFBLFVBQ1AsVUFBVSxDQUFDYSxNQUFNWixRQUFRQyxlQUFlVyxFQUFFQyxPQUFPQyxNQUFNSSxZQUFZLElBQUlOLEVBQUVDLE9BQU9DLE1BQU1LLFFBQVEsT0FBTyxFQUFFLENBQUM7QUFBQSxVQUN4RyxXQUFXbEIsZUFBZSxTQUFTO0FBQUEsVUFDbkMsY0FBYTtBQUFBLFVBQ2I7QUFBQSxVQUNBO0FBQUEsVUFDQSxXQUFXQSxlQUFlLElBQUk7QUFBQSxVQUM5QixhQUFhQSxlQUFlLGNBQWM7QUFBQSxVQUMxQyxvQkFBa0JSLFFBQVEsZ0JBQWdCMkI7QUFBQUEsVUFDMUMsV0FBVTtBQUFBO0FBQUEsUUFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFXMEs7QUFBQSxTQWI1SztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUNDM0IsU0FDQyxtQ0FDRTtBQUFBLDZCQUFDLE9BQUUsSUFBRyxlQUFjLE1BQUssU0FBUSxXQUFVLG9FQUFvRUEsbUJBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUg7QUFBQSxNQUNwSFEsZUFBZSxPQUFPLHVCQUFDLE9BQUUsV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLFFBQW1CLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTtBQUFFQywwQkFBZ0IsSUFBSTtBQUFHUixtQkFBUyxFQUFFO0FBQUEsUUFBRyxHQUFHLFdBQVUsd0RBQXVELDBDQUFoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBLO0FBQUEsV0FBMU87QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtUDtBQUFBLFNBRjVRO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUQsQ0FBQ0QsU0FBUyxDQUFDUSxnQkFBZ0IsdUJBQUMsT0FBRSxXQUFVLGlDQUFnQztBQUFBO0FBQUEsTUFBbUIsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNO0FBQUVDLHdCQUFnQixJQUFJO0FBQUdSLGlCQUFTLEVBQUU7QUFBQSxNQUFHLEdBQUcsV0FBVSx3REFBdUQsMENBQWhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEs7QUFBQSxTQUExTztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1QO0FBQUEsSUFDL1EsdUJBQUMsWUFBTyxVQUFVRyxRQUFRRSxLQUFLc0IsU0FBUyxHQUFHLFdBQVUsbUdBQW1HeEIsaUJBQU8saUJBQWlCLGVBQWhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEw7QUFBQSxJQUM1TCx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTb0IsVUFBVSxXQUFVLGtEQUFpRCxtQ0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SDtBQUFBLE9BbkN6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0NBLEtBckNLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ1A7QUFDRjtBQUFDSyxNQTdDUVA7QUFBa0IsSUFBQVEsSUFBQUQ7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwibW90aW9uIiwiTG9nbyIsIkFwaUVycm9yIiwidXNlQXBwIiwiQXV0aCIsIl9zIiwiYXV0aGVudGljYXRlIiwidmVyaWZ5Q2hhbGxlbmdlIiwiY2FuY2VsQ2hhbGxlbmdlIiwicGVuZGluZ0NoYWxsZW5nZSIsIm1vZGUiLCJzZXRNb2RlIiwiZW1haWwiLCJzZXRFbWFpbCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJuYW1lIiwic2V0TmFtZSIsImVycm9yIiwic2V0RXJyb3IiLCJlcnJvclJlZiIsInNldEVycm9yUmVmIiwiYnVzeSIsInNldEJ1c3kiLCJjb2RlIiwic2V0Q29kZSIsInJlY292ZXJ5TW9kZSIsInNldFJlY292ZXJ5TW9kZSIsInRyaW0iLCJlcnIiLCJtZXNzYWdlIiwidHJhY2VJZCIsInN1Ym1pdCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJvcGFjaXR5IiwieSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIlR3b0ZhY3RvckNoYWxsZW5nZSIsIm9uU3VibWl0Iiwib25DYW5jZWwiLCJ0b1VwcGVyQ2FzZSIsInJlcGxhY2UiLCJ1bmRlZmluZWQiLCJsZW5ndGgiLCJfYzIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRoLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tIFwiZnJhbWVyLW1vdGlvblwiO1xyXG5pbXBvcnQgeyBMb2dvIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvTG9nb1wiO1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gXCIuLi9hcGlcIjtcclxuaW1wb3J0IHsgdXNlQXBwIH0gZnJvbSBcIi4uL3N0b3JlXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBdXRoKCkge1xyXG4gIGNvbnN0IHsgYXV0aGVudGljYXRlLCB2ZXJpZnlDaGFsbGVuZ2UsIGNhbmNlbENoYWxsZW5nZSwgcGVuZGluZ0NoYWxsZW5nZSB9ID0gdXNlQXBwKCk7XHJcbiAgY29uc3QgW21vZGUsIHNldE1vZGVdID0gdXNlU3RhdGU8XCJsb2dpblwiIHwgXCJyZWdpc3RlclwiPihcImxvZ2luXCIpO1xyXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvclJlZiwgc2V0RXJyb3JSZWZdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyAtLS0tIERlc2FmaW8gMkZBIFtVRS0yNF0gLS0tLVxyXG4gIGNvbnN0IFtjb2RlLCBzZXRDb2RlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyZWNvdmVyeU1vZGUsIHNldFJlY292ZXJ5TW9kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGlmIChwZW5kaW5nQ2hhbGxlbmdlKSB7XHJcbiAgICByZXR1cm4gPFR3b0ZhY3RvckNoYWxsZW5nZVxyXG4gICAgICBjb2RlPXtjb2RlfSBzZXRDb2RlPXtzZXRDb2RlfVxyXG4gICAgICByZWNvdmVyeU1vZGU9e3JlY292ZXJ5TW9kZX0gc2V0UmVjb3ZlcnlNb2RlPXtzZXRSZWNvdmVyeU1vZGV9XHJcbiAgICAgIGVycm9yPXtlcnJvcn0gc2V0RXJyb3I9e3NldEVycm9yfVxyXG4gICAgICBidXN5PXtidXN5fVxyXG4gICAgICBvblN1Ym1pdD17YXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHNldEJ1c3kodHJ1ZSk7IHNldEVycm9yKFwiXCIpOyBzZXRFcnJvclJlZihudWxsKTtcclxuICAgICAgICB0cnkgeyBhd2FpdCB2ZXJpZnlDaGFsbGVuZ2UoY29kZS50cmltKCkpOyB9XHJcbiAgICAgICAgY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yKSB7IHNldEVycm9yKGVyci5tZXNzYWdlKTsgc2V0RXJyb3JSZWYoZXJyLnRyYWNlSWQgPz8gbnVsbCk7IH1cclxuICAgICAgICAgIGVsc2UgeyBzZXRFcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBjb25jbHVpciBhIGVudHJhZGEuXCIpOyBzZXRFcnJvclJlZihudWxsKTsgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBmaW5hbGx5IHsgc2V0QnVzeShmYWxzZSk7IH1cclxuICAgICAgfX1cclxuICAgICAgb25DYW5jZWw9eygpID0+IHsgY2FuY2VsQ2hhbGxlbmdlKCk7IHNldEVycm9yKFwiXCIpOyBzZXRFcnJvclJlZihudWxsKTsgc2V0Q29kZShcIlwiKTsgc2V0UmVjb3ZlcnlNb2RlKGZhbHNlKTsgfX1cclxuICAgIC8+O1xyXG4gIH1cclxuXHJcbiAgY29uc3Qgc3VibWl0ID0gYXN5bmMgKGV2ZW50OiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzZXRCdXN5KHRydWUpOyBzZXRFcnJvcihcIlwiKTsgc2V0RXJyb3JSZWYobnVsbCk7XHJcbiAgICB0cnkgeyBhd2FpdCBhdXRoZW50aWNhdGUobW9kZSwgZW1haWwudHJpbSgpLCBwYXNzd29yZCwgbmFtZS50cmltKCkpOyB9XHJcbiAgICBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBBcGlFcnJvcikge1xyXG4gICAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKTtcclxuICAgICAgICBzZXRFcnJvclJlZihlcnIudHJhY2VJZCA/PyBudWxsKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRFcnJvcihcIk7Do28gZm9pIHBvc3PDrXZlbCBlbnRyYXIuXCIpO1xyXG4gICAgICAgIHNldEVycm9yUmVmKG51bGwpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBmaW5hbGx5IHsgc2V0QnVzeShmYWxzZSk7IH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIGZsZXggbWluLWgtZHZoIHctZnVsbCBtYXgtdy1bNDMwcHhdIGl0ZW1zLWNlbnRlciBweC01XCI+XHJcbiAgICA8bW90aW9uLmZvcm0gaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAxOCB9fSBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX0gb25TdWJtaXQ9e3N1Ym1pdH0gY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItaW5rLTcwMCBiZy1pbmstODUwIHAtNlwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+PExvZ28gc2l6ZT17NTJ9IC8+PC9kaXY+XHJcbiAgICAgIDxoMSBjbGFzc05hbWU9XCJtdC04IGZvbnQtZGlzcGxheSB0ZXh0LTJ4bCB1cHBlcmNhc2UgdGV4dC1mb2dcIj57bW9kZSA9PT0gXCJsb2dpblwiID8gXCJFbnRyYXJcIiA6IFwiQ3JpYXIgY29udGFcIn08L2gxPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtWzEycHhdIHRleHQtZm9nLWRpbVwiPlNldSBoaXN0w7NyaWNvIGUgYWNvbXBhbmhhbWVudG8gZmljYW0gYXNzb2NpYWRvcyDDoCBzdWEgY29udGEuPC9wPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgc3BhY2UteS0zXCI+XHJcbiAgICAgICAge21vZGUgPT09IFwicmVnaXN0ZXJcIiAmJiA8aW5wdXQgdmFsdWU9e25hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9IG1heExlbmd0aD17ODB9IHBsYWNlaG9sZGVyPVwiTm9tZVwiIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItaW5rLTcwMCBiZy1pbmstODAwIHB4LTMuNSBweS0zIHRleHQtZm9nIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdm9sdC00MDBcIiAvPn1cclxuICAgICAgICA8aW5wdXQgdmFsdWU9e2VtYWlsfSBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX0gdHlwZT1cImVtYWlsXCIgcmVxdWlyZWQgcGxhY2Vob2xkZXI9XCJFLW1haWxcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWluay03MDAgYmctaW5rLTgwMCBweC0zLjUgcHktMyB0ZXh0LWZvZyBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZvbHQtNDAwXCIgLz5cclxuICAgICAgICA8aW5wdXQgdmFsdWU9e3Bhc3N3b3JkfSBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX0gdHlwZT1cInBhc3N3b3JkXCIgcmVxdWlyZWQgbWluTGVuZ3RoPXs4fSBwbGFjZWhvbGRlcj1cIlNlbmhhIChtw61uLiA4IGNhcmFjdGVyZXMpXCIgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1pbmstNzAwIGJnLWluay04MDAgcHgtMy41IHB5LTMgdGV4dC1mb2cgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12b2x0LTQwMFwiIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7ZXJyb3IgJiYgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLWxnIGJnLVsjZmY1MTQ4XS8xNSBwLTIuNSB0ZXh0LVsxMnB4XSB0ZXh0LVsjZmY4MTdiXVwiPntlcnJvcn08L3A+fVxyXG4gICAgICB7ZXJyb3IgJiYgZXJyb3JSZWYgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxMXB4XSB0ZXh0LWZvZy1tdXRlXCI+UmVmOiB7ZXJyb3JSZWZ9PC9wPn1cclxuICAgICAgPGJ1dHRvbiBkaXNhYmxlZD17YnVzeX0gY2xhc3NOYW1lPVwibXQtNSB3LWZ1bGwgcm91bmRlZC14bCBiZy12b2x0LTQwMCBweS0zIGZvbnQtZGlzcGxheSB1cHBlcmNhc2UgdGV4dC1pbmstOTUwIGRpc2FibGVkOm9wYWNpdHktNjBcIj57YnVzeSA/IFwiQ29uZWN0YW5kb+KAplwiIDogbW9kZSA9PT0gXCJsb2dpblwiID8gXCJFbnRyYXJcIiA6IFwiQ3JpYXIgY29udGFcIn08L2J1dHRvbj5cclxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRNb2RlKG1vZGUgPT09IFwibG9naW5cIiA/IFwicmVnaXN0ZXJcIiA6IFwibG9naW5cIik7IHNldEVycm9yKFwiXCIpOyBzZXRFcnJvclJlZihudWxsKTsgfX0gY2xhc3NOYW1lPVwibXQtNCB3LWZ1bGwgdGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtdm9sdC0zMDBcIj57bW9kZSA9PT0gXCJsb2dpblwiID8gXCJBaW5kYSBuw6NvIHRlbmhvIGNvbnRhXCIgOiBcIkrDoSB0ZW5obyB1bWEgY29udGFcIn08L2J1dHRvbj5cclxuICAgIDwvbW90aW9uLmZvcm0+XHJcbiAgPC9kaXY+O1xyXG59XHJcblxyXG5pbnRlcmZhY2UgQ2hhbGxlbmdlUHJvcHMge1xyXG4gIGNvZGU6IHN0cmluZztcclxuICBzZXRDb2RlOiAodjogc3RyaW5nKSA9PiB2b2lkO1xyXG4gIHJlY292ZXJ5TW9kZTogYm9vbGVhbjtcclxuICBzZXRSZWNvdmVyeU1vZGU6ICh2OiBib29sZWFuKSA9PiB2b2lkO1xyXG4gIGVycm9yOiBzdHJpbmc7XHJcbiAgc2V0RXJyb3I6ICh2OiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgYnVzeTogYm9vbGVhbjtcclxuICBvblN1Ym1pdDogKCkgPT4gUHJvbWlzZTx2b2lkPjtcclxuICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZnVuY3Rpb24gVHdvRmFjdG9yQ2hhbGxlbmdlKHsgY29kZSwgc2V0Q29kZSwgcmVjb3ZlcnlNb2RlLCBzZXRSZWNvdmVyeU1vZGUsIGVycm9yLCBzZXRFcnJvciwgYnVzeSwgb25TdWJtaXQsIG9uQ2FuY2VsIH06IENoYWxsZW5nZVByb3BzKSB7XHJcbiAgY29uc3Qgc3VibWl0ID0gYXN5bmMgKGV2ZW50OiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBhd2FpdCBvblN1Ym1pdCgpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBtaW4taC1kdmggdy1mdWxsIG1heC13LVs0MzBweF0gaXRlbXMtY2VudGVyIHB4LTVcIj5cclxuICAgIDxtb3Rpb24uZm9ybSBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDE4IH19IGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fSBvblN1Ym1pdD17c3VibWl0fSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1pbmstNzAwIGJnLWluay04NTAgcC02XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICA8TG9nbyBzaXplPXs0MH0gLz5cclxuICAgICAgICA8ZGl2PjxwIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCB1cHBlcmNhc2UgdGV4dC1mb2dcIj5WZXJpZmljYcOnw6NvIGVtIGRvaXMgZmF0b3JlczwvcD48L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxoMSBjbGFzc05hbWU9XCJtdC04IGZvbnQtZGlzcGxheSB0ZXh0LTJ4bCB1cHBlcmNhc2UgdGV4dC1mb2dcIj57cmVjb3ZlcnlNb2RlID8gXCJDw7NkaWdvIGRlIHJlY3VwZXJhw6fDo29cIiA6IFwiQ29uZmlybWUgbyBjw7NkaWdvXCJ9PC9oMT5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxMnB4XSB0ZXh0LWZvZy1kaW1cIj5cclxuICAgICAgICB7cmVjb3ZlcnlNb2RlXHJcbiAgICAgICAgICA/IFwiSW5mb3JtZSB1bSBkb3Mgc2V1cyBjw7NkaWdvcyBkZSByZWN1cGVyYcOnw6NvIGRlIHVzbyDDum5pY28uXCJcclxuICAgICAgICAgIDogXCJBYnJhIHNldSBhcGxpY2F0aXZvIGF1dGVudGljYWRvciBlIGluZm9ybWUgbyBjw7NkaWdvIGRlIDYgZMOtZ2l0b3MgZGEgY29udGEgRm9yamEuXCJ9XHJcbiAgICAgIDwvcD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01XCI+XHJcbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ0d29mYS1jb2RlXCIgY2xhc3NOYW1lPVwic3Itb25seVwiPntyZWNvdmVyeU1vZGUgPyBcIkPDs2RpZ28gZGUgcmVjdXBlcmHDp8Ojb1wiIDogXCJDw7NkaWdvIGRlIHZlcmlmaWNhw6fDo29cIn08L2xhYmVsPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgaWQ9XCJ0d29mYS1jb2RlXCJcclxuICAgICAgICAgIHZhbHVlPXtjb2RlfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb2RlKHJlY292ZXJ5TW9kZSA/IGUudGFyZ2V0LnZhbHVlLnRvVXBwZXJDYXNlKCkgOiBlLnRhcmdldC52YWx1ZS5yZXBsYWNlKC9cXEQvZywgXCJcIikpfVxyXG4gICAgICAgICAgaW5wdXRNb2RlPXtyZWNvdmVyeU1vZGUgPyBcInRleHRcIiA6IFwibnVtZXJpY1wifVxyXG4gICAgICAgICAgYXV0b0NvbXBsZXRlPVwib25lLXRpbWUtY29kZVwiXHJcbiAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICBtYXhMZW5ndGg9e3JlY292ZXJ5TW9kZSA/IDkgOiA2fVxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9e3JlY292ZXJ5TW9kZSA/IFwiWFhYWC1YWFhYXCIgOiBcIjAwMDAwMFwifVxyXG4gICAgICAgICAgYXJpYS1kZXNjcmliZWRieT17ZXJyb3IgPyBcInR3b2ZhLWVycm9yXCIgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWluay03MDAgYmctaW5rLTgwMCBweC0zLjUgcHktMyB0ZXh0LWNlbnRlciBmb250LWRpc3BsYXkgdGV4dC14bCB0cmFja2luZy1bLjM1ZW1dIHRleHQtZm9nIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdm9sdC00MDBcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8cCBpZD1cInR3b2ZhLWVycm9yXCIgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLWxnIGJnLVsjZmY1MTQ4XS8xNSBwLTIuNSB0ZXh0LVsxMnB4XSB0ZXh0LVsjZmY4MTdiXVwiPntlcnJvcn08L3A+XHJcbiAgICAgICAgICB7cmVjb3ZlcnlNb2RlID8gbnVsbCA6IDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1bMTFweF0gdGV4dC1mb2ctZGltXCI+U2VtIGFjZXNzbyBhbyBhcHA/IDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0UmVjb3ZlcnlNb2RlKHRydWUpOyBzZXRFcnJvcihcIlwiKTsgfX0gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtdm9sdC0zMDAgdW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtMlwiPlVzYXIgY8OzZGlnbyBkZSByZWN1cGVyYcOnw6NvPC9idXR0b24+PC9wPn1cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuICAgICAgeyFlcnJvciAmJiAhcmVjb3ZlcnlNb2RlICYmIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1bMTFweF0gdGV4dC1mb2ctZGltXCI+U2VtIGFjZXNzbyBhbyBhcHA/IDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0UmVjb3ZlcnlNb2RlKHRydWUpOyBzZXRFcnJvcihcIlwiKTsgfX0gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtdm9sdC0zMDAgdW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtMlwiPlVzYXIgY8OzZGlnbyBkZSByZWN1cGVyYcOnw6NvPC9idXR0b24+PC9wPn1cclxuICAgICAgPGJ1dHRvbiBkaXNhYmxlZD17YnVzeSB8fCBjb2RlLmxlbmd0aCA8IDZ9IGNsYXNzTmFtZT1cIm10LTUgdy1mdWxsIHJvdW5kZWQteGwgYmctdm9sdC00MDAgcHktMyBmb250LWRpc3BsYXkgdXBwZXJjYXNlIHRleHQtaW5rLTk1MCBkaXNhYmxlZDpvcGFjaXR5LTYwXCI+e2J1c3kgPyBcIlZlcmlmaWNhbmRv4oCmXCIgOiBcIkNvbmZpcm1hclwifTwvYnV0dG9uPlxyXG4gICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtvbkNhbmNlbH0gY2xhc3NOYW1lPVwibXQtNCB3LWZ1bGwgdGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtZm9nLWRpbVwiPlZvbHRhciBwYXJhIG8gbG9naW48L2J1dHRvbj5cclxuICAgIDwvbW90aW9uLmZvcm0+XHJcbiAgPC9kaXY+O1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvbHVpenIvT25lRHJpdmUvRG9jdW1lbnRvcy9wcm9ncmFtYXMtZ2l0L3VsdHJhLWV4ZXJjaXNlcy91bHRyYS1leGVyY2lzZXMvc3JjL3NjcmVlbnMvQXV0aC50c3gifQ==