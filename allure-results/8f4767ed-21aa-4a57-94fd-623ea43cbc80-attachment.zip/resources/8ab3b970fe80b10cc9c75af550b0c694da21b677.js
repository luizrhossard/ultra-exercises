import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Icons.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8a41314"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const base = (p) => ({
  width: p.size ?? 20,
  height: p.size ?? 20,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: p.strokeWidth ?? 1.8,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  className: p.className
});
const Futebol = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "8.6" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 42,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M12 8.4l3.4 2.5-1.3 4h-4.2l-1.3-4L12 8.4z" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 43,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M12 8.4V3.4M15.4 10.9l4.8-1.5M14.1 14.9l3 4.1M9.9 14.9l-3 4.1M8.6 10.9L3.8 9.4" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 44,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 41,
  columnNumber: 1
}, this);
_c = Futebol;
const Boxe = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("path", { d: "M8.5 3.8h4.2a4.3 4.3 0 0 1 4.3 4.3v3.1a4.6 4.6 0 0 1-4.6 4.6H10a3.5 3.5 0 0 1-3.5-3.5v-.6l-1.6-1.5a2.6 2.6 0 0 1 0-3.7l1.9-1.7a2.4 2.4 0 0 1 1.7-1z" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 50,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M8 15.8v2.4a2 2 0 0 0 2 2h3.6a2 2 0 0 0 2-2v-2.4M12.7 3.8v5.4" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 51,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 49,
  columnNumber: 1
}, this);
_c2 = Boxe;
const JiuJitsu = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("path", { d: "M3.5 6.5l6.2 5.5-6.2 5.5M20.5 6.5l-6.2 5.5 6.2 5.5" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 57,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("rect", { x: "9.8", y: "9.8", width: "4.4", height: "4.4", rx: "1" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 58,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M12 14.2v4.3" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 59,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 56,
  columnNumber: 1
}, this);
_c3 = JiuJitsu;
const Basquete = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "8.6" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 65,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M12 3.4v17.2M3.4 12h17.2" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 66,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M6 5.4a11.6 11.6 0 0 1 0 13.2M18 5.4a11.6 11.6 0 0 0 0 13.2" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 67,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 64,
  columnNumber: 1
}, this);
_c4 = Basquete;
const Volei = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "8.6" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 73,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M12 3.4c1 3.4.4 6.6-1.8 8.9M12 12.3c3.3 1 6.5.3 8.6-1.8M12 12.3c-2.3 2.4-5.5 3-8.8 2.3" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 74,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 72,
  columnNumber: 1
}, this);
_c5 = Volei;
const Corrida = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("path", { d: "M3 16.2c0-1.4 1-2.2 2.4-2.2h4.4l2.3-3.4 2.2 1.1c3 .1 5.7 2.1 6.7 4.5H3z" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 80,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M3 16.2v1.6h18v-1.6M9.5 10.5L8.2 8.6M14.6 14h2.6" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 81,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 79,
  columnNumber: 1
}, this);
_c6 = Corrida;
const Natacao = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "16.4", cy: "6.4", r: "1.9" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 87,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M4 9.6c2.8-2.4 6-2.9 9.4-1.4" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 88,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M2.8 14.2c1.7-1.7 3.5-1.7 5.2 0s3.5 1.7 5.2 0 3.5-1.7 5.2 0 2.6 1.4 2.8 1.2M2.8 18.8c1.7-1.7 3.5-1.7 5.2 0s3.5 1.7 5.2 0 3.5-1.7 5.2 0" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 89,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 86,
  columnNumber: 1
}, this);
_c7 = Natacao;
const Tenis = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("g", { transform: "rotate(-28 10 9)", children: [
    /* @__PURE__ */ jsxDEV("ellipse", { cx: "10", cy: "9", rx: "5.4", ry: "6.4" }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
      lineNumber: 96,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("path", { d: "M10 2.6v12.8M4.9 6.6h10.2M4.9 11.4h10.2", strokeWidth: 1.1 }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
      lineNumber: 97,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 95,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M13.2 14.6L19 20.4" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 99,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 94,
  columnNumber: 1
}, this);
_c8 = Tenis;
export function SportIcon({ id, size, className, strokeWidth }) {
  switch (id) {
    case "futebol":
      return /* @__PURE__ */ jsxDEV(Futebol, { size, className, strokeWidth }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
        lineNumber: 105,
        columnNumber: 27
      }, this);
    case "boxe":
      return /* @__PURE__ */ jsxDEV(Boxe, { size, className, strokeWidth }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
        lineNumber: 106,
        columnNumber: 24
      }, this);
    case "jiu-jitsu":
      return /* @__PURE__ */ jsxDEV(JiuJitsu, { size, className, strokeWidth }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
        lineNumber: 107,
        columnNumber: 29
      }, this);
    case "basquete":
      return /* @__PURE__ */ jsxDEV(Basquete, { size, className, strokeWidth }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
        lineNumber: 108,
        columnNumber: 28
      }, this);
    case "volei":
      return /* @__PURE__ */ jsxDEV(Volei, { size, className, strokeWidth }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
        lineNumber: 109,
        columnNumber: 25
      }, this);
    case "corrida":
      return /* @__PURE__ */ jsxDEV(Corrida, { size, className, strokeWidth }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
        lineNumber: 110,
        columnNumber: 27
      }, this);
    case "natacao":
      return /* @__PURE__ */ jsxDEV(Natacao, { size, className, strokeWidth }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
        lineNumber: 111,
        columnNumber: 27
      }, this);
    case "tenis":
      return /* @__PURE__ */ jsxDEV(Tenis, { size, className, strokeWidth }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
        lineNumber: 112,
        columnNumber: 25
      }, this);
    default:
      return /* @__PURE__ */ jsxDEV(Futebol, { size, className, strokeWidth }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
        lineNumber: 113,
        columnNumber: 20
      }, this);
  }
}
_c9 = SportIcon;
export const IconRadar = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "8.6" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 121,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "4.6", strokeDasharray: "2.5 3" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 122,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M12 12l5.4-5.4" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 123,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("circle", { cx: "14.6", cy: "9.4", r: "1.15", fill: "currentColor", stroke: "none" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 124,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 120,
  columnNumber: 1
}, this);
_c0 = IconRadar;
export const IconClipboard = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("rect", { x: "5", y: "4.4", width: "14", height: "16.2", rx: "2.4" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 130,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M9 4.4V3.2A1.2 1.2 0 0 1 10.2 2h3.6A1.2 1.2 0 0 1 15 3.2v1.2M8.6 10.4h6.8M8.6 14h4.6M8.6 17.4h3" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 131,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 129,
  columnNumber: 1
}, this);
_c1 = IconClipboard;
export const IconBolt = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M13.2 2.6L5.6 13.4h5.2l-1 8 7.6-10.8h-5.2l1-8z" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 137,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 136,
  columnNumber: 1
}, this);
_c10 = IconBolt;
export const IconUser = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "8", r: "3.8" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 143,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M4.4 20.4c1.3-3.6 4-5.4 7.6-5.4s6.3 1.8 7.6 5.4" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 144,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 142,
  columnNumber: 1
}, this);
_c11 = IconUser;
export const IconSearch = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "10.6", cy: "10.6", r: "6.2" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 150,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M15.4 15.4l4.6 4.6" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 151,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 149,
  columnNumber: 1
}, this);
_c12 = IconSearch;
export const IconBack = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M14.8 5.4L8.2 12l6.6 6.6" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 157,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 156,
  columnNumber: 1
}, this);
_c13 = IconBack;
export const IconPlus = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M12 5.4v13.2M5.4 12h13.2" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 163,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 162,
  columnNumber: 1
}, this);
_c14 = IconPlus;
export const IconMinus = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M5.4 12h13.2" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 169,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 168,
  columnNumber: 1
}, this);
_c15 = IconMinus;
export const IconTrash = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M4.4 6.6h15.2M9.6 6.6V4.8A1.4 1.4 0 0 1 11 3.4h2a1.4 1.4 0 0 1 1.4 1.4v1.8M6.4 6.6l.8 12.6a1.6 1.6 0 0 0 1.6 1.4h6.4a1.6 1.6 0 0 0 1.6-1.4l.8-12.6M10.2 10.6v6M13.8 10.6v6" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 175,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 174,
  columnNumber: 1
}, this);
_c16 = IconTrash;
export const IconX = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M6.2 6.2l11.6 11.6M17.8 6.2L6.2 17.8" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 181,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 180,
  columnNumber: 1
}, this);
_c17 = IconX;
export const IconPlay = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M8.4 5.2l10 6.8-10 6.8V5.2z" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 187,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 186,
  columnNumber: 1
}, this);
_c18 = IconPlay;
export const IconPause = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M8.6 5.6v12.8M15.4 5.6v12.8", strokeWidth: 2.4 }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 193,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 192,
  columnNumber: 1
}, this);
_c19 = IconPause;
export const IconTimer = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: [
  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "13.2", r: "7.4" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 199,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("path", { d: "M12 9.4v3.8l2.6 1.8M9.8 2.6h4.4" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
    lineNumber: 200,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 198,
  columnNumber: 1
}, this);
_c20 = IconTimer;
export const IconCheck = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M4.8 12.6l4.6 4.6L19.2 7.4" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 206,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 205,
  columnNumber: 1
}, this);
_c21 = IconCheck;
export const IconChevron = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M9.2 5.4l6.6 6.6-6.6 6.6" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 212,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 211,
  columnNumber: 1
}, this);
_c22 = IconChevron;
export const IconRefresh = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M19.6 12a7.6 7.6 0 1 1-2.2-5.4M19.6 3.4v4.2h-4.2" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 218,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 217,
  columnNumber: 1
}, this);
_c23 = IconRefresh;
export const IconGrip = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M6 9h12M6 12h12M6 15h12", strokeWidth: 2.2 }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 224,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 223,
  columnNumber: 1
}, this);
_c24 = IconGrip;
export const IconDumbbell = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M8.2 8.2v7.6M15.8 8.2v7.6M4.6 9.8v4.4M19.4 9.8v4.4M8.2 12h7.6M2.6 12h2M19.4 12h2" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 230,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 229,
  columnNumber: 1
}, this);
_c25 = IconDumbbell;
export const IconFlame = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M12 2.8s6.2 4.6 6.2 10a6.2 6.2 0 0 1-12.4 0c0-2.2 1-4.2 2.4-5.8.2 1.4.9 2.4 2 2.9C10 7.6 10.6 5 12 2.8z" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 236,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 235,
  columnNumber: 1
}, this);
_c26 = IconFlame;
export const IconTrend = (p) => /* @__PURE__ */ jsxDEV("svg", { ...base(p), children: /* @__PURE__ */ jsxDEV("path", { d: "M3.6 16.8l5-5 3.6 3.6 8.2-8.2M15.6 7.2h4.8V12" }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 242,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx",
  lineNumber: 241,
  columnNumber: 1
}, this);
_c27 = IconTrend;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27;
$RefreshReg$(_c, "Futebol");
$RefreshReg$(_c2, "Boxe");
$RefreshReg$(_c3, "JiuJitsu");
$RefreshReg$(_c4, "Basquete");
$RefreshReg$(_c5, "Volei");
$RefreshReg$(_c6, "Corrida");
$RefreshReg$(_c7, "Natacao");
$RefreshReg$(_c8, "Tenis");
$RefreshReg$(_c9, "SportIcon");
$RefreshReg$(_c0, "IconRadar");
$RefreshReg$(_c1, "IconClipboard");
$RefreshReg$(_c10, "IconBolt");
$RefreshReg$(_c11, "IconUser");
$RefreshReg$(_c12, "IconSearch");
$RefreshReg$(_c13, "IconBack");
$RefreshReg$(_c14, "IconPlus");
$RefreshReg$(_c15, "IconMinus");
$RefreshReg$(_c16, "IconTrash");
$RefreshReg$(_c17, "IconX");
$RefreshReg$(_c18, "IconPlay");
$RefreshReg$(_c19, "IconPause");
$RefreshReg$(_c20, "IconTimer");
$RefreshReg$(_c21, "IconCheck");
$RefreshReg$(_c22, "IconChevron");
$RefreshReg$(_c23, "IconRefresh");
$RefreshReg$(_c24, "IconGrip");
$RefreshReg$(_c25, "IconDumbbell");
$RefreshReg$(_c26, "IconFlame");
$RefreshReg$(_c27, "IconTrend");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/Icons.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JJOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJKLE1BQU1BLE9BQU9BLENBQUNDLE9BQVU7QUFBQSxFQUN0QkMsT0FBT0QsRUFBRUUsUUFBUTtBQUFBLEVBQ2pCQyxRQUFRSCxFQUFFRSxRQUFRO0FBQUEsRUFDbEJFLFNBQVM7QUFBQSxFQUNUQyxNQUFNO0FBQUEsRUFDTkMsUUFBUTtBQUFBLEVBQ1JDLGFBQWFQLEVBQUVPLGVBQWU7QUFBQSxFQUM5QkMsZUFBZTtBQUFBLEVBQ2ZDLGdCQUFnQjtBQUFBLEVBQ2hCQyxXQUFXVixFQUFFVTtBQUNmO0FBSUEsTUFBTUMsVUFBVUEsQ0FBQ1gsTUFDZix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYjtBQUFBLHlCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsTUFBSyxHQUFFLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0I7QUFBQSxFQUMvQix1QkFBQyxVQUFLLEdBQUUsK0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtRDtBQUFBLEVBQ25ELHVCQUFDLFVBQUssR0FBRSxvRkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdGO0FBQUEsS0FIMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUlBO0FBQ0FZLEtBTklEO0FBUU4sTUFBTUUsT0FBT0EsQ0FBQ2IsTUFDWix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYjtBQUFBLHlCQUFDLFVBQUssR0FBRSx5SkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTZKO0FBQUEsRUFDN0osdUJBQUMsVUFBSyxHQUFFLG1FQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUU7QUFBQSxLQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BR0E7QUFDQWMsTUFMSUQ7QUFPTixNQUFNRSxXQUFXQSxDQUFDZixNQUNoQix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYjtBQUFBLHlCQUFDLFVBQUssR0FBRSx3REFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTREO0FBQUEsRUFDNUQsdUJBQUMsVUFBSyxHQUFFLE9BQU0sR0FBRSxPQUFNLE9BQU0sT0FBTSxRQUFPLE9BQU0sSUFBRyxPQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFEO0FBQUEsRUFDckQsdUJBQUMsVUFBSyxHQUFFLGtCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBc0I7QUFBQSxLQUh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BSUE7QUFDQWdCLE1BTklEO0FBUU4sTUFBTUUsV0FBV0EsQ0FBQ2pCLE1BQ2hCLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiO0FBQUEseUJBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxNQUFLLEdBQUUsU0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUErQjtBQUFBLEVBQy9CLHVCQUFDLFVBQUssR0FBRSw4QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWtDO0FBQUEsRUFDbEMsdUJBQUMsVUFBSyxHQUFFLGlFQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUU7QUFBQSxLQUh2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BSUE7QUFDQWtCLE1BTklEO0FBUU4sTUFBTUUsUUFBUUEsQ0FBQ25CLE1BQ2IsdUJBQUMsU0FBSSxHQUFJRCxLQUFLQyxDQUFDLEdBQ2I7QUFBQSx5QkFBQyxZQUFPLElBQUcsTUFBSyxJQUFHLE1BQUssR0FBRSxTQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQStCO0FBQUEsRUFDL0IsdUJBQUMsVUFBSyxHQUFFLDRGQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0c7QUFBQSxLQUZsRztBQUFBO0FBQUE7QUFBQTtBQUFBLE9BR0E7QUFDQW9CLE1BTElEO0FBT04sTUFBTUUsVUFBVUEsQ0FBQ3JCLE1BQ2YsdUJBQUMsU0FBSSxHQUFJRCxLQUFLQyxDQUFDLEdBQ2I7QUFBQSx5QkFBQyxVQUFLLEdBQUUsNkVBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpRjtBQUFBLEVBQ2pGLHVCQUFDLFVBQUssR0FBRSxzREFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBEO0FBQUEsS0FGNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUdBO0FBQ0FzQixNQUxJRDtBQU9OLE1BQU1FLFVBQVVBLENBQUN2QixNQUNmLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiO0FBQUEseUJBQUMsWUFBTyxJQUFHLFFBQU8sSUFBRyxPQUFNLEdBQUUsU0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFrQztBQUFBLEVBQ2xDLHVCQUFDLFVBQUssR0FBRSxrQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNDO0FBQUEsRUFDdEMsdUJBQUMsVUFBSyxHQUFFLDRJQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0o7QUFBQSxLQUhsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BSUE7QUFDQXdCLE1BTklEO0FBUU4sTUFBTUUsUUFBUUEsQ0FBQ3pCLE1BQ2IsdUJBQUMsU0FBSSxHQUFJRCxLQUFLQyxDQUFDLEdBQ2I7QUFBQSx5QkFBQyxPQUFFLFdBQVUsb0JBQ1g7QUFBQSwyQkFBQyxhQUFRLElBQUcsTUFBSyxJQUFHLEtBQUksSUFBRyxPQUFNLElBQUcsU0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QztBQUFBLElBQ3pDLHVCQUFDLFVBQUssR0FBRSwyQ0FBMEMsYUFBYSxPQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1FO0FBQUEsT0FGckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBQUEsRUFDQSx1QkFBQyxVQUFLLEdBQUUsd0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QjtBQUFBLEtBTDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FNQTtBQUNBMEIsTUFSSUQ7QUFVQyxnQkFBU0UsVUFBVSxFQUFFQyxJQUFJMUIsTUFBTVEsV0FBV0gsWUFBZ0MsR0FBRztBQUNsRixVQUFRcUIsSUFBRTtBQUFBLElBQ1IsS0FBSztBQUFXLGFBQU8sdUJBQUMsV0FBUSxNQUFZLFdBQXNCLGVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0U7QUFBQSxJQUMzRixLQUFLO0FBQVEsYUFBTyx1QkFBQyxRQUFLLE1BQVksV0FBc0IsZUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLElBQ3JGLEtBQUs7QUFBYSxhQUFPLHVCQUFDLFlBQVMsTUFBWSxXQUFzQixlQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsSUFDOUYsS0FBSztBQUFZLGFBQU8sdUJBQUMsWUFBUyxNQUFZLFdBQXNCLGVBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxJQUM3RixLQUFLO0FBQVMsYUFBTyx1QkFBQyxTQUFNLE1BQVksV0FBc0IsZUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLElBQ3ZGLEtBQUs7QUFBVyxhQUFPLHVCQUFDLFdBQVEsTUFBWSxXQUFzQixlQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9FO0FBQUEsSUFDM0YsS0FBSztBQUFXLGFBQU8sdUJBQUMsV0FBUSxNQUFZLFdBQXNCLGVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0U7QUFBQSxJQUMzRixLQUFLO0FBQVMsYUFBTyx1QkFBQyxTQUFNLE1BQVksV0FBc0IsZUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLElBQ3ZGO0FBQVMsYUFBTyx1QkFBQyxXQUFRLE1BQVksV0FBc0IsZUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRTtBQUFBLEVBQ3RGO0FBQ0Y7QUFFQUMsTUFkZ0JGO0FBZ0JULGFBQU1HLFlBQVlBLENBQUM5QixNQUN4Qix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYjtBQUFBLHlCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsTUFBSyxHQUFFLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0I7QUFBQSxFQUMvQix1QkFBQyxZQUFPLElBQUcsTUFBSyxJQUFHLE1BQUssR0FBRSxPQUFNLGlCQUFnQixXQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVEO0FBQUEsRUFDdkQsdUJBQUMsVUFBSyxHQUFFLG9CQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBd0I7QUFBQSxFQUN4Qix1QkFBQyxZQUFPLElBQUcsUUFBTyxJQUFHLE9BQU0sR0FBRSxRQUFPLE1BQUssZ0JBQWUsUUFBTyxVQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFFO0FBQUEsS0FKdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUtBO0FBQ0ErQixNQVBXRDtBQVNOLGFBQU1FLGdCQUFnQkEsQ0FBQ2hDLE1BQzVCLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiO0FBQUEseUJBQUMsVUFBSyxHQUFFLEtBQUksR0FBRSxPQUFNLE9BQU0sTUFBSyxRQUFPLFFBQU8sSUFBRyxTQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFEO0FBQUEsRUFDckQsdUJBQUMsVUFBSyxHQUFFLHFHQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUc7QUFBQSxLQUYzRztBQUFBO0FBQUE7QUFBQTtBQUFBLE9BR0E7QUFDQWlDLE1BTFdEO0FBT04sYUFBTUUsV0FBV0EsQ0FBQ2xDLE1BQ3ZCLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiLGlDQUFDLFVBQUssR0FBRSxvREFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQXdELEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FFQTtBQUNBbUMsT0FKV0Q7QUFNTixhQUFNRSxXQUFXQSxDQUFDcEMsTUFDdkIsdUJBQUMsU0FBSSxHQUFJRCxLQUFLQyxDQUFDLEdBQ2I7QUFBQSx5QkFBQyxZQUFPLElBQUcsTUFBSyxJQUFHLEtBQUksR0FBRSxTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThCO0FBQUEsRUFDOUIsdUJBQUMsVUFBSyxHQUFFLHFEQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUQ7QUFBQSxLQUYzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BR0E7QUFDQXFDLE9BTFdEO0FBT04sYUFBTUUsYUFBYUEsQ0FBQ3RDLE1BQ3pCLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiO0FBQUEseUJBQUMsWUFBTyxJQUFHLFFBQU8sSUFBRyxRQUFPLEdBQUUsU0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtQztBQUFBLEVBQ25DLHVCQUFDLFVBQUssR0FBRSx3QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTRCO0FBQUEsS0FGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUdBO0FBQ0F1QyxPQUxXRDtBQU9OLGFBQU1FLFdBQVdBLENBQUN4QyxNQUN2Qix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYixpQ0FBQyxVQUFLLEdBQUUsOEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFrQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLE9BRUE7QUFDQXlDLE9BSldEO0FBTU4sYUFBTUUsV0FBV0EsQ0FBQzFDLE1BQ3ZCLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiLGlDQUFDLFVBQUssR0FBRSw4QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQWtDLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FFQTtBQUNBMkMsT0FKV0Q7QUFNTixhQUFNRSxZQUFZQSxDQUFDNUMsTUFDeEIsdUJBQUMsU0FBSSxHQUFJRCxLQUFLQyxDQUFDLEdBQ2IsaUNBQUMsVUFBSyxHQUFFLGtCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBc0IsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBO0FBQ0E2QyxPQUpXRDtBQU1OLGFBQU1FLFlBQVlBLENBQUM5QyxNQUN4Qix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYixpQ0FBQyxVQUFLLEdBQUUsZ0xBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFvTCxLQUR0TDtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BRUE7QUFDQStDLE9BSldEO0FBTU4sYUFBTUUsUUFBUUEsQ0FBQ2hELE1BQ3BCLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiLGlDQUFDLFVBQUssR0FBRSwwQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQThDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FFQTtBQUNBaUQsT0FKV0Q7QUFNTixhQUFNRSxXQUFXQSxDQUFDbEQsTUFDdkIsdUJBQUMsU0FBSSxHQUFJRCxLQUFLQyxDQUFDLEdBQ2IsaUNBQUMsVUFBSyxHQUFFLGlDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBcUMsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBO0FBQ0FtRCxPQUpXRDtBQU1OLGFBQU1FLFlBQVlBLENBQUNwRCxNQUN4Qix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYixpQ0FBQyxVQUFLLEdBQUUsK0JBQThCLGFBQWEsT0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUF1RCxLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BRUE7QUFDQXFELE9BSldEO0FBTU4sYUFBTUUsWUFBWUEsQ0FBQ3RELE1BQ3hCLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiO0FBQUEseUJBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxRQUFPLEdBQUUsU0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpQztBQUFBLEVBQ2pDLHVCQUFDLFVBQUssR0FBRSxxQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlDO0FBQUEsS0FGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUdBO0FBQ0F1RCxPQUxXRDtBQU9OLGFBQU1FLFlBQVlBLENBQUN4RCxNQUN4Qix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYixpQ0FBQyxVQUFLLEdBQUUsZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFvQyxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLE9BRUE7QUFDQXlELE9BSldEO0FBTU4sYUFBTUUsY0FBY0EsQ0FBQzFELE1BQzFCLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiLGlDQUFDLFVBQUssR0FBRSw4QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQWtDLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FFQTtBQUNBMkQsT0FKV0Q7QUFNTixhQUFNRSxjQUFjQSxDQUFDNUQsTUFDMUIsdUJBQUMsU0FBSSxHQUFJRCxLQUFLQyxDQUFDLEdBQ2IsaUNBQUMsVUFBSyxHQUFFLHNEQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBMEQsS0FENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBO0FBQ0E2RCxPQUpXRDtBQU1OLGFBQU1FLFdBQVdBLENBQUM5RCxNQUN2Qix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYixpQ0FBQyxVQUFLLEdBQUUsMkJBQTBCLGFBQWEsT0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BRUE7QUFDQStELE9BSldEO0FBTU4sYUFBTUUsZUFBZUEsQ0FBQ2hFLE1BQzNCLHVCQUFDLFNBQUksR0FBSUQsS0FBS0MsQ0FBQyxHQUNiLGlDQUFDLFVBQUssR0FBRSxzRkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQTBGLEtBRDVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FFQTtBQUNBaUUsT0FKV0Q7QUFNTixhQUFNRSxZQUFZQSxDQUFDbEUsTUFDeEIsdUJBQUMsU0FBSSxHQUFJRCxLQUFLQyxDQUFDLEdBQ2IsaUNBQUMsVUFBSyxHQUFFLDZHQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBaUgsS0FEbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBO0FBQ0FtRSxPQUpXRDtBQU1OLGFBQU1FLFlBQVlBLENBQUNwRSxNQUN4Qix1QkFBQyxTQUFJLEdBQUlELEtBQUtDLENBQUMsR0FDYixpQ0FBQyxVQUFLLEdBQUUsbURBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUF1RCxLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BRUE7QUFDQXFFLE9BSldEO0FBQVMsSUFBQXhELElBQUFFLEtBQUFFLEtBQUFFLEtBQUFFLEtBQUFFLEtBQUFFLEtBQUFFLEtBQUFHLEtBQUFFLEtBQUFFLEtBQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFLE1BQUFFO0FBQUEsYUFBQXpELElBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBRSxNQUFBIiwibmFtZXMiOlsiYmFzZSIsInAiLCJ3aWR0aCIsInNpemUiLCJoZWlnaHQiLCJ2aWV3Qm94IiwiZmlsbCIsInN0cm9rZSIsInN0cm9rZVdpZHRoIiwic3Ryb2tlTGluZWNhcCIsInN0cm9rZUxpbmVqb2luIiwiY2xhc3NOYW1lIiwiRnV0ZWJvbCIsIl9jIiwiQm94ZSIsIl9jMiIsIkppdUppdHN1IiwiX2MzIiwiQmFzcXVldGUiLCJfYzQiLCJWb2xlaSIsIl9jNSIsIkNvcnJpZGEiLCJfYzYiLCJOYXRhY2FvIiwiX2M3IiwiVGVuaXMiLCJfYzgiLCJTcG9ydEljb24iLCJpZCIsIl9jOSIsIkljb25SYWRhciIsIl9jMCIsIkljb25DbGlwYm9hcmQiLCJfYzEiLCJJY29uQm9sdCIsIl9jMTAiLCJJY29uVXNlciIsIl9jMTEiLCJJY29uU2VhcmNoIiwiX2MxMiIsIkljb25CYWNrIiwiX2MxMyIsIkljb25QbHVzIiwiX2MxNCIsIkljb25NaW51cyIsIl9jMTUiLCJJY29uVHJhc2giLCJfYzE2IiwiSWNvblgiLCJfYzE3IiwiSWNvblBsYXkiLCJfYzE4IiwiSWNvblBhdXNlIiwiX2MxOSIsIkljb25UaW1lciIsIl9jMjAiLCJJY29uQ2hlY2siLCJfYzIxIiwiSWNvbkNoZXZyb24iLCJfYzIyIiwiSWNvblJlZnJlc2giLCJfYzIzIiwiSWNvbkdyaXAiLCJfYzI0IiwiSWNvbkR1bWJiZWxsIiwiX2MyNSIsIkljb25GbGFtZSIsIl9jMjYiLCJJY29uVHJlbmQiLCJfYzI3Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkljb25zLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbnRlcmZhY2UgUCB7XHJcbiAgc2l6ZT86IG51bWJlcjtcclxuICBjbGFzc05hbWU/OiBzdHJpbmc7XHJcbiAgc3Ryb2tlV2lkdGg/OiBudW1iZXI7XHJcbn1cclxuXHJcbmNvbnN0IGJhc2UgPSAocDogUCkgPT4gKHtcclxuICB3aWR0aDogcC5zaXplID8/IDIwLFxyXG4gIGhlaWdodDogcC5zaXplID8/IDIwLFxyXG4gIHZpZXdCb3g6IFwiMCAwIDI0IDI0XCIsXHJcbiAgZmlsbDogXCJub25lXCIsXHJcbiAgc3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxyXG4gIHN0cm9rZVdpZHRoOiBwLnN0cm9rZVdpZHRoID8/IDEuOCxcclxuICBzdHJva2VMaW5lY2FwOiBcInJvdW5kXCIgYXMgY29uc3QsXHJcbiAgc3Ryb2tlTGluZWpvaW46IFwicm91bmRcIiBhcyBjb25zdCxcclxuICBjbGFzc05hbWU6IHAuY2xhc3NOYW1lLFxyXG59KTtcclxuXHJcbi8qID09PT09PT09PT09PT09PT09IFNQT1JUIElDT05TID09PT09PT09PT09PT09PT09ICovXHJcblxyXG5jb25zdCBGdXRlYm9sID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiOC42XCIgLz5cclxuICAgIDxwYXRoIGQ9XCJNMTIgOC40bDMuNCAyLjUtMS4zIDRoLTQuMmwtMS4zLTRMMTIgOC40elwiIC8+XHJcbiAgICA8cGF0aCBkPVwiTTEyIDguNFYzLjRNMTUuNCAxMC45bDQuOC0xLjVNMTQuMSAxNC45bDMgNC4xTTkuOSAxNC45bC0zIDQuMU04LjYgMTAuOUwzLjggOS40XCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmNvbnN0IEJveGUgPSAocDogUCkgPT4gKFxyXG4gIDxzdmcgey4uLmJhc2UocCl9PlxyXG4gICAgPHBhdGggZD1cIk04LjUgMy44aDQuMmE0LjMgNC4zIDAgMCAxIDQuMyA0LjN2My4xYTQuNiA0LjYgMCAwIDEtNC42IDQuNkgxMGEzLjUgMy41IDAgMCAxLTMuNS0zLjV2LS42bC0xLjYtMS41YTIuNiAyLjYgMCAwIDEgMC0zLjdsMS45LTEuN2EyLjQgMi40IDAgMCAxIDEuNy0xelwiIC8+XHJcbiAgICA8cGF0aCBkPVwiTTggMTUuOHYyLjRhMiAyIDAgMCAwIDIgMmgzLjZhMiAyIDAgMCAwIDItMnYtMi40TTEyLjcgMy44djUuNFwiIC8+XHJcbiAgPC9zdmc+XHJcbik7XHJcblxyXG5jb25zdCBKaXVKaXRzdSA9IChwOiBQKSA9PiAoXHJcbiAgPHN2ZyB7Li4uYmFzZShwKX0+XHJcbiAgICA8cGF0aCBkPVwiTTMuNSA2LjVsNi4yIDUuNS02LjIgNS41TTIwLjUgNi41bC02LjIgNS41IDYuMiA1LjVcIiAvPlxyXG4gICAgPHJlY3QgeD1cIjkuOFwiIHk9XCI5LjhcIiB3aWR0aD1cIjQuNFwiIGhlaWdodD1cIjQuNFwiIHJ4PVwiMVwiIC8+XHJcbiAgICA8cGF0aCBkPVwiTTEyIDE0LjJ2NC4zXCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmNvbnN0IEJhc3F1ZXRlID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiOC42XCIgLz5cclxuICAgIDxwYXRoIGQ9XCJNMTIgMy40djE3LjJNMy40IDEyaDE3LjJcIiAvPlxyXG4gICAgPHBhdGggZD1cIk02IDUuNGExMS42IDExLjYgMCAwIDEgMCAxMy4yTTE4IDUuNGExMS42IDExLjYgMCAwIDAgMCAxMy4yXCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmNvbnN0IFZvbGVpID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiOC42XCIgLz5cclxuICAgIDxwYXRoIGQ9XCJNMTIgMy40YzEgMy40LjQgNi42LTEuOCA4LjlNMTIgMTIuM2MzLjMgMSA2LjUuMyA4LjYtMS44TTEyIDEyLjNjLTIuMyAyLjQtNS41IDMtOC44IDIuM1wiIC8+XHJcbiAgPC9zdmc+XHJcbik7XHJcblxyXG5jb25zdCBDb3JyaWRhID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxwYXRoIGQ9XCJNMyAxNi4yYzAtMS40IDEtMi4yIDIuNC0yLjJoNC40bDIuMy0zLjQgMi4yIDEuMWMzIC4xIDUuNyAyLjEgNi43IDQuNUgzelwiIC8+XHJcbiAgICA8cGF0aCBkPVwiTTMgMTYuMnYxLjZoMTh2LTEuNk05LjUgMTAuNUw4LjIgOC42TTE0LjYgMTRoMi42XCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmNvbnN0IE5hdGFjYW8gPSAocDogUCkgPT4gKFxyXG4gIDxzdmcgey4uLmJhc2UocCl9PlxyXG4gICAgPGNpcmNsZSBjeD1cIjE2LjRcIiBjeT1cIjYuNFwiIHI9XCIxLjlcIiAvPlxyXG4gICAgPHBhdGggZD1cIk00IDkuNmMyLjgtMi40IDYtMi45IDkuNC0xLjRcIiAvPlxyXG4gICAgPHBhdGggZD1cIk0yLjggMTQuMmMxLjctMS43IDMuNS0xLjcgNS4yIDBzMy41IDEuNyA1LjIgMCAzLjUtMS43IDUuMiAwIDIuNiAxLjQgMi44IDEuMk0yLjggMTguOGMxLjctMS43IDMuNS0xLjcgNS4yIDBzMy41IDEuNyA1LjIgMCAzLjUtMS43IDUuMiAwXCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmNvbnN0IFRlbmlzID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxnIHRyYW5zZm9ybT1cInJvdGF0ZSgtMjggMTAgOSlcIj5cclxuICAgICAgPGVsbGlwc2UgY3g9XCIxMFwiIGN5PVwiOVwiIHJ4PVwiNS40XCIgcnk9XCI2LjRcIiAvPlxyXG4gICAgICA8cGF0aCBkPVwiTTEwIDIuNnYxMi44TTQuOSA2LjZoMTAuMk00LjkgMTEuNGgxMC4yXCIgc3Ryb2tlV2lkdGg9ezEuMX0gLz5cclxuICAgIDwvZz5cclxuICAgIDxwYXRoIGQ9XCJNMTMuMiAxNC42TDE5IDIwLjRcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNwb3J0SWNvbih7IGlkLCBzaXplLCBjbGFzc05hbWUsIHN0cm9rZVdpZHRoIH06IFAgJiB7IGlkOiBzdHJpbmcgfSkge1xyXG4gIHN3aXRjaCAoaWQpIHtcclxuICAgIGNhc2UgXCJmdXRlYm9sXCI6IHJldHVybiA8RnV0ZWJvbCBzaXplPXtzaXplfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gc3Ryb2tlV2lkdGg9e3N0cm9rZVdpZHRofSAvPjtcclxuICAgIGNhc2UgXCJib3hlXCI6IHJldHVybiA8Qm94ZSBzaXplPXtzaXplfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gc3Ryb2tlV2lkdGg9e3N0cm9rZVdpZHRofSAvPjtcclxuICAgIGNhc2UgXCJqaXUtaml0c3VcIjogcmV0dXJuIDxKaXVKaXRzdSBzaXplPXtzaXplfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gc3Ryb2tlV2lkdGg9e3N0cm9rZVdpZHRofSAvPjtcclxuICAgIGNhc2UgXCJiYXNxdWV0ZVwiOiByZXR1cm4gPEJhc3F1ZXRlIHNpemU9e3NpemV9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSBzdHJva2VXaWR0aD17c3Ryb2tlV2lkdGh9IC8+O1xyXG4gICAgY2FzZSBcInZvbGVpXCI6IHJldHVybiA8Vm9sZWkgc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IHN0cm9rZVdpZHRoPXtzdHJva2VXaWR0aH0gLz47XHJcbiAgICBjYXNlIFwiY29ycmlkYVwiOiByZXR1cm4gPENvcnJpZGEgc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IHN0cm9rZVdpZHRoPXtzdHJva2VXaWR0aH0gLz47XHJcbiAgICBjYXNlIFwibmF0YWNhb1wiOiByZXR1cm4gPE5hdGFjYW8gc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IHN0cm9rZVdpZHRoPXtzdHJva2VXaWR0aH0gLz47XHJcbiAgICBjYXNlIFwidGVuaXNcIjogcmV0dXJuIDxUZW5pcyBzaXplPXtzaXplfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gc3Ryb2tlV2lkdGg9e3N0cm9rZVdpZHRofSAvPjtcclxuICAgIGRlZmF1bHQ6IHJldHVybiA8RnV0ZWJvbCBzaXplPXtzaXplfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gc3Ryb2tlV2lkdGg9e3N0cm9rZVdpZHRofSAvPjtcclxuICB9XHJcbn1cclxuXHJcbi8qID09PT09PT09PT09PT09PT09IFVJIElDT05TID09PT09PT09PT09PT09PT09ICovXHJcblxyXG5leHBvcnQgY29uc3QgSWNvblJhZGFyID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiOC42XCIgLz5cclxuICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiNC42XCIgc3Ryb2tlRGFzaGFycmF5PVwiMi41IDNcIiAvPlxyXG4gICAgPHBhdGggZD1cIk0xMiAxMmw1LjQtNS40XCIgLz5cclxuICAgIDxjaXJjbGUgY3g9XCIxNC42XCIgY3k9XCI5LjRcIiByPVwiMS4xNVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBzdHJva2U9XCJub25lXCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmV4cG9ydCBjb25zdCBJY29uQ2xpcGJvYXJkID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxyZWN0IHg9XCI1XCIgeT1cIjQuNFwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCIxNi4yXCIgcng9XCIyLjRcIiAvPlxyXG4gICAgPHBhdGggZD1cIk05IDQuNFYzLjJBMS4yIDEuMiAwIDAgMSAxMC4yIDJoMy42QTEuMiAxLjIgMCAwIDEgMTUgMy4ydjEuMk04LjYgMTAuNGg2LjhNOC42IDE0aDQuNk04LjYgMTcuNGgzXCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmV4cG9ydCBjb25zdCBJY29uQm9sdCA9IChwOiBQKSA9PiAoXHJcbiAgPHN2ZyB7Li4uYmFzZShwKX0+XHJcbiAgICA8cGF0aCBkPVwiTTEzLjIgMi42TDUuNiAxMy40aDUuMmwtMSA4IDcuNi0xMC44aC01LjJsMS04elwiIC8+XHJcbiAgPC9zdmc+XHJcbik7XHJcblxyXG5leHBvcnQgY29uc3QgSWNvblVzZXIgPSAocDogUCkgPT4gKFxyXG4gIDxzdmcgey4uLmJhc2UocCl9PlxyXG4gICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCI4XCIgcj1cIjMuOFwiIC8+XHJcbiAgICA8cGF0aCBkPVwiTTQuNCAyMC40YzEuMy0zLjYgNC01LjQgNy42LTUuNHM2LjMgMS44IDcuNiA1LjRcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IEljb25TZWFyY2ggPSAocDogUCkgPT4gKFxyXG4gIDxzdmcgey4uLmJhc2UocCl9PlxyXG4gICAgPGNpcmNsZSBjeD1cIjEwLjZcIiBjeT1cIjEwLjZcIiByPVwiNi4yXCIgLz5cclxuICAgIDxwYXRoIGQ9XCJNMTUuNCAxNS40bDQuNiA0LjZcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IEljb25CYWNrID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxwYXRoIGQ9XCJNMTQuOCA1LjRMOC4yIDEybDYuNiA2LjZcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IEljb25QbHVzID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxwYXRoIGQ9XCJNMTIgNS40djEzLjJNNS40IDEyaDEzLjJcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IEljb25NaW51cyA9IChwOiBQKSA9PiAoXHJcbiAgPHN2ZyB7Li4uYmFzZShwKX0+XHJcbiAgICA8cGF0aCBkPVwiTTUuNCAxMmgxMy4yXCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmV4cG9ydCBjb25zdCBJY29uVHJhc2ggPSAocDogUCkgPT4gKFxyXG4gIDxzdmcgey4uLmJhc2UocCl9PlxyXG4gICAgPHBhdGggZD1cIk00LjQgNi42aDE1LjJNOS42IDYuNlY0LjhBMS40IDEuNCAwIDAgMSAxMSAzLjRoMmExLjQgMS40IDAgMCAxIDEuNCAxLjR2MS44TTYuNCA2LjZsLjggMTIuNmExLjYgMS42IDAgMCAwIDEuNiAxLjRoNi40YTEuNiAxLjYgMCAwIDAgMS42LTEuNGwuOC0xMi42TTEwLjIgMTAuNnY2TTEzLjggMTAuNnY2XCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmV4cG9ydCBjb25zdCBJY29uWCA9IChwOiBQKSA9PiAoXHJcbiAgPHN2ZyB7Li4uYmFzZShwKX0+XHJcbiAgICA8cGF0aCBkPVwiTTYuMiA2LjJsMTEuNiAxMS42TTE3LjggNi4yTDYuMiAxNy44XCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmV4cG9ydCBjb25zdCBJY29uUGxheSA9IChwOiBQKSA9PiAoXHJcbiAgPHN2ZyB7Li4uYmFzZShwKX0+XHJcbiAgICA8cGF0aCBkPVwiTTguNCA1LjJsMTAgNi44LTEwIDYuOFY1LjJ6XCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmV4cG9ydCBjb25zdCBJY29uUGF1c2UgPSAocDogUCkgPT4gKFxyXG4gIDxzdmcgey4uLmJhc2UocCl9PlxyXG4gICAgPHBhdGggZD1cIk04LjYgNS42djEyLjhNMTUuNCA1LjZ2MTIuOFwiIHN0cm9rZVdpZHRoPXsyLjR9IC8+XHJcbiAgPC9zdmc+XHJcbik7XHJcblxyXG5leHBvcnQgY29uc3QgSWNvblRpbWVyID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTMuMlwiIHI9XCI3LjRcIiAvPlxyXG4gICAgPHBhdGggZD1cIk0xMiA5LjR2My44bDIuNiAxLjhNOS44IDIuNmg0LjRcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IEljb25DaGVjayA9IChwOiBQKSA9PiAoXHJcbiAgPHN2ZyB7Li4uYmFzZShwKX0+XHJcbiAgICA8cGF0aCBkPVwiTTQuOCAxMi42bDQuNiA0LjZMMTkuMiA3LjRcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IEljb25DaGV2cm9uID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxwYXRoIGQ9XCJNOS4yIDUuNGw2LjYgNi42LTYuNiA2LjZcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IEljb25SZWZyZXNoID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxwYXRoIGQ9XCJNMTkuNiAxMmE3LjYgNy42IDAgMSAxLTIuMi01LjRNMTkuNiAzLjR2NC4yaC00LjJcIiAvPlxyXG4gIDwvc3ZnPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IEljb25HcmlwID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxwYXRoIGQ9XCJNNiA5aDEyTTYgMTJoMTJNNiAxNWgxMlwiIHN0cm9rZVdpZHRoPXsyLjJ9IC8+XHJcbiAgPC9zdmc+XHJcbik7XHJcblxyXG5leHBvcnQgY29uc3QgSWNvbkR1bWJiZWxsID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxwYXRoIGQ9XCJNOC4yIDguMnY3LjZNMTUuOCA4LjJ2Ny42TTQuNiA5Ljh2NC40TTE5LjQgOS44djQuNE04LjIgMTJoNy42TTIuNiAxMmgyTTE5LjQgMTJoMlwiIC8+XHJcbiAgPC9zdmc+XHJcbik7XHJcblxyXG5leHBvcnQgY29uc3QgSWNvbkZsYW1lID0gKHA6IFApID0+IChcclxuICA8c3ZnIHsuLi5iYXNlKHApfT5cclxuICAgIDxwYXRoIGQ9XCJNMTIgMi44czYuMiA0LjYgNi4yIDEwYTYuMiA2LjIgMCAwIDEtMTIuNCAwYzAtMi4yIDEtNC4yIDIuNC01LjguMiAxLjQuOSAyLjQgMiAyLjlDMTAgNy42IDEwLjYgNSAxMiAyLjh6XCIgLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmV4cG9ydCBjb25zdCBJY29uVHJlbmQgPSAocDogUCkgPT4gKFxyXG4gIDxzdmcgey4uLmJhc2UocCl9PlxyXG4gICAgPHBhdGggZD1cIk0zLjYgMTYuOGw1LTUgMy42IDMuNiA4LjItOC4yTTE1LjYgNy4yaDQuOFYxMlwiIC8+XHJcbiAgPC9zdmc+XHJcbik7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvbHVpenIvT25lRHJpdmUvRG9jdW1lbnRvcy9wcm9ncmFtYXMtZ2l0L3VsdHJhLWV4ZXJjaXNlcy91bHRyYS1leGVyY2lzZXMvc3JjL2NvbXBvbmVudHMvSWNvbnMudHN4In0=