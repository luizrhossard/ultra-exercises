import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8a41314"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=a8a41314"; const lazy = __vite__cjsImport3_react["lazy"]; const Suspense = __vite__cjsImport3_react["Suspense"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { AnimatePresence, MotionConfig, motion } from "/node_modules/.vite/deps/framer-motion.js?v=a8a41314";
import { AppProvider, useApp } from "/src/store.tsx";
import BottomNav from "/src/components/BottomNav.tsx";
import Sidebar from "/src/components/Sidebar.tsx";
import { ErrorBoundary } from "/src/components/ErrorBoundary.tsx";
import { IconBolt } from "/src/components/Icons.tsx";
const Auth = lazy(_c = () => import("/src/screens/Auth.tsx"));
_c2 = Auth;
const Onboarding = lazy(_c3 = () => import("/src/screens/Onboarding.tsx"));
_c4 = Onboarding;
const Feed = lazy(_c5 = () => import("/src/screens/Feed.tsx"));
_c6 = Feed;
const Routines = lazy(_c7 = () => import("/src/screens/Routines.tsx"));
_c8 = Routines;
const Progress = lazy(_c9 = () => import("/src/screens/Progress.tsx"));
_c0 = Progress;
const Profile = lazy(_c1 = () => import("/src/screens/Profile.tsx"));
_c10 = Profile;
const Player = lazy(_c11 = () => import("/src/screens/Player.tsx"));
_c12 = Player;
const SharedRoutine = lazy(_c13 = () => import("/src/screens/SharedRoutine.tsx"));
_c14 = SharedRoutine;
function ScreenFallback() {
  return /* @__PURE__ */ jsxDEV("div", { className: "grid min-h-[40dvh] place-items-center", children: /* @__PURE__ */ jsxDEV("span", { role: "status", "aria-label": "Carregando", className: "tabular font-display text-lg uppercase tracking-[0.2em] text-volt-400", children: "Carregando…" }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
    lineNumber: 40,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}
_c15 = ScreenFallback;
function Toasts() {
  _s();
  const { toasts } = useApp();
  return /* @__PURE__ */ jsxDEV("div", { className: "pointer-events-none fixed inset-x-0 bottom-24 z-[70] mx-auto flex w-full max-w-[430px] flex-col items-center gap-2 px-6 lg:bottom-8 lg:max-w-none", children: /* @__PURE__ */ jsxDEV(AnimatePresence, { children: toasts.map(
    (t) => /* @__PURE__ */ jsxDEV(
      motion.div,
      {
        initial: { opacity: 0, y: 18, scale: 0.94 },
        animate: { opacity: 1, y: 0, scale: 1 },
        exit: { opacity: 0, y: 8, scale: 0.96 },
        className: "flex items-center gap-2 rounded-xl px-4 py-2.5 text-[12px] font-bold text-ink-950 shadow-[0_12px_36px_rgba(0,0,0,0.45)]",
        style: { background: t.color ?? "#d4f53c" },
        children: [
          /* @__PURE__ */ jsxDEV(IconBolt, { size: 14, strokeWidth: 2.4 }, void 0, false, {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
            lineNumber: 61,
            columnNumber: 13
          }, this),
          t.msg
        ]
      },
      t.id,
      true,
      {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
        lineNumber: 53,
        columnNumber: 9
      },
      this
    )
  ) }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
    lineNumber: 51,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
    lineNumber: 50,
    columnNumber: 5
  }, this);
}
_s(Toasts, "Ve9jrQ9jRkUhW1Hvf3SL4YMZ7Ck=", false, function() {
  return [useApp];
});
_c16 = Toasts;
function Shell() {
  _s2();
  const { profile, tab, playerId, token, authLoading } = useApp();
  const sharedToken = useMemo(() => {
    const match = window.location.pathname.match(/^\/compartilhada\/([A-Za-z0-9_-]+)$/);
    return match ? match[1] : null;
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "noise relative min-h-dvh", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pointer-events-none fixed inset-0 z-0 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid-bg absolute inset-0" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "glow-drift absolute -top-24 left-[8%] h-80 w-80 rounded-full bg-[rgba(212,245,60,0.07)] blur-3xl" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "glow-drift-slow absolute right-[4%] top-1/3 h-96 w-96 rounded-full bg-[rgba(52,217,123,0.06)] blur-3xl" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
        lineNumber: 84,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "glow-drift absolute -bottom-20 left-1/3 h-72 w-72 rounded-full bg-[rgba(255,81,72,0.05)] blur-3xl" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
        lineNumber: 85,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 81,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "p",
      {
        className: "fixed right-6 top-1/2 z-0 hidden -translate-y-1/2 rotate-180 font-display text-sm uppercase tracking-[0.5em] text-fog-mute/50 xl:block",
        style: { writingMode: "vertical-rl" },
        children: "exercise × sport · relevance 1–5"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
        lineNumber: 89,
        columnNumber: 7
      },
      this
    ),
    token && !sharedToken && /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 96,
      columnNumber: 33
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `relative z-10 ${token && !sharedToken ? "lg:pl-[260px]" : ""}`, children: /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 mx-auto flex min-h-dvh w-full max-w-[430px] flex-col border-x border-ink-800 bg-ink-900/70 backdrop-blur-sm lg:max-w-[1120px] lg:bg-ink-900/50", children: sharedToken ? /* @__PURE__ */ jsxDEV(Suspense, { fallback: /* @__PURE__ */ jsxDEV(ScreenFallback, {}, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 102,
      columnNumber: 31
    }, this), children: /* @__PURE__ */ jsxDEV(SharedRoutine, { token: sharedToken }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 102,
      columnNumber: 51
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 102,
      columnNumber: 11
    }, this) : authLoading ? /* @__PURE__ */ jsxDEV("div", { className: "grid min-h-dvh place-items-center font-display text-xl uppercase text-volt-400", children: "Carregando…" }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 103,
      columnNumber: 25
    }, this) : !token ? /* @__PURE__ */ jsxDEV(Suspense, { fallback: /* @__PURE__ */ jsxDEV(ScreenFallback, {}, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 104,
      columnNumber: 31
    }, this), children: /* @__PURE__ */ jsxDEV(Auth, {}, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 104,
      columnNumber: 51
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 104,
      columnNumber: 11
    }, this) : !profile.onboarded ? /* @__PURE__ */ jsxDEV(Suspense, { fallback: /* @__PURE__ */ jsxDEV(ScreenFallback, {}, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 106,
      columnNumber: 31
    }, this), children: /* @__PURE__ */ jsxDEV(Onboarding, {}, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 106,
      columnNumber: 51
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 106,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(AnimatePresence, { mode: "wait", children: /* @__PURE__ */ jsxDEV(
        motion.main,
        {
          initial: { opacity: 0, y: 16 },
          animate: { opacity: 1, y: 0 },
          exit: { opacity: 0, y: -10 },
          transition: { duration: 0.24, ease: "easeOut" },
          className: "flex-1",
          children: /* @__PURE__ */ jsxDEV(Suspense, { fallback: /* @__PURE__ */ jsxDEV(ScreenFallback, {}, void 0, false, {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
            lineNumber: 118,
            columnNumber: 37
          }, this), children: [
            tab === "explorar" && /* @__PURE__ */ jsxDEV(Feed, {}, void 0, false, {
              fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
              lineNumber: 119,
              columnNumber: 42
            }, this),
            tab === "rotinas" && /* @__PURE__ */ jsxDEV(Routines, {}, void 0, false, {
              fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
              lineNumber: 120,
              columnNumber: 41
            }, this),
            tab === "progresso" && /* @__PURE__ */ jsxDEV(Progress, {}, void 0, false, {
              fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
              lineNumber: 121,
              columnNumber: 43
            }, this),
            tab === "perfil" && /* @__PURE__ */ jsxDEV(Profile, {}, void 0, false, {
              fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
              lineNumber: 122,
              columnNumber: 40
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
            lineNumber: 118,
            columnNumber: 17
          }, this)
        },
        tab,
        false,
        {
          fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
          lineNumber: 110,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
        lineNumber: 109,
        columnNumber: 13
      }, this),
      !sharedToken && /* @__PURE__ */ jsxDEV("div", { className: "lg:hidden", children: /* @__PURE__ */ jsxDEV(BottomNav, {}, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
        lineNumber: 128,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
        lineNumber: 127,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 108,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 99,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(AnimatePresence, { children: playerId && profile.onboarded && /* @__PURE__ */ jsxDEV(Suspense, { fallback: /* @__PURE__ */ jsxDEV(ScreenFallback, {}, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 138,
      columnNumber: 29
    }, this), children: /* @__PURE__ */ jsxDEV(Player, {}, playerId, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 139,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 138,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 136,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Toasts, {}, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
      lineNumber: 143,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
    lineNumber: 79,
    columnNumber: 5
  }, this);
}
_s2(Shell, "vGUyJj8jp2D3njjLKLSh+LnnOXY=", false, function() {
  return [useApp];
});
_c17 = Shell;
export default function App() {
  return /* @__PURE__ */ jsxDEV(MotionConfig, { reducedMotion: "user", children: /* @__PURE__ */ jsxDEV(AppProvider, { children: /* @__PURE__ */ jsxDEV(ErrorBoundary, { children: /* @__PURE__ */ jsxDEV(Shell, {}, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
    lineNumber: 153,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
    lineNumber: 152,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
    lineNumber: 151,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx",
    lineNumber: 150,
    columnNumber: 5
  }, this);
}
_c18 = App;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18;
$RefreshReg$(_c, "Auth$lazy");
$RefreshReg$(_c2, "Auth");
$RefreshReg$(_c3, "Onboarding$lazy");
$RefreshReg$(_c4, "Onboarding");
$RefreshReg$(_c5, "Feed$lazy");
$RefreshReg$(_c6, "Feed");
$RefreshReg$(_c7, "Routines$lazy");
$RefreshReg$(_c8, "Routines");
$RefreshReg$(_c9, "Progress$lazy");
$RefreshReg$(_c0, "Progress");
$RefreshReg$(_c1, "Profile$lazy");
$RefreshReg$(_c10, "Profile");
$RefreshReg$(_c11, "Player$lazy");
$RefreshReg$(_c12, "Player");
$RefreshReg$(_c13, "SharedRoutine$lazy");
$RefreshReg$(_c14, "SharedRoutine");
$RefreshReg$(_c15, "ScreenFallback");
$RefreshReg$(_c16, "Toasts");
$RefreshReg$(_c17, "Shell");
$RefreshReg$(_c18, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JNLFNBb0VJLFVBcEVKOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBCTixTQUFTQSxNQUFNQyxVQUFVQyxlQUFlO0FBQ3hDLFNBQVNDLGlCQUFpQkMsY0FBY0MsY0FBYztBQUN0RCxTQUFTQyxhQUFhQyxjQUFjO0FBQ3BDLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLE9BQU9aLEtBQUlhLEtBQUNBLE1BQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUFFQyxNQUE1Q0Y7QUFDTixNQUFNRyxhQUFhZixLQUFJZ0IsTUFBQ0EsTUFBTSxPQUFPLHNCQUFzQixDQUFDO0FBQUVDLE1BQXhERjtBQUNOLE1BQU1HLE9BQU9sQixLQUFJbUIsTUFBQ0EsTUFBTSxPQUFPLGdCQUFnQixDQUFDO0FBQUVDLE1BQTVDRjtBQUNOLE1BQU1HLFdBQVdyQixLQUFJc0IsTUFBQ0EsTUFBTSxPQUFPLG9CQUFvQixDQUFDO0FBQUVDLE1BQXBERjtBQUNOLE1BQU1HLFdBQVd4QixLQUFJeUIsTUFBQ0EsTUFBTSxPQUFPLG9CQUFvQixDQUFDO0FBQUVDLE1BQXBERjtBQUNOLE1BQU1HLFVBQVUzQixLQUFJNEIsTUFBQ0EsTUFBTSxPQUFPLG1CQUFtQixDQUFDO0FBQUVDLE9BQWxERjtBQUNOLE1BQU1HLFNBQVM5QixLQUFJK0IsT0FBQ0EsTUFBTSxPQUFPLGtCQUFrQixDQUFDO0FBQUVDLE9BQWhERjtBQUNOLE1BQU1HLGdCQUFnQmpDLEtBQUlrQyxPQUFDQSxNQUFNLE9BQU8seUJBQXlCLENBQUM7QUFBRUMsT0FBOURGO0FBRU4sU0FBU0csaUJBQWlCO0FBQ3hCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHlDQUNiLGlDQUFDLFVBQUssTUFBSyxVQUFTLGNBQVcsY0FBYSxXQUFVLHlFQUF3RSwyQkFBOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBRUo7QUFBQ0MsT0FSUUQ7QUFVVCxTQUFTRSxTQUFTO0FBQUFDLEtBQUE7QUFDaEIsUUFBTSxFQUFFQyxPQUFPLElBQUlqQyxPQUFPO0FBQzFCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHFKQUNiLGlDQUFDLG1CQUNFaUMsaUJBQU9DO0FBQUFBLElBQUksQ0FBQ0MsTUFDWDtBQUFBLE1BQUMsT0FBTztBQUFBLE1BQVA7QUFBQSxRQUVDLFNBQVMsRUFBRUMsU0FBUyxHQUFHQyxHQUFHLElBQUlDLE9BQU8sS0FBSztBQUFBLFFBQzFDLFNBQVMsRUFBRUYsU0FBUyxHQUFHQyxHQUFHLEdBQUdDLE9BQU8sRUFBRTtBQUFBLFFBQ3RDLE1BQU0sRUFBRUYsU0FBUyxHQUFHQyxHQUFHLEdBQUdDLE9BQU8sS0FBSztBQUFBLFFBQ3RDLFdBQVU7QUFBQSxRQUNWLE9BQU8sRUFBRUMsWUFBWUosRUFBRUssU0FBUyxVQUFVO0FBQUEsUUFFMUM7QUFBQSxpQ0FBQyxZQUFTLE1BQU0sSUFBSSxhQUFhLE9BQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDO0FBQUEsVUFDcENMLEVBQUVNO0FBQUFBO0FBQUFBO0FBQUFBLE1BUkVOLEVBQUVPO0FBQUFBLE1BRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVVBO0FBQUEsRUFDRCxLQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFDVixHQXJCUUQsUUFBTTtBQUFBLFVBQ00vQixNQUFNO0FBQUE7QUFBQSxPQURsQitCO0FBdUJULFNBQVNZLFFBQVE7QUFBQUMsTUFBQTtBQUNmLFFBQU0sRUFBRUMsU0FBU0MsS0FBS0MsVUFBVUMsT0FBT0MsWUFBWSxJQUFJakQsT0FBTztBQUU5RCxRQUFNa0QsY0FBY3ZELFFBQVEsTUFBTTtBQUNoQyxVQUFNd0QsUUFBUUMsT0FBT0MsU0FBU0MsU0FBU0gsTUFBTSxxQ0FBcUM7QUFDbEYsV0FBT0EsUUFBUUEsTUFBTSxDQUFDLElBQUk7QUFBQSxFQUM1QixHQUFHLEVBQUU7QUFFTCxTQUNFLHVCQUFDLFNBQUksV0FBVSw0QkFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSx5REFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw4QkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsTUFDekMsdUJBQUMsU0FBSSxXQUFVLHNHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUg7QUFBQSxNQUNqSCx1QkFBQyxTQUFJLFdBQVUsNEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1SDtBQUFBLE1BQ3ZILHVCQUFDLFNBQUksV0FBVSx1R0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtIO0FBQUEsU0FKcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsT0FBTyxFQUFFSSxhQUFhLGNBQWM7QUFBQSxRQUFFO0FBQUE7QUFBQSxNQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLQTtBQUFBLElBRUNQLFNBQVMsQ0FBQ0UsZUFBZSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBR2xDLHVCQUFDLFNBQUksV0FBVyxpQkFBaUJGLFNBQVMsQ0FBQ0UsY0FBYyxrQkFBa0IsRUFBRSxJQUM3RSxpQ0FBQyxTQUFJLFdBQVUsZ0tBQ1pBLHdCQUNDLHVCQUFDLFlBQVMsVUFBVSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWUsR0FBSyxpQ0FBQyxpQkFBYyxPQUFPQSxlQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkUsSUFDM0VELGNBQWMsdUJBQUMsU0FBSSxXQUFVLGtGQUFpRiwyQkFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRyxJQUFTLENBQUNELFFBQ3JJLHVCQUFDLFlBQVMsVUFBVSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWUsR0FBSyxpQ0FBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSyxLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdELElBQzlDLENBQUNILFFBQVFXLFlBQ1gsdUJBQUMsWUFBUyxVQUFVLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxHQUFLLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVyxLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNELElBRXRELG1DQUNFO0FBQUEsNkJBQUMsbUJBQWdCLE1BQUssUUFDcEI7QUFBQSxRQUFDLE9BQU87QUFBQSxRQUFQO0FBQUEsVUFFQyxTQUFTLEVBQUVwQixTQUFTLEdBQUdDLEdBQUcsR0FBRztBQUFBLFVBQzdCLFNBQVMsRUFBRUQsU0FBUyxHQUFHQyxHQUFHLEVBQUU7QUFBQSxVQUM1QixNQUFNLEVBQUVELFNBQVMsR0FBR0MsR0FBRyxJQUFJO0FBQUEsVUFDM0IsWUFBWSxFQUFFb0IsVUFBVSxNQUFNQyxNQUFNLFVBQVU7QUFBQSxVQUM5QyxXQUFVO0FBQUEsVUFFVixpQ0FBQyxZQUFTLFVBQVUsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZSxHQUNoQ1o7QUFBQUEsb0JBQVEsY0FBYyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQUs7QUFBQSxZQUMzQkEsUUFBUSxhQUFhLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUztBQUFBLFlBQzlCQSxRQUFRLGVBQWUsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFTO0FBQUEsWUFDaENBLFFBQVEsWUFBWSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVE7QUFBQSxlQUovQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUE7QUFBQSxRQVpLQTtBQUFBQSxRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxNQUNDLENBQUNJLGVBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVUsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBLEtBL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQ0EsS0FsQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLElBRUEsdUJBQUMsbUJBQ0VILHNCQUFZRixRQUFRVyxhQUNuQix1QkFBQyxZQUFTLFVBQVUsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEdBQ2pDLGlDQUFDLFlBQVlULFVBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQixLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNBLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsT0FoRVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlFQTtBQUVKO0FBQUNILElBNUVRRCxPQUFLO0FBQUEsVUFDMkMzQyxNQUFNO0FBQUE7QUFBQSxPQUR0RDJDO0FBOEVULHdCQUF3QmdCLE1BQU07QUFDNUIsU0FDRSx1QkFBQyxnQkFBYSxlQUFjLFFBQzFCLGlDQUFDLGVBQ0MsaUNBQUMsaUJBQ0MsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQU0sS0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUE7QUFFSjtBQUFDQyxPQVZ1QkQ7QUFBRyxJQUFBckQsSUFBQUMsS0FBQUUsS0FBQUMsS0FBQUUsS0FBQUMsS0FBQUUsS0FBQUMsS0FBQUUsS0FBQUMsS0FBQUUsS0FBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQUMsTUFBQUUsTUFBQStCLE1BQUFDLE1BQUFGO0FBQUEsYUFBQXRELElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUMsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBQyxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFDLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQStCLE1BQUE7QUFBQSxhQUFBQyxNQUFBO0FBQUEsYUFBQUYsTUFBQSIsIm5hbWVzIjpbImxhenkiLCJTdXNwZW5zZSIsInVzZU1lbW8iLCJBbmltYXRlUHJlc2VuY2UiLCJNb3Rpb25Db25maWciLCJtb3Rpb24iLCJBcHBQcm92aWRlciIsInVzZUFwcCIsIkJvdHRvbU5hdiIsIlNpZGViYXIiLCJFcnJvckJvdW5kYXJ5IiwiSWNvbkJvbHQiLCJBdXRoIiwiX2MiLCJfYzIiLCJPbmJvYXJkaW5nIiwiX2MzIiwiX2M0IiwiRmVlZCIsIl9jNSIsIl9jNiIsIlJvdXRpbmVzIiwiX2M3IiwiX2M4IiwiUHJvZ3Jlc3MiLCJfYzkiLCJfYzAiLCJQcm9maWxlIiwiX2MxIiwiX2MxMCIsIlBsYXllciIsIl9jMTEiLCJfYzEyIiwiU2hhcmVkUm91dGluZSIsIl9jMTMiLCJfYzE0IiwiU2NyZWVuRmFsbGJhY2siLCJfYzE1IiwiVG9hc3RzIiwiX3MiLCJ0b2FzdHMiLCJtYXAiLCJ0Iiwib3BhY2l0eSIsInkiLCJzY2FsZSIsImJhY2tncm91bmQiLCJjb2xvciIsIm1zZyIsImlkIiwiU2hlbGwiLCJfczIiLCJwcm9maWxlIiwidGFiIiwicGxheWVySWQiLCJ0b2tlbiIsImF1dGhMb2FkaW5nIiwic2hhcmVkVG9rZW4iLCJtYXRjaCIsIndpbmRvdyIsImxvY2F0aW9uIiwicGF0aG5hbWUiLCJ3cml0aW5nTW9kZSIsIm9uYm9hcmRlZCIsImR1cmF0aW9uIiwiZWFzZSIsIkFwcCIsIl9jMTgiLCJfYzE2IiwiX2MxNyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGxhenksIFN1c3BlbnNlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEFuaW1hdGVQcmVzZW5jZSwgTW90aW9uQ29uZmlnLCBtb3Rpb24gfSBmcm9tIFwiZnJhbWVyLW1vdGlvblwiO1xyXG5pbXBvcnQgeyBBcHBQcm92aWRlciwgdXNlQXBwIH0gZnJvbSBcIi4vc3RvcmVcIjtcclxuaW1wb3J0IEJvdHRvbU5hdiBmcm9tIFwiLi9jb21wb25lbnRzL0JvdHRvbU5hdlwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi9jb21wb25lbnRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgRXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuL2NvbXBvbmVudHMvRXJyb3JCb3VuZGFyeVwiO1xyXG5pbXBvcnQgeyBJY29uQm9sdCB9IGZyb20gXCIuL2NvbXBvbmVudHMvSWNvbnNcIjtcclxuXHJcbmNvbnN0IEF1dGggPSBsYXp5KCgpID0+IGltcG9ydChcIi4vc2NyZWVucy9BdXRoXCIpKTtcclxuY29uc3QgT25ib2FyZGluZyA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi9zY3JlZW5zL09uYm9hcmRpbmdcIikpO1xyXG5jb25zdCBGZWVkID0gbGF6eSgoKSA9PiBpbXBvcnQoXCIuL3NjcmVlbnMvRmVlZFwiKSk7XHJcbmNvbnN0IFJvdXRpbmVzID0gbGF6eSgoKSA9PiBpbXBvcnQoXCIuL3NjcmVlbnMvUm91dGluZXNcIikpO1xyXG5jb25zdCBQcm9ncmVzcyA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi9zY3JlZW5zL1Byb2dyZXNzXCIpKTtcclxuY29uc3QgUHJvZmlsZSA9IGxhenkoKCkgPT4gaW1wb3J0KFwiLi9zY3JlZW5zL1Byb2ZpbGVcIikpO1xyXG5jb25zdCBQbGF5ZXIgPSBsYXp5KCgpID0+IGltcG9ydChcIi4vc2NyZWVucy9QbGF5ZXJcIikpO1xyXG5jb25zdCBTaGFyZWRSb3V0aW5lID0gbGF6eSgoKSA9PiBpbXBvcnQoXCIuL3NjcmVlbnMvU2hhcmVkUm91dGluZVwiKSk7XHJcblxyXG5mdW5jdGlvbiBTY3JlZW5GYWxsYmFjaygpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIG1pbi1oLVs0MGR2aF0gcGxhY2UtaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgIDxzcGFuIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWxhYmVsPVwiQ2FycmVnYW5kb1wiIGNsYXNzTmFtZT1cInRhYnVsYXIgZm9udC1kaXNwbGF5IHRleHQtbGcgdXBwZXJjYXNlIHRyYWNraW5nLVswLjJlbV0gdGV4dC12b2x0LTQwMFwiPlxyXG4gICAgICAgIENhcnJlZ2FuZG/igKZcclxuICAgICAgPC9zcGFuPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gVG9hc3RzKCkge1xyXG4gIGNvbnN0IHsgdG9hc3RzIH0gPSB1c2VBcHAoKTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGZpeGVkIGluc2V0LXgtMCBib3R0b20tMjQgei1bNzBdIG14LWF1dG8gZmxleCB3LWZ1bGwgbWF4LXctWzQzMHB4XSBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNiBsZzpib3R0b20tOCBsZzptYXgtdy1ub25lXCI+XHJcbiAgICAgIDxBbmltYXRlUHJlc2VuY2U+XHJcbiAgICAgICAge3RvYXN0cy5tYXAoKHQpID0+IChcclxuICAgICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICAgIGtleT17dC5pZH1cclxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAxOCwgc2NhbGU6IDAuOTQgfX1cclxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwLCBzY2FsZTogMSB9fVxyXG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHk6IDgsIHNjYWxlOiAwLjk2IH19XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtaW5rLTk1MCBzaGFkb3ctWzBfMTJweF8zNnB4X3JnYmEoMCwwLDAsMC40NSldXCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogdC5jb2xvciA/PyBcIiNkNGY1M2NcIiB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SWNvbkJvbHQgc2l6ZT17MTR9IHN0cm9rZVdpZHRoPXsyLjR9IC8+XHJcbiAgICAgICAgICAgIHt0Lm1zZ31cclxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBTaGVsbCgpIHtcclxuICBjb25zdCB7IHByb2ZpbGUsIHRhYiwgcGxheWVySWQsIHRva2VuLCBhdXRoTG9hZGluZyB9ID0gdXNlQXBwKCk7XHJcbiAgLy8gW1VFLTI5XSBSb3RhIHDDumJsaWNhIGRlIHJvdGluYSBjb21wYXJ0aWxoYWRhICgvY29tcGFydGlsaGFkYS86dG9rZW4pIGZvcmEgZG8gZ2F0ZSBkZSBhdXRoLlxyXG4gIGNvbnN0IHNoYXJlZFRva2VuID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBtYXRjaCA9IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5tYXRjaCgvXlxcL2NvbXBhcnRpbGhhZGFcXC8oW0EtWmEtejAtOV8tXSspJC8pO1xyXG4gICAgcmV0dXJuIG1hdGNoID8gbWF0Y2hbMV0gOiBudWxsO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibm9pc2UgcmVsYXRpdmUgbWluLWgtZHZoXCI+XHJcbiAgICAgIHsvKiBhbWJpZW50IGJhY2tncm91bmQgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBmaXhlZCBpbnNldC0wIHotMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQtYmcgYWJzb2x1dGUgaW5zZXQtMFwiIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnbG93LWRyaWZ0IGFic29sdXRlIC10b3AtMjQgbGVmdC1bOCVdIGgtODAgdy04MCByb3VuZGVkLWZ1bGwgYmctW3JnYmEoMjEyLDI0NSw2MCwwLjA3KV0gYmx1ci0zeGxcIiAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xvdy1kcmlmdC1zbG93IGFic29sdXRlIHJpZ2h0LVs0JV0gdG9wLTEvMyBoLTk2IHctOTYgcm91bmRlZC1mdWxsIGJnLVtyZ2JhKDUyLDIxNywxMjMsMC4wNildIGJsdXItM3hsXCIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsb3ctZHJpZnQgYWJzb2x1dGUgLWJvdHRvbS0yMCBsZWZ0LTEvMyBoLTcyIHctNzIgcm91bmRlZC1mdWxsIGJnLVtyZ2JhKDI1NSw4MSw3MiwwLjA1KV0gYmx1ci0zeGxcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBkZXNrdG9wIHNpZGUgZmxvdXJpc2ggKi99XHJcbiAgICAgIDxwXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgcmlnaHQtNiB0b3AtMS8yIHotMCBoaWRkZW4gLXRyYW5zbGF0ZS15LTEvMiByb3RhdGUtMTgwIGZvbnQtZGlzcGxheSB0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy1bMC41ZW1dIHRleHQtZm9nLW11dGUvNTAgeGw6YmxvY2tcIlxyXG4gICAgICAgIHN0eWxlPXt7IHdyaXRpbmdNb2RlOiBcInZlcnRpY2FsLXJsXCIgfX1cclxuICAgICAgPlxyXG4gICAgICAgIGV4ZXJjaXNlIMOXIHNwb3J0IMK3IHJlbGV2YW5jZSAx4oCTNVxyXG4gICAgICA8L3A+XHJcblxyXG4gICAgICB7dG9rZW4gJiYgIXNoYXJlZFRva2VuICYmIDxTaWRlYmFyIC8+fVxyXG5cclxuICAgICAgey8qIGFwcCBjb2x1bW4gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcmVsYXRpdmUgei0xMCAke3Rva2VuICYmICFzaGFyZWRUb2tlbiA/IFwibGc6cGwtWzI2MHB4XVwiIDogXCJcIn1gfT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIG14LWF1dG8gZmxleCBtaW4taC1kdmggdy1mdWxsIG1heC13LVs0MzBweF0gZmxleC1jb2wgYm9yZGVyLXggYm9yZGVyLWluay04MDAgYmctaW5rLTkwMC83MCBiYWNrZHJvcC1ibHVyLXNtIGxnOm1heC13LVsxMTIwcHhdIGxnOmJnLWluay05MDAvNTBcIj5cclxuICAgICAgICB7c2hhcmVkVG9rZW4gPyAoXHJcbiAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxTY3JlZW5GYWxsYmFjayAvPn0+PFNoYXJlZFJvdXRpbmUgdG9rZW49e3NoYXJlZFRva2VufSAvPjwvU3VzcGVuc2U+XHJcbiAgICAgICAgKSA6IGF1dGhMb2FkaW5nID8gPGRpdiBjbGFzc05hbWU9XCJncmlkIG1pbi1oLWR2aCBwbGFjZS1pdGVtcy1jZW50ZXIgZm9udC1kaXNwbGF5IHRleHQteGwgdXBwZXJjYXNlIHRleHQtdm9sdC00MDBcIj5DYXJyZWdhbmRv4oCmPC9kaXY+IDogIXRva2VuID8gKFxyXG4gICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8U2NyZWVuRmFsbGJhY2sgLz59PjxBdXRoIC8+PC9TdXNwZW5zZT5cclxuICAgICAgICApIDogIXByb2ZpbGUub25ib2FyZGVkID8gKFxyXG4gICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8U2NyZWVuRmFsbGJhY2sgLz59PjxPbmJvYXJkaW5nIC8+PC9TdXNwZW5zZT5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAgPEFuaW1hdGVQcmVzZW5jZSBtb2RlPVwid2FpdFwiPlxyXG4gICAgICAgICAgICAgIDxtb3Rpb24ubWFpblxyXG4gICAgICAgICAgICAgICAga2V5PXt0YWJ9XHJcbiAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDE2IH19XHJcbiAgICAgICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cclxuICAgICAgICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgeTogLTEwIH19XHJcbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjI0LCBlYXNlOiBcImVhc2VPdXRcIiB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxTY3JlZW5GYWxsYmFjayAvPn0+XHJcbiAgICAgICAgICAgICAgICAgIHt0YWIgPT09IFwiZXhwbG9yYXJcIiAmJiA8RmVlZCAvPn1cclxuICAgICAgICAgICAgICAgICAge3RhYiA9PT0gXCJyb3RpbmFzXCIgJiYgPFJvdXRpbmVzIC8+fVxyXG4gICAgICAgICAgICAgICAgICB7dGFiID09PSBcInByb2dyZXNzb1wiICYmIDxQcm9ncmVzcyAvPn1cclxuICAgICAgICAgICAgICAgICAge3RhYiA9PT0gXCJwZXJmaWxcIiAmJiA8UHJvZmlsZSAvPn1cclxuICAgICAgICAgICAgICAgIDwvU3VzcGVuc2U+XHJcbiAgICAgICAgICAgICAgPC9tb3Rpb24ubWFpbj5cclxuICAgICAgICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XHJcbiAgICAgICAgICAgIHshc2hhcmVkVG9rZW4gJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6aGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICA8Qm90dG9tTmF2IC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8Lz5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8QW5pbWF0ZVByZXNlbmNlPlxyXG4gICAgICAgIHtwbGF5ZXJJZCAmJiBwcm9maWxlLm9uYm9hcmRlZCAmJiAoXHJcbiAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxTY3JlZW5GYWxsYmFjayAvPn0+XHJcbiAgICAgICAgICAgIDxQbGF5ZXIga2V5PXtwbGF5ZXJJZH0gLz5cclxuICAgICAgICAgIDwvU3VzcGVuc2U+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XHJcbiAgICAgIDxUb2FzdHMgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPE1vdGlvbkNvbmZpZyByZWR1Y2VkTW90aW9uPVwidXNlclwiPlxyXG4gICAgICA8QXBwUHJvdmlkZXI+XHJcbiAgICAgICAgPEVycm9yQm91bmRhcnk+XHJcbiAgICAgICAgICA8U2hlbGwgLz5cclxuICAgICAgICA8L0Vycm9yQm91bmRhcnk+XHJcbiAgICAgIDwvQXBwUHJvdmlkZXI+XHJcbiAgICA8L01vdGlvbkNvbmZpZz5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvbHVpenIvT25lRHJpdmUvRG9jdW1lbnRvcy9wcm9ncmFtYXMtZ2l0L3VsdHJhLWV4ZXJjaXNlcy91bHRyYS1leGVyY2lzZXMvc3JjL0FwcC50c3gifQ==