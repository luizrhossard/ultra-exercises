import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ErrorBoundary.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8a41314"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=a8a41314"; const Component = __vite__cjsImport2_react["Component"];
export class ErrorBoundary extends Component {
  constructor() {
    super(...arguments);
    this.state = { hasError: false };
    this.reset = () => this.setState({ hasError: false });
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(error) {
    console.error("Erro inesperado na interface:", error);
  }
  render() {
    if (!this.state.hasError) return this.props.children;
    return /* @__PURE__ */ jsxDEV("div", { role: "alert", className: "grid min-h-dvh place-items-center px-5", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-[430px] rounded-2xl border border-ink-700 bg-ink-850 p-6 text-center", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "font-display text-2xl uppercase text-fog", children: "Algo deu errado" }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/ErrorBoundary.tsx",
        lineNumber: 36,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-[13px] text-fog-dim", children: "Ocorreu um erro inesperado na interface. Seus dados de treino continuam salvos." }, void 0, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/ErrorBoundary.tsx",
        lineNumber: 37,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex flex-col gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: this.reset,
            className: "w-full rounded-xl bg-volt-400 py-3 font-display uppercase text-ink-950",
            children: "Tentar novamente"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/ErrorBoundary.tsx",
            lineNumber: 41,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => window.location.reload(),
            className: "w-full rounded-xl border border-ink-700 py-3 text-[12px] font-bold text-volt-300",
            children: "Recarregar página"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/ErrorBoundary.tsx",
            lineNumber: 47,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/ErrorBoundary.tsx",
        lineNumber: 40,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/ErrorBoundary.tsx",
      lineNumber: 35,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/ErrorBoundary.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this);
  }
}
export default ErrorBoundary;
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/ErrorBoundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/ErrorBoundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NVOzs7QUFoQ1YsU0FBU0EsaUJBQWlDO0FBY25DLGFBQU1DLHNCQUFzQkQsVUFBa0Q7QUFBQSxFQUE5RTtBQUFBO0FBQ0xFLGlCQUE0QixFQUFFQyxVQUFVLE1BQU07QUFVOUMsU0FBUUMsUUFBUUEsTUFBTSxLQUFLQyxTQUFTLEVBQUVGLFVBQVUsTUFBTSxDQUFDO0FBQUE7QUFBQSxFQVJ2RCxPQUFPRywyQkFBK0M7QUFDcEQsV0FBTyxFQUFFSCxVQUFVLEtBQUs7QUFBQSxFQUMxQjtBQUFBLEVBRUFJLGtCQUFrQkMsT0FBZ0I7QUFDaENDLFlBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQUEsRUFDdEQ7QUFBQSxFQUlBRSxTQUFTO0FBQ1AsUUFBSSxDQUFDLEtBQUtSLE1BQU1DLFNBQVUsUUFBTyxLQUFLUSxNQUFNQztBQUM1QyxXQUNFLHVCQUFDLFNBQUksTUFBSyxTQUFRLFdBQVUsMENBQzFCLGlDQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLDZCQUFDLE9BQUUsV0FBVSw0Q0FBMkMsK0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUU7QUFBQSxNQUN2RSx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLCtGQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLEtBQUtSO0FBQUFBLFlBQ2QsV0FBVTtBQUFBLFlBQXdFO0FBQUE7QUFBQSxVQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTVMsT0FBT0MsU0FBU0MsT0FBTztBQUFBLFlBQ3RDLFdBQVU7QUFBQSxZQUFrRjtBQUFBO0FBQUEsVUFGOUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLEVBRUo7QUFDRjtBQUVBLGVBQWVkIiwibmFtZXMiOlsiQ29tcG9uZW50IiwiRXJyb3JCb3VuZGFyeSIsInN0YXRlIiwiaGFzRXJyb3IiLCJyZXNldCIsInNldFN0YXRlIiwiZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yIiwiY29tcG9uZW50RGlkQ2F0Y2giLCJlcnJvciIsImNvbnNvbGUiLCJyZW5kZXIiLCJwcm9wcyIsImNoaWxkcmVuIiwid2luZG93IiwibG9jYXRpb24iLCJyZWxvYWQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRXJyb3JCb3VuZGFyeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCB0eXBlIFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW50ZXJmYWNlIEVycm9yQm91bmRhcnlQcm9wcyB7XHJcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcclxufVxyXG5cclxuaW50ZXJmYWNlIEVycm9yQm91bmRhcnlTdGF0ZSB7XHJcbiAgaGFzRXJyb3I6IGJvb2xlYW47XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBCYXJyZWlyYSBnbG9iYWwgZGUgZXJyb3MgZGUgcmVuZGVyaXphw6fDo286IGV2aXRhIHRlbGEgYnJhbmNhIGUgb2ZlcmVjZVxyXG4gKiByZWN1cGVyYcOnw6NvIGFtaWfDoXZlbC4gTsOjbyBleGliZSBkZXRhbGhlcyB0w6ljbmljb3MgZG8gZXJybyBhbyB1c3XDoXJpby5cclxuICovXHJcbmV4cG9ydCBjbGFzcyBFcnJvckJvdW5kYXJ5IGV4dGVuZHMgQ29tcG9uZW50PEVycm9yQm91bmRhcnlQcm9wcywgRXJyb3JCb3VuZGFyeVN0YXRlPiB7XHJcbiAgc3RhdGU6IEVycm9yQm91bmRhcnlTdGF0ZSA9IHsgaGFzRXJyb3I6IGZhbHNlIH07XHJcblxyXG4gIHN0YXRpYyBnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IoKTogRXJyb3JCb3VuZGFyeVN0YXRlIHtcclxuICAgIHJldHVybiB7IGhhc0Vycm9yOiB0cnVlIH07XHJcbiAgfVxyXG5cclxuICBjb21wb25lbnREaWRDYXRjaChlcnJvcjogdW5rbm93bikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm8gaW5lc3BlcmFkbyBuYSBpbnRlcmZhY2U6XCIsIGVycm9yKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgcmVzZXQgPSAoKSA9PiB0aGlzLnNldFN0YXRlKHsgaGFzRXJyb3I6IGZhbHNlIH0pO1xyXG5cclxuICByZW5kZXIoKSB7XHJcbiAgICBpZiAoIXRoaXMuc3RhdGUuaGFzRXJyb3IpIHJldHVybiB0aGlzLnByb3BzLmNoaWxkcmVuO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJncmlkIG1pbi1oLWR2aCBwbGFjZS1pdGVtcy1jZW50ZXIgcHgtNVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LVs0MzBweF0gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1pbmstNzAwIGJnLWluay04NTAgcC02IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC0yeGwgdXBwZXJjYXNlIHRleHQtZm9nXCI+QWxnbyBkZXUgZXJyYWRvPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LVsxM3B4XSB0ZXh0LWZvZy1kaW1cIj5cclxuICAgICAgICAgICAgT2NvcnJldSB1bSBlcnJvIGluZXNwZXJhZG8gbmEgaW50ZXJmYWNlLiBTZXVzIGRhZG9zIGRlIHRyZWlubyBjb250aW51YW0gc2Fsdm9zLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXggZmxleC1jb2wgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3RoaXMucmVzZXR9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYmctdm9sdC00MDAgcHktMyBmb250LWRpc3BsYXkgdXBwZXJjYXNlIHRleHQtaW5rLTk1MFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBUZW50YXIgbm92YW1lbnRlXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItaW5rLTcwMCBweS0zIHRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LXZvbHQtMzAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJlY2FycmVnYXIgcMOhZ2luYVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFcnJvckJvdW5kYXJ5O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL2x1aXpyL09uZURyaXZlL0RvY3VtZW50b3MvcHJvZ3JhbWFzLWdpdC91bHRyYS1leGVyY2lzZXMvdWx0cmEtZXhlcmNpc2VzL3NyYy9jb21wb25lbnRzL0Vycm9yQm91bmRhcnkudHN4In0=