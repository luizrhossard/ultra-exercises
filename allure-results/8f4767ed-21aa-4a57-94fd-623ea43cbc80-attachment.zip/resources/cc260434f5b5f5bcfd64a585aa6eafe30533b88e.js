import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BottomNav.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8a41314"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=a8a41314";
import { useApp } from "/src/store.tsx";
import { IconBolt, IconClipboard, IconRadar, IconTrend, IconUser } from "/src/components/Icons.tsx";
const TABS = [
  { id: "explorar", label: "Explorar", icon: (p) => /* @__PURE__ */ jsxDEV(IconRadar, { ...p }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
    lineNumber: 26,
    columnNumber: 51
  }, this) },
  { id: "rotinas", label: "Rotinas", icon: (p) => /* @__PURE__ */ jsxDEV(IconClipboard, { ...p }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
    lineNumber: 27,
    columnNumber: 49
  }, this) },
  { id: "progresso", label: "Progresso", icon: (p) => /* @__PURE__ */ jsxDEV(IconTrend, { ...p }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
    lineNumber: 28,
    columnNumber: 53
  }, this) },
  { id: "perfil", label: "Perfil", icon: (p) => /* @__PURE__ */ jsxDEV(IconUser, { ...p }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
    lineNumber: 29,
    columnNumber: 47
  }, this) }
];
export default function BottomNav() {
  _s();
  const { tab, setTab, setGenFocus } = useApp();
  const go = (t) => setTab(t);
  return /* @__PURE__ */ jsxDEV("nav", { className: "fixed inset-x-0 bottom-0 z-30 mx-auto w-full max-w-[430px] border-t border-ink-700 bg-ink-900/92 pb-[max(env(safe-area-inset-bottom),10px)] pt-2 backdrop-blur-md", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-5 items-end px-2", children: [
    TABS.slice(0, 2).map(
      (t) => /* @__PURE__ */ jsxDEV(NavBtn, { t, active: tab === t.id, onClick: () => go(t.id) }, t.id, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
        lineNumber: 41,
        columnNumber: 9
      }, this)
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxDEV(
      motion.button,
      {
        whileTap: { scale: 0.88 },
        onClick: () => {
          setGenFocus(null);
          go("rotinas");
          window.setTimeout(
            () => document.getElementById("generator-card")?.scrollIntoView({ behavior: "smooth", block: "center" }),
            60
          );
        },
        "aria-label": "Gerar treino do dia",
        className: "relative -mt-7 grid h-14 w-14 place-items-center rounded-2xl bg-volt-400 text-ink-950 shadow-[0_10px_30px_rgba(212,245,60,0.35)]",
        children: [
          /* @__PURE__ */ jsxDEV(IconBolt, { size: 26, strokeWidth: 2 }, void 0, false, {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
            lineNumber: 58,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "absolute -bottom-4 text-[8px] font-bold uppercase tracking-[0.18em] text-volt-400", children: "Gerar" }, void 0, false, {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
            lineNumber: 59,
            columnNumber: 13
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
        lineNumber: 45,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
      lineNumber: 44,
      columnNumber: 9
    }, this),
    TABS.slice(2).map(
      (t) => /* @__PURE__ */ jsxDEV(NavBtn, { t, active: tab === t.id, onClick: () => go(t.id) }, t.id, false, {
        fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this)
    )
  ] }, void 0, true, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
    lineNumber: 39,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
    lineNumber: 38,
    columnNumber: 5
  }, this);
}
_s(BottomNav, "pcp0rDwhRUwt9vXC0b1RTXudYHA=", false, function() {
  return [useApp];
});
_c = BottomNav;
function NavBtn({
  t,
  active,
  onClick
}) {
  return /* @__PURE__ */ jsxDEV(
    motion.button,
    {
      whileTap: { scale: 0.9 },
      onClick,
      className: "relative flex flex-col items-center gap-1 py-1",
      "aria-label": t.label,
      children: [
        active && /* @__PURE__ */ jsxDEV(
          motion.span,
          {
            layoutId: "nav-notch",
            className: "absolute -top-2 h-[3px] w-8 rounded-full bg-volt-400"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
            lineNumber: 90,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: `transition-colors ${active ? "text-volt-400" : "text-fog-mute"}`, children: t.icon({ size: 21 }) }, void 0, false, {
          fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
          lineNumber: 95,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: `text-[9px] font-bold uppercase tracking-[0.14em] transition-colors ${active ? "text-fog" : "text-fog-mute"}`,
            children: t.label
          },
          void 0,
          false,
          {
            fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
            lineNumber: 96,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx",
      lineNumber: 83,
      columnNumber: 5
    },
    this
  );
}
_c2 = NavBtn;
var _c, _c2;
$RefreshReg$(_c, "BottomNav");
$RefreshReg$(_c2, "NavBtn");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/luizr/OneDrive/Documentos/programas-git/ultra-exercises/ultra-exercises/src/components/BottomNav.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTW9EOzs7Ozs7Ozs7Ozs7Ozs7OztBQU5wRCxTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGNBQWM7QUFFdkIsU0FBU0MsVUFBVUMsZUFBZUMsV0FBV0MsV0FBV0MsZ0JBQWdCO0FBRXhFLE1BQU1DLE9BQXNGO0FBQUEsRUFDMUYsRUFBRUMsSUFBSSxZQUFZQyxPQUFPLFlBQVlDLE1BQU1BLENBQUNDLE1BQU0sdUJBQUMsYUFBVSxHQUFJQSxLQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBaUIsRUFBSTtBQUFBLEVBQ3ZFLEVBQUVILElBQUksV0FBV0MsT0FBTyxXQUFXQyxNQUFNQSxDQUFDQyxNQUFNLHVCQUFDLGlCQUFjLEdBQUlBLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUIsRUFBSTtBQUFBLEVBQ3pFLEVBQUVILElBQUksYUFBYUMsT0FBTyxhQUFhQyxNQUFNQSxDQUFDQyxNQUFNLHVCQUFDLGFBQVUsR0FBSUEsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlCLEVBQUk7QUFBQSxFQUN6RSxFQUFFSCxJQUFJLFVBQVVDLE9BQU8sVUFBVUMsTUFBTUEsQ0FBQ0MsTUFBTSx1QkFBQyxZQUFTLEdBQUlBLEtBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnQixFQUFJO0FBQUM7QUFHckUsd0JBQXdCQyxZQUFZO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxFQUFFQyxLQUFLQyxRQUFRQyxZQUFZLElBQUlmLE9BQU87QUFFNUMsUUFBTWdCLEtBQUtBLENBQUNDLE1BQVdILE9BQU9HLENBQUM7QUFFL0IsU0FDRSx1QkFBQyxTQUFJLFdBQVUscUtBQ2IsaUNBQUMsU0FBSSxXQUFVLG1DQUNaWDtBQUFBQSxTQUFLWSxNQUFNLEdBQUcsQ0FBQyxFQUFFQztBQUFBQSxNQUFJLENBQUNGLE1BQ3JCLHVCQUFDLFVBQWtCLEdBQU0sUUFBUUosUUFBUUksRUFBRVYsSUFBSSxTQUFTLE1BQU1TLEdBQUdDLEVBQUVWLEVBQUUsS0FBeERVLEVBQUVWLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RTtBQUFBLElBQ3hFO0FBQUEsSUFFRCx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxNQUFDLE9BQU87QUFBQSxNQUFQO0FBQUEsUUFDQyxVQUFVLEVBQUVhLE9BQU8sS0FBSztBQUFBLFFBQ3hCLFNBQVMsTUFBTTtBQUNiTCxzQkFBWSxJQUFJO0FBQ2hCQyxhQUFHLFNBQVM7QUFDWkssaUJBQU9DO0FBQUFBLFlBQ0wsTUFBTUMsU0FBU0MsZUFBZSxnQkFBZ0IsR0FBR0MsZUFBZSxFQUFFQyxVQUFVLFVBQVVDLE9BQU8sU0FBUyxDQUFDO0FBQUEsWUFDdkc7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLFFBQ0EsY0FBVztBQUFBLFFBQ1gsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxZQUFTLE1BQU0sSUFBSSxhQUFhLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1DO0FBQUEsVUFDbkMsdUJBQUMsVUFBSyxXQUFVLHFGQUFvRixxQkFBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBO0FBQUE7QUFBQSxNQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBRUNyQixLQUFLWSxNQUFNLENBQUMsRUFBRUM7QUFBQUEsTUFBSSxDQUFDRixNQUNsQix1QkFBQyxVQUFrQixHQUFNLFFBQVFKLFFBQVFJLEVBQUVWLElBQUksU0FBUyxNQUFNUyxHQUFHQyxFQUFFVixFQUFFLEtBQXhEVSxFQUFFVixJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUU7QUFBQSxJQUN4RTtBQUFBLE9BNUJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkEsS0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStCQTtBQUVKO0FBQUNLLEdBdkN1QkQsV0FBUztBQUFBLFVBQ01YLE1BQU07QUFBQTtBQUFBLEtBRHJCVztBQXlDeEIsU0FBU2lCLE9BQU87QUFBQSxFQUNkWDtBQUFBQSxFQUNBWTtBQUFBQSxFQUNBQztBQUtGLEdBQUc7QUFDRCxTQUNFO0FBQUEsSUFBQyxPQUFPO0FBQUEsSUFBUDtBQUFBLE1BQ0MsVUFBVSxFQUFFVixPQUFPLElBQUk7QUFBQSxNQUN2QjtBQUFBLE1BQ0EsV0FBVTtBQUFBLE1BQ1YsY0FBWUgsRUFBRVQ7QUFBQUEsTUFFYnFCO0FBQUFBLGtCQUNDO0FBQUEsVUFBQyxPQUFPO0FBQUEsVUFBUDtBQUFBLFlBQ0MsVUFBUztBQUFBLFlBQ1QsV0FBVTtBQUFBO0FBQUEsVUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFa0U7QUFBQSxRQUdwRSx1QkFBQyxVQUFLLFdBQVcscUJBQXFCQSxTQUFTLGtCQUFrQixlQUFlLElBQUtaLFlBQUVSLEtBQUssRUFBRXNCLE1BQU0sR0FBRyxDQUFDLEtBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEc7QUFBQSxRQUMxRztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVyxzRUFDVEYsU0FBUyxhQUFhLGVBQWU7QUFBQSxZQUd0Q1osWUFBRVQ7QUFBQUE7QUFBQUEsVUFMTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBO0FBQUE7QUFBQSxJQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFvQkE7QUFFSjtBQUFDd0IsTUFoQ1FKO0FBQU0sSUFBQUssSUFBQUQ7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIm1vdGlvbiIsInVzZUFwcCIsIkljb25Cb2x0IiwiSWNvbkNsaXBib2FyZCIsIkljb25SYWRhciIsIkljb25UcmVuZCIsIkljb25Vc2VyIiwiVEFCUyIsImlkIiwibGFiZWwiLCJpY29uIiwicCIsIkJvdHRvbU5hdiIsIl9zIiwidGFiIiwic2V0VGFiIiwic2V0R2VuRm9jdXMiLCJnbyIsInQiLCJzbGljZSIsIm1hcCIsInNjYWxlIiwid2luZG93Iiwic2V0VGltZW91dCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJzY3JvbGxJbnRvVmlldyIsImJlaGF2aW9yIiwiYmxvY2siLCJOYXZCdG4iLCJhY3RpdmUiLCJvbkNsaWNrIiwic2l6ZSIsIl9jMiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJvdHRvbU5hdi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbW90aW9uIH0gZnJvbSBcImZyYW1lci1tb3Rpb25cIjtcclxuaW1wb3J0IHsgdXNlQXBwIH0gZnJvbSBcIi4uL3N0b3JlXCI7XHJcbmltcG9ydCB0eXBlIHsgVGFiIH0gZnJvbSBcIi4uL3R5cGVzXCI7XHJcbmltcG9ydCB7IEljb25Cb2x0LCBJY29uQ2xpcGJvYXJkLCBJY29uUmFkYXIsIEljb25UcmVuZCwgSWNvblVzZXIgfSBmcm9tIFwiLi9JY29uc1wiO1xyXG5cclxuY29uc3QgVEFCUzogeyBpZDogVGFiOyBsYWJlbDogc3RyaW5nOyBpY29uOiAocDogeyBzaXplPzogbnVtYmVyIH0pID0+IFJlYWN0LlJlYWN0Tm9kZSB9W10gPSBbXHJcbiAgeyBpZDogXCJleHBsb3JhclwiLCBsYWJlbDogXCJFeHBsb3JhclwiLCBpY29uOiAocCkgPT4gPEljb25SYWRhciB7Li4ucH0gLz4gfSxcclxuICB7IGlkOiBcInJvdGluYXNcIiwgbGFiZWw6IFwiUm90aW5hc1wiLCBpY29uOiAocCkgPT4gPEljb25DbGlwYm9hcmQgey4uLnB9IC8+IH0sXHJcbiAgeyBpZDogXCJwcm9ncmVzc29cIiwgbGFiZWw6IFwiUHJvZ3Jlc3NvXCIsIGljb246IChwKSA9PiA8SWNvblRyZW5kIHsuLi5wfSAvPiB9LFxyXG4gIHsgaWQ6IFwicGVyZmlsXCIsIGxhYmVsOiBcIlBlcmZpbFwiLCBpY29uOiAocCkgPT4gPEljb25Vc2VyIHsuLi5wfSAvPiB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQm90dG9tTmF2KCkge1xyXG4gIGNvbnN0IHsgdGFiLCBzZXRUYWIsIHNldEdlbkZvY3VzIH0gPSB1c2VBcHAoKTtcclxuXHJcbiAgY29uc3QgZ28gPSAodDogVGFiKSA9PiBzZXRUYWIodCk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bmF2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LXgtMCBib3R0b20tMCB6LTMwIG14LWF1dG8gdy1mdWxsIG1heC13LVs0MzBweF0gYm9yZGVyLXQgYm9yZGVyLWluay03MDAgYmctaW5rLTkwMC85MiBwYi1bbWF4KGVudihzYWZlLWFyZWEtaW5zZXQtYm90dG9tKSwxMHB4KV0gcHQtMiBiYWNrZHJvcC1ibHVyLW1kXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNSBpdGVtcy1lbmQgcHgtMlwiPlxyXG4gICAgICAgIHtUQUJTLnNsaWNlKDAsIDIpLm1hcCgodCkgPT4gKFxyXG4gICAgICAgICAgPE5hdkJ0biBrZXk9e3QuaWR9IHQ9e3R9IGFjdGl2ZT17dGFiID09PSB0LmlkfSBvbkNsaWNrPXsoKSA9PiBnbyh0LmlkKX0gLz5cclxuICAgICAgICApKX1cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICA8bW90aW9uLmJ1dHRvblxyXG4gICAgICAgICAgICB3aGlsZVRhcD17eyBzY2FsZTogMC44OCB9fVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0R2VuRm9jdXMobnVsbCk7XHJcbiAgICAgICAgICAgICAgZ28oXCJyb3RpbmFzXCIpO1xyXG4gICAgICAgICAgICAgIHdpbmRvdy5zZXRUaW1lb3V0KFxyXG4gICAgICAgICAgICAgICAgKCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnZW5lcmF0b3ItY2FyZFwiKT8uc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogXCJzbW9vdGhcIiwgYmxvY2s6IFwiY2VudGVyXCIgfSksXHJcbiAgICAgICAgICAgICAgICA2MFxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJHZXJhciB0cmVpbm8gZG8gZGlhXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgLW10LTcgZ3JpZCBoLTE0IHctMTQgcGxhY2UtaXRlbXMtY2VudGVyIHJvdW5kZWQtMnhsIGJnLXZvbHQtNDAwIHRleHQtaW5rLTk1MCBzaGFkb3ctWzBfMTBweF8zMHB4X3JnYmEoMjEyLDI0NSw2MCwwLjM1KV1cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SWNvbkJvbHQgc2l6ZT17MjZ9IHN0cm9rZVdpZHRoPXsyfSAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTQgdGV4dC1bOHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjE4ZW1dIHRleHQtdm9sdC00MDBcIj5cclxuICAgICAgICAgICAgICBHZXJhclxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L21vdGlvbi5idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHtUQUJTLnNsaWNlKDIpLm1hcCgodCkgPT4gKFxyXG4gICAgICAgICAgPE5hdkJ0biBrZXk9e3QuaWR9IHQ9e3R9IGFjdGl2ZT17dGFiID09PSB0LmlkfSBvbkNsaWNrPXsoKSA9PiBnbyh0LmlkKX0gLz5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L25hdj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBOYXZCdG4oe1xyXG4gIHQsXHJcbiAgYWN0aXZlLFxyXG4gIG9uQ2xpY2ssXHJcbn06IHtcclxuICB0OiAodHlwZW9mIFRBQlMpW251bWJlcl07XHJcbiAgYWN0aXZlOiBib29sZWFuO1xyXG4gIG9uQ2xpY2s6ICgpID0+IHZvaWQ7XHJcbn0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPG1vdGlvbi5idXR0b25cclxuICAgICAgd2hpbGVUYXA9e3sgc2NhbGU6IDAuOSB9fVxyXG4gICAgICBvbkNsaWNrPXtvbkNsaWNrfVxyXG4gICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMSBweS0xXCJcclxuICAgICAgYXJpYS1sYWJlbD17dC5sYWJlbH1cclxuICAgID5cclxuICAgICAge2FjdGl2ZSAmJiAoXHJcbiAgICAgICAgPG1vdGlvbi5zcGFuXHJcbiAgICAgICAgICBsYXlvdXRJZD1cIm5hdi1ub3RjaFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTIgaC1bM3B4XSB3LTggcm91bmRlZC1mdWxsIGJnLXZvbHQtNDAwXCJcclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9e2B0cmFuc2l0aW9uLWNvbG9ycyAke2FjdGl2ZSA/IFwidGV4dC12b2x0LTQwMFwiIDogXCJ0ZXh0LWZvZy1tdXRlXCJ9YH0+e3QuaWNvbih7IHNpemU6IDIxIH0pfTwvc3Bhbj5cclxuICAgICAgPHNwYW5cclxuICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LVs5cHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTRlbV0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgIGFjdGl2ZSA/IFwidGV4dC1mb2dcIiA6IFwidGV4dC1mb2ctbXV0ZVwiXHJcbiAgICAgICAgfWB9XHJcbiAgICAgID5cclxuICAgICAgICB7dC5sYWJlbH1cclxuICAgICAgPC9zcGFuPlxyXG4gICAgPC9tb3Rpb24uYnV0dG9uPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9sdWl6ci9PbmVEcml2ZS9Eb2N1bWVudG9zL3Byb2dyYW1hcy1naXQvdWx0cmEtZXhlcmNpc2VzL3VsdHJhLWV4ZXJjaXNlcy9zcmMvY29tcG9uZW50cy9Cb3R0b21OYXYudHN4In0=